import { useEffect, useMemo, useRef, useState } from 'react';
import { Game } from './game/game';
import { DEFAULT_SETTINGS, REGION_INFO, type HudState, type Settings } from './game/config';
import { Joystick, RoundButton } from './ui/Controls';
import { Loading, MainMenu, PausePanel, SettingsPanel, fmtHour } from './ui/Panels';
import {
  IconBoost, IconCloud, IconDown, IconFlower, IconGlide, IconLeaf, IconMist, IconMoon, IconNectar, IconPause, IconRain, IconSun, IconUp, IconWind, IconWings,
} from './ui/Icons';

const SETTINGS_KEY = 'butterfly.settings.v1';

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  const mobile = typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0 && Math.min(screen.width, screen.height) < 900;
  return { ...DEFAULT_SETTINGS, quality: mobile ? 'medium' : 'high' };
}

const timeName = (h: number) => (h >= 4.8 && h < 7 ? 'Sunrise' : h >= 7 && h < 11.5 ? 'Morning' : h >= 11.5 && h < 16.5 ? 'Afternoon' : h >= 16.5 && h < 19.3 ? 'Sunset' : 'Night');
const INTRO_CAPTIONS: [number, number, string][] = [
  [0.8, 6.5, 'Morning, deep within the verdant forest…'],
  [9, 15, 'Something stirs inside the chrysalis.'],
  [16.5, 24, 'A new life emerges.'],
  [27, 38, 'Wings, damp with dew, slowly unfold.'],
  [42, 47, 'Take flight.'],
];

function WeatherIcon({ w }: { w: string }) {
  if (w === 'Rain') return <IconRain size={14} />;
  if (w === 'Cloudy') return <IconCloud size={14} />;
  if (w === 'Windy') return <IconWind size={14} />;
  if (w === 'Mist') return <IconMist size={14} />;
  return <IconSun size={14} />;
}

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const mapRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [progress, setProgress] = useState({ p: 0, label: 'Preparing' });
  const [hud, setHud] = useState<HudState | null>(null);
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [showSettings, setShowSettings] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const el = mount.current!;
    const g = new Game(el, settings, { onHud: setHud, onProgress: (p, label) => setProgress({ p, label }) });
    gameRef.current = g;
    g.init().then(() => setGame(g)).catch((e) => { console.error(e); setError(String(e?.message || e)); });
    return () => { g.dispose(); gameRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { if (game && mapRef.current) game.attachMinimap(mapRef.current); }, [game, hud?.mode === 'menu']);

  const update = (s: Settings) => {
    setSettings(s);
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* ignore */ }
    game?.applySettings(s);
  };
  const sync = () => game && setHud(game.buildHud());

  const mode = hud?.mode ?? 'menu';
  const playing = !!hud && !['menu', 'paused', 'intro'].includes(mode);
  const loading = progress.p < 1;
  const hasSave = useMemo(() => (game ? game.hasSave() : false), [game, mode]);

  const A = hud;
  const prompt = A?.prompt;
  const perched = mode === 'feeding' || mode === 'resting' || mode === 'landing' || mode === 'sleeping';

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#06101c] text-white select-none" onContextMenu={(e) => e.preventDefault()}>
      <div ref={mount} className="absolute inset-0 overflow-hidden" style={{ touchAction: 'none' }} />

      {error && (
        <div className="absolute inset-0 z-[60] flex items-center justify-center p-8 text-center bg-black/80">
          <div>
            
            <div className="text-sm text-white/80">3D graphics could not start on this device/browser.</div>
            <div className="text-xs text-white/40 mt-2 break-all">{error}</div>
            <div className="text-xs text-white/50 mt-4">Try Chrome on Android with hardware acceleration enabled, or lower the graphics preset.</div>
          </div>
        </div>
      )}

      {/* ---------- in-game overlay ---------- */}
      <div className="absolute inset-0 pointer-events-none" style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)', paddingLeft: 'env(safe-area-inset-left)', paddingRight: 'env(safe-area-inset-right)' }}>
        {A && (playing || mode === 'paused') && (
          <>
            <div className="absolute top-3 left-3 flex flex-col gap-1.5 soft-text">
              <div className="glass rounded-full px-3 py-1 flex items-center gap-2 text-[11px] tracking-widest uppercase opacity-80">
                {A.night ? <IconMoon size={14} /> : <WeatherIcon w={A.weather} />}
                <span>{timeName(A.hour)}</span><span className="opacity-60">{fmtHour(A.hour)}</span>
              </div>
              <div className="glass rounded-full px-3 py-1 flex items-center gap-3 text-[11px] opacity-70 w-fit">
                <span className="flex items-center gap-1"><IconNectar size={13} />{A.nectar}</span>
                <span className="flex items-center gap-1"><IconFlower size={13} />{A.flowerTypes}</span>
              </div>
            </div>

            <div className="absolute top-3 right-3 flex items-start gap-2">
              <button className="pointer-events-auto glass rounded-full w-9 h-9 flex items-center justify-center opacity-70 mt-1" aria-label="Pause" onClick={() => { game?.pause(); sync(); }}>
                <IconPause size={16} />
              </button>
              <canvas ref={mapRef} width={192} height={192} className="w-[92px] h-[92px] rounded-full opacity-80" style={{ boxShadow: '0 0 18px rgba(0,30,60,0.35)' }} />
            </div>

            {A.regionTitle && (
              <div key={A.regionTitle} className="absolute top-[13%] left-0 right-0 text-center fade-up soft-text">
                <div className="text-[10px] tracking-[0.6em] text-cyan-100/80 uppercase mr-[-0.6em]">{REGION_INFO[A.region].sub}</div>
                <div className="text-3xl font-extralight tracking-[0.3em] mr-[-0.3em] title-glow">{A.regionTitle}</div>
              </div>
            )}

            {A.toast && (
              <div key={A.toast} className="absolute bottom-[22%] left-0 right-0 flex justify-center fade-up">
                <div className="glass-dark rounded-full px-5 py-2 text-xs tracking-[0.2em] uppercase text-cyan-50">{A.toast}</div>
              </div>
            )}
          </>
        )}

        {A && playing && game && (
          <>
            <Joystick game={game} />
            <div className="absolute right-4 bottom-5 flex items-end gap-3">
              <div className="flex flex-col gap-3 items-center">
                <RoundButton size={46} label="Glide" active={A.glide} onTap={() => { game.toggleGlide(); sync(); }}><IconGlide size={20} /></RoundButton>
                <RoundButton size={46} label="Boost" onDown={() => game.setHold('boost', true)} onUp={() => game.setHold('boost', false)}><IconBoost size={20} /></RoundButton>
              </div>
              <div className="flex flex-col gap-3 items-center">
                <RoundButton size={50} label="Ascend" onDown={() => game.setHold('up', true)} onUp={() => game.setHold('up', false)}><IconUp size={24} /></RoundButton>
                <RoundButton size={50} label="Descend" onDown={() => game.setHold('down', true)} onUp={() => game.setHold('down', false)}><IconDown size={24} /></RoundButton>
              </div>
              <div className="flex flex-col gap-3 items-center">
                {A.canSleep && <RoundButton size={46} label="Sleep" onTap={() => game.sleep()}><IconMoon size={20} /></RoundButton>}
                {(prompt || perched) ? (
                  <RoundButton size={64} pulse={!!prompt} label="Interact" onTap={() => { game.action(); sync(); }}>
                    {A.sleeping ? <IconSun size={28} /> : prompt === 'feed' ? <IconFlower size={28} /> : prompt ? <IconLeaf size={28} /> : <IconWings size={28} />}
                  </RoundButton>
                ) : (
                  <div style={{ width: 64, height: 64 }} />
                )}
              </div>
            </div>
          </>
        )}

        {/* sleeping */}
        <div className="absolute inset-0 transition-opacity duration-[2500ms]" style={{ opacity: A?.sleeping ? 1 : 0, background: 'radial-gradient(circle at 50% 50%, rgba(3,8,30,0.2), rgba(2,4,18,0.8))' }}>
          {A?.sleeping && [0, 1, 2].map((_, i) => (
            <div key={i} className="absolute text-2xl text-cyan-100/80" style={{ left: '56%', top: '46%', animation: `floatz 4s ease-in-out ${i * 1.3}s infinite` }}>z</div>
          ))}
        </div>

        {/* intro cinematic */}
        {A?.intro && (
          <>
            <div className="absolute left-0 right-0 top-0 bg-black transition-all duration-1000" style={{ height: '9vh' }} />
            <div className="absolute left-0 right-0 bottom-0 bg-black transition-all duration-1000" style={{ height: '9vh' }} />
            {INTRO_CAPTIONS.map(([a, b, t]) => A.introTime >= a && A.introTime <= b && (
              <div key={t} className="absolute left-0 right-0 bottom-[12vh] text-center fade-up soft-text text-sm sm:text-base tracking-[0.35em] uppercase text-white/90 px-6">{t}</div>
            ))}
            {A.introSkippable && (
              <button className="pointer-events-auto absolute right-5 bottom-[11vh] text-[11px] tracking-[0.3em] uppercase text-white/70 glass rounded-full px-4 py-1.5" onClick={() => game?.skipIntro()}>
                Skip ›
              </button>
            )}
          </>
        )}
      </div>

      {/* ---------- menus ---------- */}
      {game && mode === 'menu' && !showSettings && !loading && (
        <MainMenu
          hasSave={hasSave}
          onNew={() => { game.startNew(); sync(); }}
          onContinue={() => { game.continueGame(); sync(); }}
          onSettings={() => setShowSettings(true)}
        />
      )}
      {game && hud && mode === 'paused' && !showSettings && (
        <PausePanel hud={hud} onResume={() => { game.resume(); sync(); }} onSettings={() => setShowSettings(true)} onMenu={() => { game.toMenu(); sync(); }} />
      )}
      {game && showSettings && !loading && (
        <SettingsPanel s={settings} onChange={update} hour={hud?.hour ?? 8} onHour={(h) => { game.setHour(h); sync(); }} onClose={() => setShowSettings(false)} />
      )}
      {(loading || !game) && !error && <Loading p={progress.p} label={progress.label} />}
    </div>
  );
}
