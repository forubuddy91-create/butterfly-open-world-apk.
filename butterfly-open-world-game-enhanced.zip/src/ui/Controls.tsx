import { useRef, useState, type ReactNode, type PointerEvent as RPE } from 'react';
import type { Game } from '../game/game';

/** Floating translucent joystick: appears where the thumb lands in the lower-left zone. */
export function Joystick({ game }: { game: Game }) {
  const [origin, setOrigin] = useState<{ x: number; y: number } | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const id = useRef<number | null>(null);
  const R = 52;

  const move = (e: RPE, o: { x: number; y: number }) => {
    let dx = e.clientX - o.x, dy = e.clientY - o.y;
    const d = Math.hypot(dx, dy);
    if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
    setKnob({ x: dx, y: dy });
    const dead = 0.12;
    let nx = dx / R, ny = -dy / R;
    const m = Math.hypot(nx, ny);
    if (m < dead) { nx = 0; ny = 0; } else { const s = (m - dead) / (1 - dead) / m; nx *= s; ny *= s; }
    game.setStick(nx, ny);
  };

  return (
    <div
      className="absolute left-0 bottom-0 w-[44%] h-[62%] pointer-events-auto"
      style={{ touchAction: 'none' }}
      onPointerDown={(e) => {
        if (id.current !== null) return;
        id.current = e.pointerId;
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        const o = { x: e.clientX, y: e.clientY };
        setOrigin(o); setKnob({ x: 0, y: 0 });
      }}
      onPointerMove={(e) => { if (e.pointerId === id.current && origin) move(e, origin); }}
      onPointerUp={(e) => { if (e.pointerId === id.current) { id.current = null; setOrigin(null); game.setStick(0, 0); } }}
      onPointerCancel={(e) => { if (e.pointerId === id.current) { id.current = null; setOrigin(null); game.setStick(0, 0); } }}
    >
      {!origin && (
        <div className="absolute left-[18%] bottom-[16%] w-[104px] h-[104px] rounded-full glass opacity-40 flex items-center justify-center">
          <div className="w-10 h-10 rounded-full glass opacity-80" />
        </div>
      )}
      {origin && (
        <div
          className="fixed rounded-full glass opacity-70"
          style={{ width: R * 2 + 8, height: R * 2 + 8, left: origin.x - R - 4, top: origin.y - R - 4, pointerEvents: 'none' }}
        >
          <div
            className="absolute rounded-full"
            style={{
              width: 46, height: 46, left: R + 4 - 23 + knob.x, top: R + 4 - 23 + knob.y,
              background: 'radial-gradient(circle at 35% 30%, rgba(255,255,255,0.75), rgba(150,230,255,0.35))',
              boxShadow: '0 0 16px rgba(120,220,255,0.6)',
            }}
          />
        </div>
      )}
    </div>
  );
}

export function RoundButton({
  children, size = 54, onDown, onUp, onTap, active = false, label, pulse = false,
}: {
  children: ReactNode; size?: number; onDown?: () => void; onUp?: () => void; onTap?: () => void; active?: boolean; label?: string; pulse?: boolean;
}) {
  return (
    <button
      aria-label={label}
      className={`glass rounded-full flex items-center justify-center text-white pointer-events-auto transition-all duration-200 ${active ? 'bg-white/30 scale-95' : ''} ${pulse ? 'pulse-ring' : ''}`}
      style={{ width: size, height: size, touchAction: 'none', opacity: active ? 0.95 : 0.62 }}
      onPointerDown={(e) => { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); onDown?.(); onTap?.(); }}
      onPointerUp={() => onUp?.()}
      onPointerCancel={() => onUp?.()}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}
