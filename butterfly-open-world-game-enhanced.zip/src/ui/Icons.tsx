import type { ReactNode } from 'react';

const base = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;

function Svg({ children, size = 22 }: { children: ReactNode; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" {...base}>
      {children}
    </svg>
  );
}

export const IconUp = ({ size }: { size?: number }) => (<Svg size={size}><path d="M6 14l6-6 6 6" /></Svg>);
export const IconDown = ({ size }: { size?: number }) => (<Svg size={size}><path d="M6 10l6 6 6-6" /></Svg>);
export const IconBoost = ({ size }: { size?: number }) => (<Svg size={size}><path d="M6 12l6-6 6 6" /><path d="M6 19l6-6 6 6" /></Svg>);
export const IconGlide = ({ size }: { size?: number }) => (
  <Svg size={size}><path d="M3 12c3-5 6-5 9 0s6 5 9 0" /><path d="M5 17c2-2 4-2 7 0s5 2 7 0" opacity="0.6" /></Svg>
);
export const IconWings = ({ size }: { size?: number }) => (
  <Svg size={size}>
    <path d="M12 12c-2-5-5-7-8-7 0 4 2 7 8 7z" /><path d="M12 12c2-5 5-7 8-7 0 4-2 7-8 7z" />
    <path d="M12 12c-4 0-7 3-7 6 3 1 6-1 7-6z" /><path d="M12 12c4 0 7 3 7 6-3 1-6-1-7-6z" />
  </Svg>
);
export const IconFlower = ({ size }: { size?: number }) => (
  <Svg size={size}>
    <circle cx="12" cy="12" r="2.2" />
    <path d="M12 9.8C12 6 12 4 12 4s0 2-0 5.8M12 14.2c0 3.8 0 5.8 0 5.8M9.8 12C6 12 4 12 4 12M14.2 12c3.8 0 5.8 0 5.8 0" opacity="0.0" />
    <ellipse cx="12" cy="6.2" rx="2.2" ry="3.2" /><ellipse cx="12" cy="17.8" rx="2.2" ry="3.2" />
    <ellipse cx="6.2" cy="12" rx="3.2" ry="2.2" /><ellipse cx="17.8" cy="12" rx="3.2" ry="2.2" />
  </Svg>
);
export const IconLeaf = ({ size }: { size?: number }) => (
  <Svg size={size}><path d="M5 19C5 10 10 5 20 4c0 10-5 15-13 15" /><path d="M5 19c3-4 6-7 10-9" /></Svg>
);
export const IconMoon = ({ size }: { size?: number }) => (<Svg size={size}><path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z" /></Svg>);
export const IconSun = ({ size }: { size?: number }) => (
  <Svg size={size}><circle cx="12" cy="12" r="4" /><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4" /></Svg>
);
export const IconPause = ({ size }: { size?: number }) => (<Svg size={size}><path d="M9 6v12M15 6v12" /></Svg>);
export const IconNectar = ({ size }: { size?: number }) => (<Svg size={size}><path d="M12 3c4 5 6 8 6 11a6 6 0 01-12 0c0-3 2-6 6-11z" /></Svg>);
export const IconCloud = ({ size }: { size?: number }) => (<Svg size={size}><path d="M7 18a4 4 0 01-.5-8 5.5 5.5 0 0110.7 1A3.5 3.5 0 0117 18z" /></Svg>);
export const IconRain = ({ size }: { size?: number }) => (
  <Svg size={size}><path d="M7 14a4 4 0 01-.5-8 5.5 5.5 0 0110.7 1A3.5 3.5 0 0117 14z" /><path d="M9 17l-1 3M13 17l-1 3M17 17l-1 3" /></Svg>
);
export const IconWind = ({ size }: { size?: number }) => (<Svg size={size}><path d="M3 9h10a3 3 0 10-3-3M3 15h14a3 3 0 11-3 3M3 12h7" /></Svg>);
export const IconMist = ({ size }: { size?: number }) => (<Svg size={size}><path d="M4 9h16M6 13h14M4 17h12" /></Svg>);
export const IconFull = ({ size }: { size?: number }) => (<Svg size={size}><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" /></Svg>);
