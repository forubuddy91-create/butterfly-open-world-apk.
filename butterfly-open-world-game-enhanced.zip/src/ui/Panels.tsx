import type { ReactNode } from 'react';
import type { HudState, QualityName, Settings, WeatherMode } from '../game/config';
import { IconWings, IconCloud, IconFull, IconMist, IconRain, IconSun, IconWind } from './Icons';

export function Loading({ p, label }: { p: number; label: string }) {
  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center" style={{ background: 'radial-gradient(circle at 50% 40%, #12304a, #050c16)' }}>
      <div className="mb-2 text-cyan-200" style={{ filter: 'drop-shadow(0 0 12px #36c8ff)' }}><IconWings size={48} /></div>
      <div className="tracking-[0.5em] text-sm text-cyan-100/80 mb-6 uppercase">Butterfly</div>
      <div className="w-56 h-[3px] rounded bg-white/15 overflow-hidden">
        <div className="h-full rounded bg-gradient-to-r from-cyan-300 to-blue-400 transition-all duration-500" style={{ width: `${Math.round(p * 100)}%` }} />
      </div>
      <div className="mt-4 text-xs text-white/55 tracking-widest">{label}…</div>
    </div>
  );
}

function GlassBtn({ children, onClick, strong = false }: { children: ReactNode; onClick: () => void; strong?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`pointer-events-auto rounded-full px-8 py-3 text-sm tracking-[0.25em] uppercase transition-all active:scale-95 ${strong ? 'bg-white/25 border border-white/60 shadow-[0_0_30px_rgba(120,220,255,0.45)]' : 'glass'} hover:bg-white/30`}
    >
      {children}
    </button>
  );
}

export function MainMenu({ hasSave, onNew, onContinue, onSettings }: { hasSave: boolean; onNew: () => void; onContinue: () => void; onSettings: () => void }) {
  const full = () => {
    try {
      document.documentElement.requestFullscreen?.().then(() => (screen.orientation as unknown as { lock?: (o: string) => Promise<void> })?.lock?.('landscape').catch(() => {})).catch(() => {});
    } catch { /* not supported */ }
  };
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center pointer-events-none"
      style={{ background: 'radial-gradient(ellipse at 50% 55%, rgba(0,20,40,0) 20%, rgba(2,10,24,0.65) 100%)' }}>
      <div className="fade-up text-center">
        <div className="text-[11px] tracking-[0.7em] text-cyan-100/80 mb-2 uppercase soft-text">A life in flight</div>
        <h1 className="title-glow text-6xl sm:text-7xl font-extralight tracking-[0.28em] mr-[-0.28em]">BUTTERFLY</h1>
        <div className="mt-2 flex justify-center text-cyan-200 opacity-90" style={{ filter: 'drop-shadow(0 0 12px #36c8ff)' }}><IconWings size={34} /></div>
      </div>
      <div className="mt-8 flex flex-col items-center gap-3 fade-up" style={{ animationDelay: '0.3s' }}>
        <GlassBtn strong onClick={onNew}>{hasSave ? 'New Life' : 'Begin'}</GlassBtn>
        {hasSave && <GlassBtn onClick={onContinue}>Continue</GlassBtn>}
        <GlassBtn onClick={onSettings}>Settings</GlassBtn>
      </div>
      <button onClick={full} className="pointer-events-auto absolute right-4 top-4 glass rounded-full w-10 h-10 flex items-center justify-center opacity-70" aria-label="Fullscreen">
        <IconFull size={18} />
      </button>
      <div className="absolute bottom-4 text-[10px] tracking-[0.3em] text-white/45 uppercase soft-text">Best in landscape · headphones recommended</div>
    </div>
  );
}

function Slider({ label, value, min = 0, max = 1, step = 0.01, onChange, fmt }: { label: string; value: number; min?: number; max?: number; step?: number; onChange: (v: number) => void; fmt?: (v: number) => string }) {
  return (
    <label className="block">
      <div className="flex justify-between text-[11px] tracking-widest uppercase text-white/70 mb-1.5"><span>{label}</span><span>{fmt ? fmt(value) : Math.round(value * 100) + '%'}</span></div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    </label>
  );
}

const QUALS: { id: QualityName; label: string }[] = [
  { id: 'low', label: 'Low' }, { id: 'medium', label: 'Medium' }, { id: 'high', label: 'High' }, { id: 'ultra', label: 'Ultra' },
];
const WEATHERS: { id: WeatherMode; label: string; icon: ReactNode }[] = [
  { id: 'auto', label: 'Auto', icon: <IconSun size={15} /> }, { id: 'sunny', label: 'Sunny', icon: <IconSun size={15} /> },
  { id: 'cloudy', label: 'Cloudy', icon: <IconCloud size={15} /> }, { id: 'rain', label: 'Rain', icon: <IconRain size={15} /> },
  { id: 'windy', label: 'Wind', icon: <IconWind size={15} /> }, { id: 'mist', label: 'Mist', icon: <IconMist size={15} /> },
];
const TIMES = [{ l: 'Sunrise', h: 6.2 }, { l: 'Morning', h: 9 }, { l: 'Afternoon', h: 15 }, { l: 'Sunset', h: 18.2 }, { l: 'Night', h: 22.5 }];

export function fmtHour(h: number) {
  const hh = Math.floor(h), mm = Math.floor((h - hh) * 60);
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

export function SettingsPanel({ s, onChange, hour, onHour, onClose }: { s: Settings; onChange: (s: Settings) => void; hour: number; onHour: (h: number) => void; onClose: () => void }) {
  const chip = (on: boolean) => `pointer-events-auto rounded-full px-3.5 py-1.5 text-[11px] tracking-widest uppercase transition-all flex items-center gap-1.5 ${on ? 'bg-white/30 border border-white/70' : 'glass opacity-80'}`;
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-3 pointer-events-auto" style={{ background: 'rgba(2,10,20,0.45)' }}>
      <div className="glass-dark rounded-3xl w-full max-w-xl max-h-full overflow-y-auto p-5 fade-up" style={{ WebkitOverflowScrolling: 'touch' }}>
        <div className="flex items-center justify-between mb-4">
          <div className="tracking-[0.35em] uppercase text-sm text-cyan-100">Settings</div>
          <button onClick={onClose} className="glass rounded-full px-4 py-1.5 text-[11px] tracking-widest uppercase">Done</button>
        </div>

        <div className="text-[11px] tracking-widest uppercase text-white/55 mb-2">Graphics</div>
        <div className="flex flex-wrap gap-2 mb-1.5">
          {QUALS.map((q) => (<button key={q.id} className={chip(s.quality === q.id)} onClick={() => onChange({ ...s, quality: q.id })}>{q.label}</button>))}
        </div>
        <div className="text-[10px] text-white/40 mb-4">Same art direction at every level — higher presets add denser foliage, shadows, bloom and resolution. The world reloads when changed.</div>

        <div className="grid sm:grid-cols-2 gap-x-6 gap-y-4 mb-5">
          <Slider label="Music" value={s.music} onChange={(v) => onChange({ ...s, music: v })} />
          <Slider label="Nature" value={s.ambient} onChange={(v) => onChange({ ...s, ambient: v })} />
          <Slider label="Effects" value={s.sfx} onChange={(v) => onChange({ ...s, sfx: v })} />
          <Slider label="Camera" value={s.sensitivity} min={0.4} max={2.2} onChange={(v) => onChange({ ...s, sensitivity: v })} fmt={(v) => v.toFixed(1) + '×'} />
        </div>

        <div className="text-[11px] tracking-widest uppercase text-white/55 mb-2">Time of day · {fmtHour(hour)}</div>
        <Slider label="" value={hour} min={0} max={23.99} step={0.05} onChange={onHour} fmt={() => ''} />
        <div className="flex flex-wrap gap-2 mt-2.5 mb-4">
          {TIMES.map((t) => (<button key={t.l} className={chip(false)} onClick={() => onHour(t.h)}>{t.l}</button>))}
          <button className={chip(s.dayCycle)} onClick={() => onChange({ ...s, dayCycle: !s.dayCycle })}>Cycle {s.dayCycle ? 'on' : 'off'}</button>
        </div>

        <div className="text-[11px] tracking-widest uppercase text-white/55 mb-2">Weather</div>
        <div className="flex flex-wrap gap-2 mb-5">
          {WEATHERS.map((w) => (<button key={w.id} className={chip(s.weather === w.id)} onClick={() => onChange({ ...s, weather: w.id })}>{w.icon}{w.label}</button>))}
        </div>

        <div className="text-[10px] leading-relaxed text-white/45 tracking-wide">
          Touch: left thumb steers (↔ turn, ↑ forward) · drag anywhere else to look · ▲▼ climb/descend · glide ≈ rest wings · tap the glowing ring to land.
          <br />Keyboard: W/S forward/back · A/D turn · Space/C climb/descend · Shift boost · G glide · F land/take off · Z sleep · Esc pause · Mouse drag + wheel for camera.
        </div>
      </div>
    </div>
  );
}

export function PausePanel({ hud, onResume, onSettings, onMenu }: { hud: HudState; onResume: () => void; onSettings: () => void; onMenu: () => void }) {
  const Stat = ({ k, v }: { k: string; v: string }) => (
    <div className="text-center"><div className="text-xl font-light">{v}</div><div className="text-[10px] tracking-[0.25em] uppercase text-white/55">{k}</div></div>
  );
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-auto" style={{ background: 'rgba(2,10,20,0.5)' }}>
      <div className="glass-dark rounded-3xl px-8 py-6 fade-up flex flex-col items-center gap-4">
        <div className="tracking-[0.5em] uppercase text-sm text-cyan-100 mr-[-0.5em]">Resting</div>
        <div className="flex gap-8 my-1">
          <Stat k="Nectar" v={String(hud.nectar)} /><Stat k="Flowers" v={`${hud.flowerTypes}/8`} /><Stat k="Discoveries" v={`${hud.discoveries}/${hud.discoveryTotal}`} />
        </div>
        <GlassBtn strong onClick={onResume}>Resume</GlassBtn>
        <GlassBtn onClick={onSettings}>Settings</GlassBtn>
        <GlassBtn onClick={onMenu}>Main Menu</GlassBtn>
      </div>
    </div>
  );
}
