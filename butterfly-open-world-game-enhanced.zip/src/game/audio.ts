export interface AmbientParams {
  wind: number; rain: number; water: number; fall: number; night: number; foliage: number; open: number;
  daylight: number; speed: number; sleeping: boolean;
}

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

/** Fully procedural soundscape (no audio files): wind, water, rain, birds, insects and gentle generative music. */
export class AudioEngine {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicBus!: GainNode;
  private ambBus!: GainNode;
  private sfxBus!: GainNode;
  private reverb!: ConvolverNode;
  private noise!: AudioBuffer;
  private windG!: GainNode; private windF!: BiquadFilterNode;
  private leafG!: GainNode; private waterG!: GainNode; private fallG!: GainNode; private rainG!: GainNode;
  private cricketG!: GainNode; private cicadaG!: GainNode;
  private vols = { music: 0.5, ambient: 0.8, sfx: 0.7 };
  private birdT = 2;
  private chordT = 0;
  private chordI = 0;
  private bellT = 3;
  private t = 0;
  private lastFlap = 0;
  started = false;

  start() {
    if (this.started) { this.ctx?.resume(); return; }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.started = true;
    this.master = ctx.createGain(); this.master.gain.value = 0.9; this.master.connect(ctx.destination);
    this.musicBus = ctx.createGain(); this.ambBus = ctx.createGain(); this.sfxBus = ctx.createGain();
    this.musicBus.connect(this.master); this.ambBus.connect(this.master); this.sfxBus.connect(this.master);
    this.setVolumes(this.vols.music, this.vols.ambient, this.vols.sfx);

    // noise buffer
    const len = ctx.sampleRate * 3;
    this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + w * 0.099046; b1 = 0.963 * b1 + w * 0.2965164; b2 = 0.57 * b2 + w * 1.0526913;
      d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.2;
    }
    // reverb impulse
    const irLen = ctx.sampleRate * 3.2;
    const ir = ctx.createBuffer(2, irLen, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const ch = ir.getChannelData(c);
      for (let i = 0; i < irLen; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / irLen, 2.6);
    }
    this.reverb = ctx.createConvolver(); this.reverb.buffer = ir;
    const wet = ctx.createGain(); wet.gain.value = 0.55;
    this.reverb.connect(wet); wet.connect(this.musicBus);

    const loop = (type: BiquadFilterType, freq: number, q = 0.7, hp?: number) => {
      const src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
      src.loopStart = Math.random() * 1.5;
      const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
      const g = ctx.createGain(); g.gain.value = 0;
      src.connect(f);
      let last: AudioNode = f;
      if (hp) { const h = ctx.createBiquadFilter(); h.type = 'highpass'; h.frequency.value = hp; f.connect(h); last = h; }
      last.connect(g); g.connect(this.ambBus);
      src.start();
      return { g, f };
    };
    const wind = loop('bandpass', 520, 0.6); this.windG = wind.g; this.windF = wind.f;
    this.leafG = loop('highpass', 3200, 0.5).g;
    this.waterG = loop('bandpass', 900, 0.4, 250).g;
    this.fallG = loop('lowpass', 1100, 0.3, 90).g;
    this.rainG = loop('highpass', 1800, 0.4).g;

    // insects
    const mkInsect = (f: number, lfoF: number) => {
      const o = ctx.createOscillator(); o.frequency.value = f; o.type = 'sine';
      const env = ctx.createGain(); env.gain.value = 0.5;
      const lfo = ctx.createOscillator(); lfo.frequency.value = lfoF;
      const lg = ctx.createGain(); lg.gain.value = 0.5;
      lfo.connect(lg); lg.connect(env.gain);
      const out = ctx.createGain(); out.gain.value = 0;
      o.connect(env); env.connect(out); out.connect(this.ambBus);
      o.start(); lfo.start();
      return out;
    };
    this.cricketG = mkInsect(4300, 15);
    const c2 = mkInsect(3750, 11);
    c2.gain.value = 0;
    this.cicadaG = mkInsect(6100, 7);
    // second cricket shares control through a tiny tick
    (this as unknown as { c2: GainNode }).c2 = c2;
  }

  setVolumes(music: number, ambient: number, sfx: number) {
    this.vols = { music, ambient, sfx };
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.musicBus.gain.setTargetAtTime(music * 0.9, t, 0.1);
    this.ambBus.gain.setTargetAtTime(ambient, t, 0.1);
    this.sfxBus.gain.setTargetAtTime(sfx, t, 0.1);
  }

  suspend() { this.ctx?.suspend(); }
  resume() { this.ctx?.resume(); }

  private env(g: GainNode, t0: number, a: number, peak: number, r: number) {
    g.gain.cancelScheduledValues(t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(peak, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + r);
  }

  chirp(vol: number) {
    const ctx = this.ctx; if (!ctx || vol < 0.02) return;
    const n = 2 + Math.floor(Math.random() * 4);
    const base = 2200 + Math.random() * 2400;
    const pan = ctx.createStereoPanner(); pan.pan.value = Math.random() * 2 - 1;
    pan.connect(this.ambBus);
    let t = ctx.currentTime + 0.02;
    const kind = Math.random();
    for (let i = 0; i < n; i++) {
      const o = ctx.createOscillator(); o.type = 'sine';
      const g = ctx.createGain();
      const f0 = base * (1 + (i % 2) * 0.18 + Math.random() * 0.1);
      const dur = 0.07 + Math.random() * 0.08;
      o.frequency.setValueAtTime(f0, t);
      o.frequency.exponentialRampToValueAtTime(f0 * (kind < 0.5 ? 1.5 : 0.7), t + dur);
      this.env(g, t, 0.01, 0.07 * vol, dur);
      o.connect(g); g.connect(pan);
      o.start(t); o.stop(t + dur + 0.1);
      t += dur + 0.05 + Math.random() * 0.06;
    }
  }

  ribbit(vol: number) {
    const ctx = this.ctx; if (!ctx || vol < 0.02) return;
    let t = ctx.currentTime + 0.02;
    for (let i = 0; i < 2; i++) {
      const o = ctx.createOscillator(); o.type = 'sawtooth';
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 520; f.Q.value = 3;
      const g = ctx.createGain();
      o.frequency.setValueAtTime(190, t); o.frequency.exponentialRampToValueAtTime(130, t + 0.14);
      this.env(g, t, 0.02, 0.1 * vol, 0.13);
      o.connect(f); f.connect(g); g.connect(this.ambBus);
      o.start(t); o.stop(t + 0.3);
      t += 0.17;
    }
  }

  flap(strength: number) {
    const ctx = this.ctx; if (!ctx) return;
    const now = ctx.currentTime;
    if (now - this.lastFlap < 0.07) return;
    this.lastFlap = now;
    const src = ctx.createBufferSource(); src.buffer = this.noise;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1500 + Math.random() * 500; f.Q.value = 1.2;
    const g = ctx.createGain();
    this.env(g, now, 0.01, 0.05 * strength, 0.07);
    src.connect(f); f.connect(g); g.connect(this.sfxBus);
    src.start(now, Math.random() * 2, 0.15);
  }

  ding(pitch = 0) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    [mtof(84 + pitch), mtof(91 + pitch)].forEach((f, i) => {
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f;
      const g = ctx.createGain(); this.env(g, t + i * 0.08, 0.01, 0.07, 0.9);
      o.connect(g); g.connect(this.sfxBus); g.connect(this.reverb);
      o.start(t + i * 0.08); o.stop(t + 1.4);
    });
  }

  discover() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    [72, 76, 79, 83, 88].forEach((m, i) => {
      const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = mtof(m);
      const g = ctx.createGain(); this.env(g, t + i * 0.13, 0.02, 0.08, 2.2);
      o.connect(g); g.connect(this.sfxBus); g.connect(this.reverb);
      o.start(t + i * 0.13); o.stop(t + 3);
    });
  }

  private pad(notes: number[], t0: number, dur: number, gain: number) {
    const ctx = this.ctx!;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = 0.4;
    lp.connect(this.musicBus); lp.connect(this.reverb);
    notes.forEach((m, i) => {
      for (const det of [-6, 6]) {
        const o = ctx.createOscillator(); o.type = i % 2 ? 'triangle' : 'sine';
        o.frequency.value = mtof(m); o.detune.value = det;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.linearRampToValueAtTime(gain, t0 + dur * 0.4);
        g.gain.linearRampToValueAtTime(0.0001, t0 + dur + 3);
        o.connect(g); g.connect(lp);
        o.start(t0); o.stop(t0 + dur + 3.2);
      }
    });
  }

  private bell(m: number, vol: number) {
    const ctx = this.ctx!;
    const t = ctx.currentTime + 0.05;
    const pan = ctx.createStereoPanner(); pan.pan.value = Math.random() * 1.2 - 0.6;
    pan.connect(this.musicBus); pan.connect(this.reverb);
    for (const [mul, a] of [[1, 1], [2.005, 0.25], [3.01, 0.08]]) {
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = mtof(m) * mul;
      const g = ctx.createGain(); this.env(g, t, 0.008, 0.07 * vol * a, 3.2 / mul);
      o.connect(g); g.connect(pan);
      o.start(t); o.stop(t + 3.6);
    }
  }

  update(dt: number, p: AmbientParams) {
    const ctx = this.ctx; if (!ctx || ctx.state !== 'running') return;
    this.t += dt;
    const t = ctx.currentTime;
    const sl = p.sleeping ? 0.45 : 1;
    const wob = 0.75 + 0.25 * Math.sin(this.t * 0.37) * Math.sin(this.t * 0.91 + 1);
    this.windG.gain.setTargetAtTime((0.04 + 0.5 * p.wind) * wob * sl, t, 0.3);
    this.windF.frequency.setTargetAtTime(280 + 700 * p.wind + 120 * Math.sin(this.t * 0.5), t, 0.3);
    this.leafG.gain.setTargetAtTime(p.foliage * (0.02 + 0.2 * p.wind) * wob * sl, t, 0.3);
    this.waterG.gain.setTargetAtTime(p.water * 0.3 * sl, t, 0.4);
    this.fallG.gain.setTargetAtTime(p.fall * 0.6 * sl, t, 0.4);
    this.rainG.gain.setTargetAtTime(p.rain * 0.28 * sl, t, 0.6);
    const quiet = 1 - p.rain * 0.8;
    const cr = p.night * quiet * 0.025 * sl;
    this.cricketG.gain.setTargetAtTime(cr, t, 0.8);
    ((this as unknown as { c2: GainNode }).c2).gain.setTargetAtTime(cr * 0.8, t, 0.8);
    this.cicadaG.gain.setTargetAtTime(p.daylight * (1 - p.night) * quiet * p.foliage * 0.012 * sl, t, 0.8);

    // birds in the distance
    this.birdT -= dt;
    if (this.birdT <= 0) {
      this.birdT = 1.5 + Math.random() * 5;
      const v = (1 - p.night) * p.daylight * quiet * (0.2 + 0.8 * Math.min(1, p.foliage + p.open)) * 0.7;
      if (v > 0.05 && !p.sleeping) this.chirp(v);
    }

    // generative music
    this.chordT -= dt;
    const night = p.night > 0.5;
    if (this.chordT <= 0) {
      const dayChords = [[48, 55, 59, 64, 71], [45, 52, 59, 64, 67], [53, 57, 60, 64, 69], [43, 50, 59, 64, 69]];
      const nightChords = [[45, 52, 60, 64, 67], [41, 48, 57, 60, 64], [48, 55, 59, 64, 67], [40, 47, 55, 59, 62]];
      const set = night ? nightChords : dayChords;
      this.chordI = (this.chordI + 1) % set.length;
      this.pad(set[this.chordI], t + 0.05, 8.5, p.sleeping ? 0.016 : 0.026);
      this.chordT = 8.5;
    }
    this.bellT -= dt;
    if (this.bellT <= 0) {
      const scale = night ? [69, 72, 74, 76, 79, 81] : [72, 74, 76, 79, 81, 84];
      const base = this.chordI;
      this.bell(scale[Math.floor(Math.random() * scale.length)] + (base % 2 ? -12 : 0), p.sleeping ? 0.5 : 1);
      this.bellT = 1.6 + Math.random() * 4.2;
    }
  }
}
