import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import {
  QUALITY, QualityCfg, Settings, HudState, SaveData, RegionId, REGION_INFO, START_SITE, WeatherMode, HALF,
} from './config';
import { World, regionWeights, REGION_IDS, LAKE } from './terrain';
import { Vegetation, FLOWER_H, FLOWER_TYPES } from './vegetation';
import { Atmosphere } from './sky';
import { Butterfly, BLUE, Sparkles } from './butterfly';
import { Wildlife } from './wildlife';
import { AudioEngine } from './audio';
import { U } from './shared';
import { clamp, angleDiff, lerp, smoothstep } from './noise';

const SAVE_KEY = 'butterfly.save.v1';
const MODEL_SCALE = 0.34;
const LEG = 0.12;

type Mode = 'fly' | 'landing' | 'perched';
interface LandTarget { kind: 'feed' | 'rest' | 'ground'; pos: THREE.Vector3; type: number }

const POIS = [
  { id: 'gate', name: 'Mossy Gateway', x: -262, z: 168, r: 24 },
  { id: 'pond', name: 'Frog Pond', x: -140, z: 238, r: 30 },
  { id: 'mill', name: 'Windmill Hill', x: 262, z: 262, r: 26 },
  { id: 'golden', name: 'Golden Arch', x: 236, z: 190, r: 24 },
  { id: 'ridge', name: 'Wildflower Ridge', x: 150, z: 118, r: 26 },
  { id: 'broken', name: 'Broken Gate', x: 172, z: -150, r: 26 },
  { id: 'summit', name: 'Summit Shrine', x: 266, z: -276, r: 22 },
  { id: 'hollow', name: 'Mist Hollow', x: 120, z: -215, r: 28 },
  { id: 'falls', name: 'Crystal Falls', x: -205, z: -322, r: 32 },
  { id: 'heart', name: 'Heart Lake', x: LAKE.x, z: LAKE.z + 10, r: 32 },
  { id: 'bridge', name: 'Old Stone Bridge', x: 0, z: 0, r: 22 },
  { id: 'sky', name: 'Garden Above the Falls', x: -205, z: -365, r: 22 },
];

export interface GameCallbacks {
  onHud: (h: HudState) => void;
  onProgress: (p: number, label: string) => void;
}

const nextFrame = () => new Promise<void>((r) => setTimeout(r, 10));

export class Game {
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(62, 1, 0.05, 2600);
  composer: EffectComposer | null = null;
  bloom: UnrealBloomPass | null = null;
  q!: QualityCfg;
  world!: World;
  veg!: Vegetation;
  atmos!: Atmosphere;
  wildlife!: Wildlife;
  bf!: Butterfly;
  sparkles!: Sparkles;
  audio = new AudioEngine();

  state: 'loading' | 'menu' | 'intro' | 'play' | 'paused' = 'loading';
  private prevState: 'menu' | 'intro' | 'play' = 'menu';
  private clock = new THREE.Clock();
  private time = 0;
  private disposed = false;

  // player
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  yaw = 0;
  pitchV = 0;
  rollV = 0;
  mode: Mode = 'fly';
  glide = false;
  takeoffT = 0;
  landTarget: LandTarget | null = null;
  activeTarget: LandTarget | null = null;
  feeding = 0;
  feedTimer = 0;
  sleeping = false;
  perchYaw = 0;

  // input
  stick = { x: 0, y: 0 };
  keys = new Set<string>();
  holds = { up: false, down: false, boost: false };
  private pointers = new Map<number, { x: number; y: number }>();
  private lastCamInput = -10;
  private camUserYaw = 0;
  private camUserPitch = 0;
  private zoom = 1;

  // camera
  private camHead = 0;
  private camLook = new THREE.Vector3();
  private camPos = new THREE.Vector3();
  private fovBoost = 62;
  private introBlend = 1;
  private cinePos = new THREE.Vector3();
  private cineLook = new THREE.Vector3();

  // intro
  private introT = 0;
  private chry!: THREE.Group;
  private halfA!: THREE.Mesh;
  private halfB!: THREE.Mesh;
  private shellMat!: THREE.MeshStandardMaterial;
  private site = new THREE.Vector3();
  private introDone = false;

  // progress
  nectar = 0;
  discovered = new Set<string>();
  flowerTypes = new Set<string>();
  private metColors = new Set<number>();
  private poiT = 0;
  private landT = 0;
  private hudT = 0;
  private saveT = 0;
  private regionNow: RegionId = 'forest';
  private regionTitle: string | null = null;
  private regionTitleT = 0;
  private toastMsg: string | null = null;
  private toastT = 0;
  private waterNearV = { water: 0, fall: 0 };
  private waterT = 0;
  private nightHintShown = false;
  private lastFlapCycle = 0;
  private sparkAcc = 0;

  // misc
  private marker: HTMLDivElement;
  private minimap: HTMLCanvasElement | null = null;
  private mapBase: HTMLCanvasElement | null = null;
  private mapT = 0;
  private fpsAcc = 0;
  private fpsN = 0;
  private fpsLow = 0;
  private pixelRatio = 1;
  private tmpV = new THREE.Vector3();

  constructor(private container: HTMLElement, public settings: Settings, private cb: GameCallbacks) {
    this.marker = document.createElement('div');
    this.marker.style.cssText =
      'position:absolute;left:0;top:0;width:44px;height:44px;margin:-22px 0 0 -22px;border-radius:50%;pointer-events:none;display:none;' +
      'border:1.5px solid rgba(255,255,255,0.75);background:radial-gradient(circle,rgba(255,255,255,0.22),rgba(255,255,255,0.04));' +
      'box-shadow:0 0 18px rgba(160,230,255,0.55);font-size:18px;line-height:41px;text-align:center;color:white;will-change:transform;';
    container.appendChild(this.marker);
  }

  /* ------------------------------------------------------------ setup */

  async init() {
    const r = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', stencil: false });
    this.renderer = r;
    r.toneMapping = THREE.NeutralToneMapping;
    r.toneMappingExposure = 1.0;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;touch-action:none;display:block;';
    this.container.insertBefore(r.domElement, this.container.firstChild);
    this.bindInput();
    await this.buildWorld();
    if (this.disposed) return;
    this.state = 'menu';
    this.resetMenuCam();
    this.clock.start();
    r.setAnimationLoop(() => this.tick());
  }

  private async buildWorld() {
    const P = (p: number, l: string) => this.cb.onProgress(p, l);
    this.state = 'loading';
    // tear down previous world
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
    this.scene.clear();
    this.scene.fog = null;
    this.q = QUALITY[this.settings.quality];
    const q = this.q;
    P(0.04, 'Shaping the land');
    await nextFrame();
    this.world = new World(q.terrainSeg);
    this.world.build(this.scene);
    P(0.3, 'Growing forests and flowers');
    await nextFrame();
    this.atmos = new Atmosphere(this.scene, q, this.world);
    this.atmos.setMode(this.settings.weather);
    this.veg = new Vegetation(this.world, q);
    this.scene.add(this.veg.group);
    P(0.62, 'Waking the wildlife');
    await nextFrame();
    this.site.set(START_SITE.x, this.world.heightAt(START_SITE.x, START_SITE.z), START_SITE.z);
    this.bf = new Butterfly(BLUE, false, q.glowLight);
    this.bf.model.scale.setScalar(MODEL_SCALE);
    this.scene.add(this.bf.group);
    this.sparkles = new Sparkles(160);
    this.scene.add(this.sparkles.points);
    this.wildlife = new Wildlife(this.world, this.veg, q, {
      chirp: (v) => this.audio.chirp(v),
      ribbit: (v) => this.audio.ribbit(v),
      meet: (i) => this.onMeet(i),
    }, this.site);
    this.scene.add(this.wildlife.group);
    this.buildIntroSet();
    this.buildMinimapBase();
    P(0.9, 'Painting the sky');
    await nextFrame();
    this.setupComposer();
    this.onResize();
    P(1, 'Ready');
  }

  private setupComposer() {
    const r = this.renderer;
    this.pixelRatio = Math.min(window.devicePixelRatio || 1, this.q.pixelRatio);
    r.setPixelRatio(this.pixelRatio);
    const w = this.container.clientWidth || window.innerWidth, h = this.container.clientHeight || window.innerHeight;
    r.setSize(w, h, false);
    r.shadowMap.enabled = this.q.shadowMap > 0;
    try {
      const hasFloat = r.extensions.has('EXT_color_buffer_float') || r.extensions.has('EXT_color_buffer_half_float');
      const rt = new THREE.WebGLRenderTarget(w * this.pixelRatio, h * this.pixelRatio, {
        type: hasFloat ? THREE.HalfFloatType : THREE.UnsignedByteType, samples: this.q.msaa,
      });
      const comp = new EffectComposer(r, rt);
      comp.setPixelRatio(this.pixelRatio);
      comp.setSize(w, h);
      comp.addPass(new RenderPass(this.scene, this.camera));
      this.bloom = null;
      if (this.q.bloom > 0) {
        this.bloom = new UnrealBloomPass(new THREE.Vector2(w, h), this.q.bloom, 0.55, 1.0);
        comp.addPass(this.bloom);
      }
      comp.addPass(new OutputPass());
      this.composer = comp;
    } catch (e) {
      console.warn('Post-processing unavailable', e);
      this.composer = null;
    }
  }

  async applySettings(s: Settings) {
    const old = this.settings;
    this.settings = s;
    this.audio.setVolumes(s.music, s.ambient, s.sfx);
    this.atmos?.setMode(s.weather);
    if (old.quality !== s.quality) {
      const st = this.state === 'paused' ? this.prevState : this.state;
      const keep = { pos: this.pos.clone(), yaw: this.yaw, hour: this.atmos.hour };
      await this.buildWorld();
      this.atmos.hour = keep.hour;
      this.pos.copy(keep.pos); this.yaw = keep.yaw;
      this.prevState = st === 'loading' ? 'menu' : st;
      this.state = 'paused';
      if (this.prevState === 'intro') { this.introT = 0; this.introDone = false; }
      if (this.prevState === 'menu') this.resetMenuCam();
      this.bf.group.visible = this.prevState !== 'menu';
    }
  }

  private buildMinimapBase() {
    const S = 256;
    const c = document.createElement('canvas');
    c.width = c.height = S;
    const g = c.getContext('2d')!;
    const img = g.createImageData(S, S);
    const w = [0, 0, 0, 0];
    for (let j = 0; j < S; j++) for (let i = 0; i < S; i++) {
      const x = -HALF + (i / S) * 1000, z = -HALF + (j / S) * 1000;
      const h = this.world.heightAt(x, z);
      regionWeights(x, z, w);
      let r: number, gg: number, b: number;
      if (h < 0) { const d = clamp(-h / 10, 0, 1); r = 60 - d * 30; gg = 150 - d * 50; b = 190 - d * 30; }
      else {
        const m = clamp(h / 120, 0, 1);
        r = 70 + w[1] * 80 + m * 90; gg = 120 + w[0] * -20 + w[1] * 40 - m * 20 + m * 30; b = 60 + m * 90;
        const hx = this.world.heightAt(x + 4, z) - this.world.heightAt(x - 4, z);
        const sh = clamp(1 + hx * 0.05, 0.6, 1.4);
        r *= sh; gg *= sh; b *= sh;
      }
      const k = (j * S + i) * 4;
      img.data[k] = r; img.data[k + 1] = gg; img.data[k + 2] = b; img.data[k + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    this.mapBase = c;
    POIS.find((p) => p.id === 'bridge')!.x = this.veg.bridgePos.x;
    POIS.find((p) => p.id === 'bridge')!.z = this.veg.bridgePos.z;
  }

  attachMinimap(c: HTMLCanvasElement | null) { this.minimap = c; }

  /* ------------------------------------------------------------ intro set */

  private buildIntroSet() {
    const g = new THREE.Group();
    g.position.copy(this.site);
    const green = new THREE.MeshLambertMaterial({ color: '#4d8a2a', side: THREE.DoubleSide });
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.1, 0), new THREE.Vector3(0.06, 0.5, 0.0), new THREE.Vector3(0.02, 1.0, 0.04),
      new THREE.Vector3(0.22, 1.42, 0.0), new THREE.Vector3(0.7, 1.6, 0),
    ]);
    const stem = new THREE.Mesh(new THREE.TubeGeometry(curve, 24, 0.024, 6), new THREE.MeshLambertMaterial({ color: '#58862e' }));
    stem.castShadow = true;
    g.add(stem);
    const leafShape = (L: number, W: number) => {
      const sh = new THREE.Shape();
      sh.moveTo(0, 0);
      sh.bezierCurveTo(0.55 * W, 0.15 * L, 0.6 * W, 0.65 * L, 0, L);
      sh.bezierCurveTo(-0.6 * W, 0.65 * L, -0.55 * W, 0.15 * L, 0, 0);
      const geo = new THREE.ShapeGeometry(sh, 8);
      geo.rotateX(-Math.PI / 2);
      return geo;
    };
    const lg = leafShape(0.9, 0.5), lg2 = leafShape(0.6, 0.34);
    const cols = ['#58a02c', '#6cb232', '#4a9026', '#7cc03a'];
    for (let i = 0; i < 9; i++) {
      const t = 0.12 + (i / 9) * 0.7;
      const p = curve.getPoint(t);
      const m = new THREE.Mesh(i % 3 ? lg : lg2, new THREE.MeshLambertMaterial({ color: cols[i % 4], side: THREE.DoubleSide }));
      m.position.copy(p);
      m.rotation.set(0.25 + (i % 2) * 0.2, i * 2.4, 0, 'YXZ');
      m.scale.setScalar(0.9 + (i % 3) * 0.25);
      m.castShadow = true;
      g.add(m);
    }
    // twig-top leaf hanging above the chrysalis
    const top = new THREE.Mesh(lg, green);
    top.position.set(0.5, 1.58, 0); top.rotation.set(0.5, 1.2, 0); top.scale.setScalar(1.1);
    top.castShadow = true;
    g.add(top);
    // mossy rock
    const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(0.55, 1), new THREE.MeshLambertMaterial({ color: '#7d786c', flatShading: true }));
    rock.scale.set(1.5, 0.8, 1.1); rock.position.set(-0.95, 0.12, 0.45); rock.rotation.y = 0.6;
    rock.castShadow = true; rock.receiveShadow = true;
    const moss = new THREE.Mesh(new THREE.SphereGeometry(0.5, 10, 6), new THREE.MeshLambertMaterial({ color: '#5a9a30' }));
    moss.scale.set(1.25, 0.28, 0.9); moss.position.set(-0.95, 0.46, 0.45); moss.rotation.y = 0.6;
    g.add(rock, moss);

    // chrysalis
    this.chry = new THREE.Group();
    this.chry.position.set(0.7, 1.6, 0);
    this.chry.rotation.z = 0.1;
    const pts = [[0, 0], [0.012, -0.02], [0.04, -0.06], [0.075, -0.14], [0.092, -0.22], [0.086, -0.3], [0.062, -0.38], [0.03, -0.435], [0.0, -0.46]]
      .map((p) => new THREE.Vector2(p[0], p[1]));
    this.shellMat = new THREE.MeshStandardMaterial({
      color: '#86cc58', roughness: 0.28, metalness: 0.1, emissive: '#143a10', emissiveIntensity: 0.35, side: THREE.DoubleSide, transparent: true,
    });
    const mkHalf = (start: number) => {
      const m = new THREE.Mesh(new THREE.LatheGeometry(pts, 22, start, Math.PI), this.shellMat);
      m.castShadow = true;
      const gold = new THREE.MeshStandardMaterial({ color: '#ffd24a', metalness: 0.9, roughness: 0.2, emissive: '#6a4a00', emissiveIntensity: 0.6 });
      for (let i = 0; i < 4; i++) {
        const k = 3 + i, a = start + Math.PI * (0.25 + 0.5 * ((i * 37) % 10) / 10);
        const s = new THREE.Mesh(new THREE.SphereGeometry(0.008, 6, 4), gold);
        s.position.set(Math.sin(a) * pts[k].x, pts[k].y, Math.cos(a) * pts[k].x);
        m.add(s);
      }
      return m;
    };
    this.halfA = mkHalf(0);
    this.halfB = mkHalf(Math.PI);
    this.chry.add(this.halfA, this.halfB);
    const pad = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.06, 6), new THREE.MeshLambertMaterial({ color: '#d8c8a0' }));
    pad.position.y = 0.03; pad.rotation.z = Math.PI;
    this.chry.add(pad);
    g.add(this.chry);
    this.scene.add(g);
  }

  /* ------------------------------------------------------------ public controls */

  hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch { return false; } }

  startNew() {
    this.audio.start();
    this.audio.setVolumes(this.settings.music, this.settings.ambient, this.settings.sfx);
    this.nectar = 0; this.discovered.clear(); this.flowerTypes.clear();
    this.atmos.hour = 7.3;
    this.introT = 0; this.introDone = false; this.introBlend = 0;
    this.state = 'intro';
    this.bf.group.visible = true;
    this.bf.model.scale.setScalar(MODEL_SCALE);
    this.mode = 'fly';
    this.landTarget = null;
    this.camUserYaw = 0; this.camUserPitch = 0;
    this.pos.copy(this.site);
  }

  continueGame() {
    let s: SaveData | null = null;
    try { s = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null'); } catch { s = null; }
    if (!s) { this.startNew(); return; }
    this.audio.start();
    this.audio.setVolumes(this.settings.music, this.settings.ambient, this.settings.sfx);
    this.nectar = s.nectar || 0;
    this.discovered = new Set(s.discovered || []);
    this.flowerTypes = new Set(s.flowerTypes || []);
    this.atmos.hour = s.hour ?? 8;
    this.pos.set(s.x, Math.max(s.y, this.world.heightAt(s.x, s.z) + 1.5), s.z);
    this.yaw = s.yaw || 0;
    this.beginPlay(true);
  }

  private beginPlay(fromSave: boolean) {
    this.state = 'play';
    this.mode = 'fly';
    this.vel.set(0, 0, 0);
    this.glide = false;
    this.bf.group.visible = true;
    this.bf.model.scale.setScalar(MODEL_SCALE);
    this.camHead = this.yaw;
    this.camPos.copy(this.pos).add(this.tmpV.set(-Math.sin(this.yaw) * 3, 1.2, -Math.cos(this.yaw) * 3));
    this.camLook.copy(this.pos);
    this.introBlend = fromSave ? 1 : 0;
    this.takeoffT = fromSave ? 0 : 1;
    this.bf.group.rotation.set(0, this.yaw, 0);
    this.regionNow = this.world.regionAt(this.pos.x, this.pos.z);
    this.regionTitle = REGION_INFO[this.regionNow].name; this.regionTitleT = 5;
    this.toast(fromSave ? 'Welcome back' : 'Fly freely — explore the world', 4500);
  }

  pause() {
    if (this.state === 'play' || this.state === 'intro' || this.state === 'menu') {
      this.prevState = this.state;
      this.state = 'paused';
      this.saveGame();
    }
  }
  resume() { if (this.state === 'paused') { this.state = this.prevState; this.clock.getDelta(); this.audio.resume(); } }
  toMenu() {
    this.saveGame();
    this.state = 'menu';
    this.bf.group.visible = false;
    this.sleeping = false;
    this.resetMenuCam();
  }
  get inMenu() { return this.state === 'menu'; }

  skipIntro() {
    if (this.state === 'intro' && this.introT < 40) this.introT = 41.5;
  }

  setHour(h: number) { this.atmos.hour = h; }
  setStick(x: number, y: number) { this.stick.x = x; this.stick.y = y; }
  setHold(name: 'up' | 'down' | 'boost', v: boolean) { this.holds[name] = v; }
  toggleGlide() {
    if (this.state !== 'play' || this.mode !== 'fly') return;
    this.glide = !this.glide;
  }
  action() {
    if (this.state !== 'play') return;
    if (this.sleeping) { this.wake(false); return; }
    if (this.mode === 'fly' && this.landTarget) this.startLanding(this.landTarget);
    else if (this.mode === 'landing' || this.mode === 'perched') this.takeOff();
  }
  sleep() {
    if (this.state !== 'play' || this.mode !== 'perched') return;
    if (this.atmos.night < 0.4 && this.atmos.hour > 6 && this.atmos.hour < 19) return;
    this.sleeping = true;
    this.toast('Sweet dreams…', 2500);
  }
  private wake(natural: boolean) {
    this.sleeping = false;
    if (natural) this.toast('A new day begins', 4000);
    this.saveGame();
  }

  private startLanding(t: LandTarget) {
    this.activeTarget = { kind: t.kind, pos: t.pos.clone(), type: t.type };
    this.mode = 'landing';
    this.glide = false;
    this.feeding = 0; this.feedTimer = 0;
  }

  private takeOff() {
    this.mode = 'fly';
    this.sleeping = false;
    this.takeoffT = 1;
    this.feeding = 0;
    this.vel.set(Math.sin(this.yaw) * 1.5, 2.6, Math.cos(this.yaw) * 1.5);
    this.pos.y += 0.05;
  }

  private onMeet(idx: number) {
    if (this.state !== 'play' || this.metColors.has(idx)) return;
    this.metColors.add(idx);
    this.toast('A fellow butterfly flutters by', 3000);
  }

  toast(msg: string, ms = 3500) { this.toastMsg = msg; this.toastT = ms / 1000; }

  saveGame() {
    if (this.state === 'loading' || this.state === 'menu') return;
    if (this.introT < 40 && this.state === 'intro') return;
    try {
      const s: SaveData = {
        x: this.pos.x, y: this.pos.y, z: this.pos.z, yaw: this.yaw, hour: this.atmos.hour, nectar: this.nectar,
        discovered: [...this.discovered], flowerTypes: [...this.flowerTypes],
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(s));
    } catch { /* storage unavailable */ }
  }

  /* ------------------------------------------------------------ input */

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    const k = e.key.toLowerCase();
    this.keys.add(k);
    if (this.state === 'menu') return;
    if (k === 'f' || k === 'e' || k === 'enter') this.action();
    if (k === 'g') this.toggleGlide();
    if (k === 'z') this.sleep();
    if (k === 'escape' || k === 'p') { if (this.state === 'paused') this.resume(); else this.pause(); this.cb.onHud(this.buildHud()); }
  };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.key.toLowerCase()); };
  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth, h = this.container.clientHeight || window.innerHeight;
    if (!this.renderer) return;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.composer?.setSize(w, h);
    this.atmos?.setViewHeight(h * this.pixelRatio);
    this.sparkles?.setViewHeight(h * this.pixelRatio);
  };
  private onVis = () => {
    if (document.hidden) { this.audio.suspend(); if (this.state === 'play') { this.pause(); this.cb.onHud(this.buildHud()); } }
    else if (this.state !== 'paused') this.audio.resume();
  };

  private bindInput() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    document.addEventListener('visibilitychange', this.onVis);
    const el = this.renderer.domElement;
    el.addEventListener('pointerdown', (e) => {
      el.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    });
    el.addEventListener('pointermove', (e) => {
      const p = this.pointers.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      if (this.state === 'play' || this.state === 'intro') this.rotateCam(dx, dy);
    });
    const up = (e: PointerEvent) => { this.pointers.delete(e.pointerId); };
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('wheel', (e) => {
      this.zoom = clamp(this.zoom * (1 + Math.sign(e.deltaY) * 0.08), 0.6, 2);
    }, { passive: true });
  }

  rotateCam(dx: number, dy: number) {
    const k = 0.0052 * this.settings.sensitivity;
    this.camUserYaw -= dx * k;
    this.camUserPitch = clamp(this.camUserPitch + dy * k * 0.8, -0.7, 1.1);
    this.lastCamInput = this.time;
  }

  /* ------------------------------------------------------------ frame */

  private tick() {
    if (this.disposed || this.state === 'loading') return;
    let dt = Math.min(this.clock.getDelta(), 0.05);
    if (this.state === 'paused') dt = 0;
    else {
      this.fpsAcc += dt; this.fpsN++;
      if (this.fpsAcc > 3) {
        const fps = this.fpsN / this.fpsAcc;
        this.fpsAcc = 0; this.fpsN = 0;
        if (fps < 38 && this.pixelRatio > 0.65) { this.fpsLow++; if (this.fpsLow >= 1) { this.pixelRatio = Math.max(0.6, this.pixelRatio - 0.15); this.applyRatio(); this.fpsLow = 0; } }
        else this.fpsLow = 0;
      }
    }
    this.time += dt;
    if (dt > 0) this.simulate(dt);
    if (this.composer) this.composer.render(dt); else this.renderer.render(this.scene, this.camera);
  }

  private applyRatio() {
    this.renderer.setPixelRatio(this.pixelRatio);
    this.composer?.setPixelRatio(this.pixelRatio);
    this.onResize();
  }

  private simulate(dt: number) {
    const st = this.state;
    let timeScale = this.settings.dayCycle ? 1 : 0;
    if (this.sleeping) timeScale = 55;
    if (st === 'intro') timeScale = 0;
    if (st === 'menu') timeScale = 0.35;

    if (st === 'menu') this.updateMenuCam(dt);
    else if (st === 'intro') this.updateIntro(dt);
    else if (st === 'play') this.updatePlay(dt);

    const focus = st === 'intro' ? this.site : this.pos;
    const camP = this.camera.position;
    const rw = regionWeights(camP.x, camP.z);
    this.atmos.update(dt, camP, focus, rw, timeScale);
    this.veg.update(dt, st === 'menu' ? this.camera.position : focus, U.uWind.value);
    this.world.update(dt, this.atmos.daylight);
    this.wildlife.update(dt, st === 'menu' ? this.camera.position : focus);
    this.sparkles.update(dt);
    if (this.bf.light) this.bf.light.intensity = 1.6 + this.atmos.night * 2.2;

    // ambient audio
    this.waterT -= dt;
    if (this.waterT <= 0) { this.waterT = 0.25; this.waterNearV = this.world.waterNear(camP.x, camP.z); }
    this.audio.update(dt, {
      wind: U.uWind.value, rain: this.atmos.cur.rain, water: this.waterNearV.water, fall: this.waterNearV.fall,
      night: this.atmos.night, foliage: clamp(rw[0] + rw[2] * 0.6 + rw[3] * 0.3, 0, 1), open: clamp(rw[1] + rw[3] * 0.5, 0, 1),
      daylight: this.atmos.daylight, speed: this.vel.length(), sleeping: this.sleeping,
    });

    // timers & hud
    this.toastT -= dt; if (this.toastT <= 0) this.toastMsg = null;
    this.regionTitleT -= dt; if (this.regionTitleT <= 0) this.regionTitle = null;
    this.updateMarker();
    this.hudT -= dt;
    if (this.hudT <= 0) { this.hudT = 0.2; this.cb.onHud(this.buildHud()); }
    this.mapT -= dt;
    if (this.mapT <= 0) { this.mapT = 0.12; this.drawMinimap(); }
    if (st === 'play') {
      this.saveT += dt;
      if (this.saveT > 20) { this.saveT = 0; this.saveGame(); }
    }
  }

  /* ------------------------------------------------------------ menu camera */

  private resetMenuCam() {
    this.bf.group.visible = false;
    this.time = 0;
  }

  private updateMenuCam(dt: number) {
    void dt;
    const a = this.time * 0.045 + 0.6;
    const cx = START_SITE.x + 30, cz = START_SITE.z - 20;
    const R = 85;
    const x = cx + Math.cos(a) * R, z = cz + Math.sin(a) * R;
    const y = Math.max(this.world.heightAt(x, z) + 17, 20) + Math.sin(this.time * 0.2) * 1.5;
    this.camera.position.set(x, y, z);
    this.camera.lookAt(START_SITE.x - 30, this.world.heightAt(START_SITE.x, START_SITE.z) + 2, START_SITE.z + 20);
    this.camera.fov = 58; this.camera.updateProjectionMatrix();
    this.pos.set(cx, 10, cz);
  }

  /* ------------------------------------------------------------ intro (emergence) */

  private ease(t: number) { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); }
  private seg(t: number, a: number, b: number) { return clamp((t - a) / (b - a), 0, 1); }

  private updateIntro(dt: number) {
    this.introT += dt;
    const T = this.introT, e = this.ease.bind(this), sg = this.seg.bind(this);
    const bf = this.bf;
    const chryW = this.tmpV.copy(this.chry.position).add(this.site);
    const cx = chryW.x, cy = chryW.y, cz = chryW.z;
    this.atmos.hour = 7.3 + Math.min(T, 45) * 0.002;

    // chrysalis sway & colour
    const sway = Math.sin(T * 1.3) * 0.03 * (1 - sg(T, 10, 16));
    this.chry.rotation.z = 0.1 + sway;
    const dark = sg(T, 4.5, 9);
    this.shellMat.color.set('#86cc58').lerp(new THREE.Color('#1e3a6a'), dark);
    this.shellMat.emissive.set('#143a10').lerp(new THREE.Color('#1060c0'), dark);
    this.shellMat.emissiveIntensity = 0.35 + dark * 0.9 * (0.7 + 0.3 * Math.sin(T * 5));
    this.shellMat.opacity = 1 - dark * 0.42 - sg(T, 18, 24) * 0.0;
    // crack
    const open = e(sg(T, 10.5, 16)) * 0.62;
    const shake = (T > 10 && T < 16) ? Math.sin(T * 40) * 0.012 * (1 - sg(T, 14, 16)) : 0;
    this.halfA.rotation.z = open + shake;
    this.halfB.rotation.z = -open - shake;

    // butterfly pose while emerging
    const emerge = e(sg(T, 14.5, 21));
    const settle = e(sg(T, 21, 24));
    const expand = e(sg(T, 22.5, 36));
    const pump = Math.sin(T * 2.4) * 0.03 * (1 - expand) * sg(T, 22.5, 40);
    const hangX = cx + 0.0, hangZ = cz + lerp(0.0, 0.07, settle);
    const yIn = cy - 0.24, yOut = cy - 0.56;
    const by = lerp(yIn, yOut, emerge) + (settle > 0 ? 0 : 0);
    const flightLift = e(sg(T, 41.5, 46));
    bf.group.visible = T > 7;

    // wings: crumpled → fully expanded, wet → dry
    const dry = e(sg(T, 27, 39));
    const quiver = sg(T, 34, 41);
    const hang = T < 41 ? 1 - 0.1 * quiver * (0.5 + 0.5 * Math.sin(T * 6)) * (0.5 + quiver) : 1 - e(sg(T, 41, 43.5));
    const tilt = -Math.PI / 2 * (1 - e(sg(T, 42, 44.5)));
    const flapIn = sg(T, 43, 45.5);
    bf.animate(dt, {
      freq: 3 + flapIn * 3, amp: 0.2 + flapIn * 0.75, mean: 0.45, fold: 0, expand: clamp(0.15 + expand * 0.85 + pump, 0.1, 1),
      hang: clamp(hang, 0, 1), wet: 1 - dry * 0.92, glow: 0.2 + dry * 0.9 + flapIn * 0.3, feed: 0,
    });
    const rise = flightLift * 1.4;
    bf.group.position.set(hangX + flightLift * 0.2, by + rise, hangZ + flightLift * 0.9);
    bf.group.rotation.set(tilt, Math.PI * (1 - e(sg(T, 42, 44.5))) + this.yawIntro() * e(sg(T, 42, 44.5)), 0, 'YXZ');
    // sparkles as the wings dry
    if (T > 30 && T < 46 && Math.random() < dt * (6 + flapIn * 30)) {
      this.sparkles.emit(bf.group.position.x + (Math.random() - 0.5) * 0.3, bf.group.position.y - 0.1 + Math.random() * 0.2, bf.group.position.z + 0.1, 0, 0.08, 0.05, 0.04);
    }

    // camera cinematography
    const target = this.cineLook;
    const look0 = new THREE.Vector3(cx, cy - 0.15, cz);
    const wide = new THREE.Vector3(this.site.x + 7.5, this.site.y + 3.4, this.site.z + 11);
    const mid = new THREE.Vector3(this.site.x + 1.9, this.site.y + 1.45, this.site.z + 2.1);
    const closeA = new THREE.Vector3(cx + 0.25, cy - 0.2, cz + 0.9);
    const closeB = new THREE.Vector3(cx + 0.9 * Math.sin(T * 0.12 + 0.5), cy - 0.42, cz + 1.4 * Math.cos(T * 0.12 + 0.2));
    const pos = this.cinePos;
    if (T < 8) pos.lerpVectors(wide, mid, e(T / 8));
    else if (T < 14) pos.lerpVectors(mid, closeA, e(sg(T, 8, 14)));
    else pos.lerpVectors(closeA, closeB, e(sg(T, 14, 22)));
    if (T > 36) pos.lerp(new THREE.Vector3(cx + 1.6, cy - 0.1, cz + 2.6), e(sg(T, 36, 42)));
    target.copy(look0);
    if (T > 18) target.y = lerp(look0.y, by + 0.05, e(sg(T, 18, 24)));
    if (T > 42) { target.copy(bf.group.position); }
    // handheld drift
    pos.x += Math.sin(T * 0.7) * 0.01; pos.y += Math.cos(T * 0.9) * 0.008;
    const cy2 = this.world.heightAt(pos.x, pos.z) + 0.25;
    if (pos.y < cy2) pos.y = cy2;
    this.camera.position.copy(pos);
    this.camera.lookAt(target);
    this.camera.fov = lerp(50, 38, e(sg(T, 6, 14))) + (T > 36 ? e(sg(T, 36, 46)) * 22 : 0);
    this.camera.updateProjectionMatrix();

    if (T > 3 && T < 8 && Math.random() < dt * 0.4) this.audio.ding(-12);
    if (T >= 46.5 && !this.introDone) {
      this.introDone = true;
      this.pos.copy(bf.group.position);
      this.yaw = this.yawIntro();
      this.camPos.copy(this.camera.position);
      this.camLook.copy(target);
      this.camHead = this.yaw;
      this.beginPlay(false);
      this.takeoffT = 1.2;
      this.vel.set(Math.sin(this.yaw) * 2.2, 1.6, Math.cos(this.yaw) * 2.2);
      this.introBlend = 0;
      this.discovered.add('birth');
      this.saveGame();
    }
  }

  private yawIntro() { return Math.atan2(46, 42); }

  /* ------------------------------------------------------------ gameplay */

  private updatePlay(dt: number) {
    const W = this.world;
    const pos = this.pos, vel = this.vel;
    // --- input mapping (keyboard + touch stick)
    let sx = this.stick.x, sy = this.stick.y;
    const K = this.keys;
    if (K.has('a') || K.has('arrowleft')) sx -= 1;
    if (K.has('d') || K.has('arrowright')) sx += 1;
    if (K.has('w') || K.has('arrowup')) sy += 1;
    if (K.has('s') || K.has('arrowdown')) sy -= 1;
    sx = clamp(sx, -1, 1); sy = clamp(sy, -1, 1);
    const up = this.holds.up || K.has(' ');
    const down = this.holds.down || K.has('c') || K.has('control');
    const boost = this.holds.boost || K.has('shift');
    const mag = Math.hypot(sx, sy);

    if (this.mode === 'fly') {
      // steering: stick X turns, stick Y sets speed
      const speedNow = Math.hypot(vel.x, vel.z);
      const turnRate = (1.5 + 0.5 * (1 - clamp(speedNow / 10, 0, 1))) * (this.glide ? 1.25 : 1);
      const dyaw = -sx * turnRate * dt;
      this.yaw += dyaw;
      const f = this.tmpV.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
      let fwd = sy > 0 ? sy : sy * 0.35;
      if (boost) fwd = Math.max(fwd, 0.85);
      const cruise = 6.5, bo = boost ? 2.5 : 1;
      let tgt = fwd * cruise * bo;
      let acc = tgt > speedNow * Math.sign(fwd || 1) ? 1.5 : 1.0;
      if (this.glide) {
        tgt = Math.max(speedNow * 0.995, fwd > 0.1 ? 7.5 * Math.max(fwd, 0.6) : 4.5);
        tgt = Math.min(tgt, 11);
        acc = 0.5;
      } else if (mag < 0.05 && !boost) acc = 0.85;
      const tvx = f.x * tgt, tvz = f.z * tgt;
      const k = 1 - Math.exp(-acc * dt);
      vel.x += (tvx - vel.x) * k;
      vel.z += (tvz - vel.z) * k;
      // wind & turbulence
      const wnd = U.uWind.value;
      const t = this.time;
      vel.x += (0.9 + Math.sin(t * 0.21) * 0.4) * wnd * dt * 1.1;
      vel.z += (0.4 + Math.cos(t * 0.17) * 0.3) * wnd * dt * 0.8;
      // vertical
      let vyT = ((up ? 1 : 0) - (down ? 1 : 0)) * (boost ? 4.8 : 3.4);
      if (this.glide) vyT = (up ? 1.2 : down ? -2.8 : -0.85);
      else if (!up && !down) vyT = Math.sin(t * 2.1) * 0.16 + Math.sin(t * 3.7) * 0.07;
      vel.y += (vyT - vel.y) * (1 - Math.exp(-2.6 * dt));
      vel.y += Math.sin(t * 5.3) * 0.2 * dt * (1 + wnd);
      // drag
      const drag = Math.exp(-0.04 * dt);
      vel.multiplyScalar(drag);
      pos.addScaledVector(vel, dt);
      this.takeoffT = Math.max(0, this.takeoffT - dt);
      if (this.takeoffT > 0.4 && vel.y < 1.5) vel.y += 3 * dt;
    } else if (this.mode === 'landing' && this.activeTarget) {
      const tg = this.activeTarget.pos;
      const to = this.tmpV.set(tg.x - pos.x, tg.y + LEG - pos.y, tg.z - pos.z);
      const dist = to.length();
      const hd = Math.hypot(to.x, to.z);
      const sp = clamp(dist * 1.7, 0.45, 5);
      vel.copy(to).normalize().multiplyScalar(Math.min(sp, dist / Math.max(dt, 1e-3)));
      pos.addScaledVector(vel, dt);
      if (hd > 0.25) this.yaw += angleDiff(this.yaw, Math.atan2(to.x, to.z)) * (1 - Math.exp(-4 * dt));
      if (mag > 0.6 || up) { this.takeOff(); }
      else if (dist < 0.035) {
        this.mode = 'perched';
        pos.set(tg.x, tg.y + LEG, tg.z);
        vel.set(0, 0, 0);
        this.perchYaw = this.yaw;
        this.feedTimer = 0;
        if (this.activeTarget.kind === 'feed') {
          const nm = FLOWER_TYPES[this.activeTarget.type]?.name;
          if (nm && !this.flowerTypes.has(nm)) {
            this.flowerTypes.add(nm);
            this.toast(`New flower: ${nm}`, 3200);
            this.audio.ding(this.flowerTypes.size);
          }
        }
      }
    } else if (this.mode === 'perched') {
      vel.set(0, 0, 0);
      const at = this.activeTarget!;
      pos.set(at.pos.x, at.pos.y + LEG, at.pos.z);
      if (this.sleeping) {
        if (this.atmos.hour > 6 && this.atmos.hour < 12 && this.atmos.night < 0.05) this.wake(true);
      } else if (mag > 0.45 || up || boost) this.takeOff();
      if (at.kind === 'feed' && !this.sleeping) {
        this.feeding = Math.min(1, this.feeding + dt * 1.5);
        this.feedTimer += dt;
        if (this.feedTimer > 3.2) {
          this.feedTimer = 0; this.nectar++;
          this.audio.ding(0);
          for (let i = 0; i < 6; i++) this.sparkles.emit(pos.x, pos.y + 0.1, pos.z, (Math.random() - 0.5) * 0.5, 0.35, (Math.random() - 0.5) * 0.5, 0.045);
        }
      } else this.feeding = Math.max(0, this.feeding - dt * 2);
    }

    // --- ground / water / bounds
    const gh = W.heightAt(pos.x, pos.z);
    if (this.mode === 'fly') {
      const floor = Math.max(gh, 0) + 0.3;
      if (pos.y < floor) { pos.y = floor; if (vel.y < 0) vel.y = 0; }
      // gentle terrain-hugging when flying close to slopes
      if (pos.y > 230) { pos.y = 230; vel.y = Math.min(vel.y, 0); }
    }
    const lim = 492;
    if (Math.abs(pos.x) > lim - 20) vel.x -= Math.sign(pos.x) * (Math.abs(pos.x) - (lim - 20)) * dt * 0.8;
    if (Math.abs(pos.z) > lim - 20) vel.z -= Math.sign(pos.z) * (Math.abs(pos.z) - (lim - 20)) * dt * 0.8;
    pos.x = clamp(pos.x, -lim, lim); pos.z = clamp(pos.z, -lim, lim);

    // --- wings & body pose
    const speed = Math.hypot(vel.x, vel.z);
    const sf = clamp(speed / 7, 0, 1.6);
    let pose = { freq: 6, amp: 0.95, mean: 0.42, fold: 0, expand: 1, hang: 0, wet: 0, glow: 1 + this.atmos.night * 0.8, feed: this.feeding };
    let pitchT = 0, rollT = 0;
    if (this.mode === 'fly') {
      const climbing = vel.y > 0.8;
      if (this.glide) {
        pose = { ...pose, freq: 0.7, amp: 0.1, mean: 0.28 };
        pitchT = -clamp(vel.y * 0.08, -0.4, 0.3) + 0.08;
      } else {
        pose.freq = 5.4 + sf * 1.2 + (climbing ? 1.1 : 0) + (boost ? 1.3 : 0) + (this.takeoffT > 0 ? 1.6 : 0);
        pose.amp = 0.95 - sf * 0.1;
        pose.mean = 0.42 - (vel.y < -1 ? 0.12 : 0);
        const hover = 1 - clamp(speed / 3, 0, 1);
        pitchT = -(hover * 0.55) * 1 - clamp(vel.y * 0.07, -0.4, 0.4) + sf * 0.12;
      }
      rollT = sx * 0.55 * (this.glide ? 1.3 : 1);
    } else if (this.mode === 'landing') {
      const d = this.activeTarget ? this.tmpV.copy(this.activeTarget.pos).sub(pos).length() : 1;
      pose.freq = 3.4; pose.amp = 0.85 - (1 - clamp(d, 0, 1)) * 0.4;
      pose.fold = this.activeTarget?.kind === 'feed' ? 0.25 * (1 - clamp(d, 0, 1)) : (1 - clamp(d / 0.7, 0, 1)) * 0.95;
      pitchT = -0.55;
    } else {
      pitchT = -0.4;
      if (this.activeTarget?.kind === 'feed' && !this.sleeping) {
        pose.freq = 0.42; pose.amp = 0.42; pose.mean = 0.9; pose.fold = 0.15; pose.feed = this.feeding;
      } else {
        pose.freq = this.sleeping ? 0.08 : 0.18; pose.amp = 0.3; pose.mean = 1.0; pose.fold = this.sleeping ? 1 : 0.9;
        pose.glow = (this.sleeping ? 0.5 : 0.9) + this.atmos.night * 0.6;
      }
    }
    this.bf.animate(dt, pose);
    const cycle = Math.floor(this.bf.phase / (Math.PI * 2));
    if (cycle !== this.lastFlapCycle) {
      this.lastFlapCycle = cycle;
      if (this.mode !== 'perched' && !this.glide) this.audio.flap(clamp(0.5 + sf * 0.5, 0.3, 1));
    }

    this.pitchV += (pitchT - this.pitchV) * (1 - Math.exp(-4 * dt));
    this.rollV += (rollT - this.rollV) * (1 - Math.exp(-3.5 * dt));
    const bob = this.mode === 'fly' ? Math.sin(this.bf.phase) * 0.012 : 0;
    this.bf.group.position.set(pos.x, pos.y + bob, pos.z);
    this.bf.group.rotation.set(this.pitchV, this.yaw, this.rollV, 'YXZ');

    // sparkle trail
    const glowAmt = 1 + this.atmos.night;
    if (this.mode === 'fly') {
      this.sparkAcc += dt * (4 + sf * 16 + (boost ? 20 : 0)) * glowAmt;
      while (this.sparkAcc > 1) {
        this.sparkAcc -= 1;
        const bx = -Math.sin(this.yaw) * 0.18, bz = -Math.cos(this.yaw) * 0.18;
        this.sparkles.emit(pos.x + bx + (Math.random() - 0.5) * 0.12, pos.y - 0.02 + (Math.random() - 0.5) * 0.12, pos.z + bz + (Math.random() - 0.5) * 0.12,
          vel.x * 0.03, 0.02, vel.z * 0.03, 0.05);
      }
    }

    // --- perch / flower detection
    this.landT -= dt;
    if (this.landT <= 0) { this.landT = 0.1; this.findLandTarget(); }

    // --- POIs & region
    this.poiT -= dt;
    if (this.poiT <= 0) { this.poiT = 0.5; this.checkPois(); }
    const reg = W.regionAt(pos.x, pos.z);
    if (reg !== this.regionNow) {
      this.regionNow = reg;
      this.regionTitle = REGION_INFO[reg].name; this.regionTitleT = 4.5;
    }
    if (!this.nightHintShown && this.atmos.night > 0.8) {
      this.nightHintShown = true;
      this.toast('Night falls — find a quiet leaf to sleep', 5000);
    }

    this.updateChaseCamera(dt, boost);
  }

  private findLandTarget() {
    this.landTarget = null;
    if (this.mode !== 'fly') return;
    const p = this.pos;
    let best: LandTarget | null = null;
    // flowers
    const items = this.veg.flowerItems, n = this.veg.flowers.count;
    let bd = 3.4 * 3.4;
    let bi = -1;
    for (let i = 0; i < n; i++) {
      const f = items[i];
      const dx = f.x - p.x, dz = f.z - p.z;
      if (dx > 3.4 || dx < -3.4 || dz > 3.4 || dz < -3.4) continue;
      const top = f.y + FLOWER_H * f.sy + 0.05;
      const dy = top - p.y;
      if (dy > 2.4 || dy < -2.4) continue;
      const d = dx * dx + dz * dz + dy * dy * 0.6;
      if (d < bd && f.sy > 0.45) { bd = d; bi = i; }
    }
    if (bi >= 0) {
      const f = items[bi];
      best = { kind: 'feed', pos: new THREE.Vector3(f.x, f.y + FLOWER_H * f.sy + 0.05, f.z), type: f.type };
    } else {
      let pd = 4.6 * 4.6, pb: THREE.Vector3 | null = null;
      for (const pc of this.veg.perches) {
        const dx = pc.pos.x - p.x, dy = pc.pos.y - p.y, dz = pc.pos.z - p.z;
        const d = dx * dx + dy * dy + dz * dz;
        if (d < pd) { pd = d; pb = pc.pos; }
      }
      if (pb) best = { kind: 'rest', pos: pb.clone(), type: 0 };
      else {
        const gh = this.world.heightAt(p.x, p.z);
        if (gh > 0.5 && p.y - gh < 1.5) best = { kind: 'ground', pos: new THREE.Vector3(p.x, gh + 0.02, p.z), type: 0 };
      }
    }
    this.landTarget = best;
  }

  private checkPois() {
    for (const p of POIS) {
      if (this.discovered.has(p.id)) continue;
      const d = Math.hypot(this.pos.x - p.x, this.pos.z - p.z);
      let ok = d < p.r;
      if (p.id === 'summit') ok = d < p.r && this.pos.y > this.world.heightAt(p.x, p.z) - 8;
      if (ok) {
        this.discovered.add(p.id);
        this.toast(`Discovered: ${p.name}`, 4500);
        this.audio.discover();
        this.saveGame();
        break;
      }
    }
  }

  /* ------------------------------------------------------------ camera */

  private updateChaseCamera(dt: number, boost: boolean) {
    const cam = this.camera;
    const speed = Math.hypot(this.vel.x, this.vel.z);
    const sf = clamp(speed / 8, 0, 1.4);
    this.camHead += angleDiff(this.camHead, this.mode === 'perched' ? this.camHead : this.yaw) * (1 - Math.exp(-(this.mode === 'fly' ? 1.9 : 0.6) * dt));
    if (this.time - this.lastCamInput > 2.2) {
      const d = Math.exp(-0.9 * dt);
      this.camUserYaw *= d; this.camUserPitch *= d;
    }
    const perched = this.mode === 'perched';
    const baseDist = perched ? (this.sleeping ? 3.6 : 2.0) : this.mode === 'landing' ? 2.2 : 2.9 + sf * 0.6;
    const dist = baseDist * this.zoom;
    const ca = this.camHead + Math.PI + this.camUserYaw;
    let cp = (perched ? 0.22 : 0.26) + this.camUserPitch - clamp(this.vel.y * 0.022, -0.14, 0.14);
    cp = clamp(cp, -0.45, 1.3);
    const target = this.tmpV.copy(this.pos);
    target.y += 0.12;
    const desired = new THREE.Vector3(
      target.x + Math.sin(ca) * Math.cos(cp) * dist, target.y + Math.sin(cp) * dist, target.z + Math.cos(ca) * Math.cos(cp) * dist,
    );
    const ground = Math.max(this.world.heightAt(desired.x, desired.z), 0) + 0.4;
    if (desired.y < ground) desired.y = ground;
    const kPos = 1 - Math.exp(-(perched ? 3 : 8) * dt);
    this.camPos.lerp(desired, kPos);
    const lookT = new THREE.Vector3(target.x + Math.sin(this.yaw) * 0.7 * sf, target.y + 0.1, target.z + Math.cos(this.yaw) * 0.7 * sf);
    this.camLook.lerp(lookT, 1 - Math.exp(-9 * dt));
    this.introBlend = Math.min(1, this.introBlend + dt * 0.55);
    const b = this.ease(this.introBlend);
    if (b < 1) {
      cam.position.lerpVectors(this.cinePos, this.camPos, b);
      this.tmpV.lerpVectors(this.cineLook, this.camLook, b);
      cam.lookAt(this.tmpV);
    } else {
      cam.position.copy(this.camPos);
      cam.lookAt(this.camLook);
    }
    const targetFov = 62 + (boost ? 9 : 0) + (this.glide ? 4 : 0) + sf * 3 - (perched ? 8 : 0);
    this.fovBoost += (targetFov - this.fovBoost) * (1 - Math.exp(-3 * dt));
    if (Math.abs(cam.fov - this.fovBoost) > 0.02) { cam.fov = this.fovBoost; cam.updateProjectionMatrix(); }
  }

  private updateMarker() {
    const m = this.marker;
    const t = this.state === 'play' && this.mode === 'fly' ? this.landTarget : null;
    if (!t) { m.style.display = 'none'; return; }
    const v = this.tmpV.copy(t.pos).project(this.camera);
    if (v.z > 1 || v.z < -1) { m.style.display = 'none'; return; }
    const w = this.container.clientWidth, h = this.container.clientHeight;
    m.style.display = 'block';
    m.style.transform = `translate(${(v.x * 0.5 + 0.5) * w}px, ${(-v.y * 0.5 + 0.5) * h}px) scale(${0.9 + 0.1 * Math.sin(this.time * 4)})`;
    m.textContent = t.kind === 'feed' ? '🌸' : t.kind === 'rest' ? '🍃' : '·';
  }

  /* ------------------------------------------------------------ hud / map */

  buildHud(): HudState {
    const h = this.atmos.hour;
    const nightish = this.atmos.night > 0.4 || h < 6 || h > 19;
    return {
      region: this.regionNow,
      regionTitle: this.regionTitle,
      hour: h,
      weather: this.atmos.weatherLabel(),
      nectar: this.nectar,
      discoveries: [...this.discovered].filter((d) => d !== 'birth').length,
      discoveryTotal: POIS.length,
      flowerTypes: this.flowerTypes.size,
      prompt: this.state === 'play' && this.mode === 'fly' && this.landTarget ? this.landTarget.kind : null,
      mode: this.state === 'paused' ? 'paused' : this.state === 'menu' ? 'menu' : this.state === 'intro' ? 'intro' :
        this.sleeping ? 'sleeping' : this.mode === 'perched' ? (this.activeTarget?.kind === 'feed' ? 'feeding' : 'resting') :
        this.mode === 'landing' ? 'landing' : this.glide ? 'gliding' : Math.hypot(this.vel.x, this.vel.z) < 1 ? 'hovering' : 'flying',
      night: nightish,
      toast: this.toastMsg,
      intro: this.state === 'intro',
      introSkippable: this.state === 'intro' && this.introT < 40,
      introTime: this.state === 'intro' ? this.introT : 0,
      sleeping: this.sleeping,
      canSleep: this.state === 'play' && this.mode === 'perched' && !this.sleeping && nightish,
      glide: this.glide,
    };
  }

  private drawMinimap() {
    const c = this.minimap;
    if (!c || !this.mapBase || this.state === 'menu') return;
    const g = c.getContext('2d');
    if (!g) return;
    const S = c.width;
    const span = 320; // world units shown
    const k = this.mapBase.width / 1000;
    const px = (this.pos.x + HALF) * k, pz = (this.pos.z + HALF) * k;
    const sw = span * k;
    g.clearRect(0, 0, S, S);
    g.save();
    g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2); g.clip();
    g.fillStyle = '#10202a'; g.fillRect(0, 0, S, S);
    g.translate(S / 2, S / 2);
    g.rotate(this.yaw - Math.PI); // heading up
    g.translate(-S / 2, -S / 2);
    g.globalAlpha = 0.92;
    g.drawImage(this.mapBase, px - sw / 2, pz - sw / 2, sw, sw, 0, 0, S, S);
    g.globalAlpha = 1;
    // POIs
    const sc = S / span;
    for (const p of POIS) {
      if (!this.discovered.has(p.id)) continue;
      const x = (p.x - this.pos.x) * sc + S / 2, y = (p.z - this.pos.z) * sc + S / 2;
      g.fillStyle = 'rgba(255,240,170,0.95)';
      g.beginPath(); g.arc(x, y, 3, 0, Math.PI * 2); g.fill();
    }
    g.restore();
    // butterfly marker
    g.save();
    g.translate(S / 2, S / 2);
    g.fillStyle = '#7ff0ff'; g.shadowColor = '#4cd0ff'; g.shadowBlur = 8;
    g.beginPath(); g.moveTo(0, -8); g.lineTo(6, 7); g.lineTo(0, 3); g.lineTo(-6, 7); g.closePath(); g.fill();
    g.restore();
    g.strokeStyle = 'rgba(255,255,255,0.35)'; g.lineWidth = 1.5;
    g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2); g.stroke();
  }

  /* ------------------------------------------------------------ cleanup */

  dispose() {
    this.disposed = true;
    this.renderer?.setAnimationLoop(null);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    document.removeEventListener('visibilitychange', this.onVis);
    this.audio.suspend();
    this.marker.remove();
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
  }

  /** smoothstep helper re-exported for UI */
  static smooth = smoothstep;
}

export const WEATHER_MODES: WeatherMode[] = ['auto', 'sunny', 'cloudy', 'rain', 'windy', 'mist'];
export { REGION_IDS };
