import * as THREE from 'three';
import { World, LAKE, POND } from './terrain';
import { Vegetation } from './vegetation';
import { QualityCfg } from './config';
import { paint, xform, merge, col } from './geo';
import { Butterfly, NPC_PALETTES } from './butterfly';
import { mulberry32, angleDiff, clamp } from './noise';

export interface WildHooks {
  chirp: (vol: number) => void;
  ribbit: (vol: number) => void;
  meet: (idx: number) => void;
}

const rnd = mulberry32(2024);
const R = (a = 0, b = 1) => a + (b - a) * rnd();

/* ---------------------------------------------------------------- birds */
const BIRD_COLORS = [
  { body: '#7a5638', belly: '#e8d8b8', wing: '#4a3624' },
  { body: '#2a62d8', belly: '#f0f0ff', wing: '#1a3a98' },
  { body: '#d8362a', belly: '#f4d0a0', wing: '#8a2218' },
  { body: '#e8c020', belly: '#fff2a0', wing: '#403010' },
];

function birdBody(c: (typeof BIRD_COLORS)[0]) {
  const parts: THREE.BufferGeometry[] = [];
  const b = new THREE.SphereGeometry(0.2, 10, 8); b.scale(0.95, 0.85, 1.55);
  paint(b, (v) => col(c.body).lerp(col(c.belly), clamp(-v.y * 4, 0, 1)));
  const h = new THREE.SphereGeometry(0.115, 8, 6); h.translate(0, 0.08, 0.3);
  paint(h, (v) => col(c.body).lerp(col(c.belly), clamp(-(v.y - 0.08) * 6, 0, 1) * 0.7));
  const beak = new THREE.ConeGeometry(0.035, 0.12, 5); beak.rotateX(Math.PI / 2); beak.translate(0, 0.07, 0.46);
  paint(beak, () => col('#e8a020'));
  const tail = new THREE.BoxGeometry(0.16, 0.025, 0.32); tail.translate(0, 0.0, -0.4);
  paint(tail, () => col(c.wing));
  parts.push(b, h, beak, tail);
  const eyes = new THREE.SphereGeometry(0.02, 4, 4);
  for (const s of [-1, 1]) { const e = xform(eyes, [s * 0.075, 0.11, 0.37]); paint(e, () => col('#101010')); parts.push(e); }
  return merge(parts);
}
function birdWing(c: (typeof BIRD_COLORS)[0]) {
  const g = new THREE.BufferGeometry();
  const v = [0, 0, 0.18, 0.5, 0.02, 0.22, 1.0, 0.03, -0.12, 0.6, 0.02, -0.3, 0, 0, -0.24];
  g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
  g.setIndex([0, 1, 2, 0, 2, 3, 0, 3, 4]);
  g.setAttribute('uv', new THREE.Float32BufferAttribute(new Array(10).fill(0), 2));
  g.computeVertexNormals();
  paint(g, (p) => col(c.wing).lerp(col(c.body), 1 - clamp(p.x, 0, 1)));
  return g;
}

interface Bird {
  g: THREE.Group; wl: THREE.Group; wr: THREE.Group;
  mode: 'fly' | 'land' | 'perch' | 'takeoff';
  pos: THREE.Vector3; vel: THREE.Vector3; home: THREE.Vector3; radius: number; speed: number; alt: number;
  timer: number; perch: THREE.Vector3 | null; flap: number; roll: number; dir: number; fseed: number; chirpT: number;
}

/* ---------------------------------------------------------------- others */
interface Bee { g: THREE.Group; wl: THREE.Mesh; wr: THREE.Mesh; pos: THREE.Vector3; tgt: THREE.Vector3; timer: number; hover: boolean; ph: number }
interface Dragon { g: THREE.Group; w: THREE.Mesh[]; pos: THREE.Vector3; tgt: THREE.Vector3; timer: number; yaw: number; ph: number }
interface Frog { g: THREE.Group; pos: THREE.Vector3; from: THREE.Vector3; to: THREE.Vector3; t: number; hop: boolean; idle: number; yaw: number; ribT: number }
interface Npc { b: Butterfly; pos: THREE.Vector3; head: number; speed: number; ph: number; idx: number; alt: number; turn: number; met: boolean }

export class Wildlife {
  group = new THREE.Group();
  birds: Bird[] = [];
  bees: Bee[] = [];
  dragons: Dragon[] = [];
  frogs: Frog[] = [];
  npcs: Npc[] = [];
  bugs: THREE.Points;
  bugPos: Float32Array;
  bugHead: Float32Array;
  private waterSample: { x: number; z: number; d: number }[] = [];
  private t = 0;

  constructor(private world: World, private veg: Vegetation, q: QualityCfg, private hooks: WildHooks, start: THREE.Vector3) {
    const k = q.wildlife;
    // birds
    const nb = Math.round(16 * k);
    const bm = new THREE.MeshLambertMaterial({ vertexColors: true });
    const wm = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    const bodies = BIRD_COLORS.map(birdBody), wings = BIRD_COLORS.map(birdWing);
    for (let i = 0; i < nb; i++) {
      const ci = i % BIRD_COLORS.length;
      const g = new THREE.Group();
      g.add(new THREE.Mesh(bodies[ci], bm));
      const wl = new THREE.Group(), wr = new THREE.Group();
      const ml = new THREE.Mesh(wings[ci], wm), mr = new THREE.Mesh(wings[ci], wm);
      mr.scale.x = -1;
      wl.add(ml); wr.add(mr);
      wl.position.set(0.1, 0.05, 0.02); wr.position.set(-0.1, 0.05, 0.02);
      g.add(wl, wr);
      g.scale.setScalar(1.15);
      g.traverse((o) => { o.frustumCulled = true; });
      this.group.add(g);
      const home = start.clone().add(new THREE.Vector3(R(-160, 160), 0, R(-160, 160)));
      this.birds.push({
        g, wl, wr, mode: 'fly', pos: home.clone().setY(world.heightAt(home.x, home.z) + R(18, 40)), vel: new THREE.Vector3(0, 0, 1),
        home, radius: R(40, 110), speed: R(7, 11), alt: R(16, 38), timer: R(8, 30), perch: null, flap: R(0, 6), roll: 0, dir: rnd() < 0.5 ? 1 : -1,
        fseed: R(0, 100), chirpT: R(2, 9),
      });
    }
    // perched start for a third of them
    this.birds.forEach((b, i) => { if (i % 3 === 0) this.sendToPerch(b, true); });

    // bees
    const beeGeo = (() => {
      const b = new THREE.SphereGeometry(0.1, 8, 6); b.scale(0.8, 0.8, 1.2);
      paint(b, (v) => (Math.sin(v.z * 40) > 0.1 ? col('#1a1208') : col('#f6c21a')));
      return b;
    })();
    const beeMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    const bwMat = new THREE.MeshBasicMaterial({ color: '#e8f4ff', transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false });
    const bwGeo = new THREE.PlaneGeometry(0.16, 0.07); bwGeo.translate(0.09, 0, 0); bwGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < Math.round(12 * k); i++) {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(beeGeo, beeMat));
      const wl = new THREE.Mesh(bwGeo, bwMat), wr = new THREE.Mesh(bwGeo, bwMat);
      wr.scale.x = -1; wl.position.y = wr.position.y = 0.08;
      g.add(wl, wr);
      g.scale.setScalar(1.4);
      this.group.add(g);
      const p = start.clone().add(new THREE.Vector3(R(-20, 20), 2, R(-20, 20)));
      this.bees.push({ g, wl, wr, pos: p, tgt: p.clone(), timer: R(0, 3), hover: false, ph: R(0, 6) });
    }

    // dragonflies
    const dgBody = (() => {
      const b = new THREE.CylinderGeometry(0.018, 0.012, 0.55, 6); b.rotateX(Math.PI / 2);
      paint(b, (v) => col('#18c8b8').lerp(col('#1840c0'), clamp(-v.z * 2.5, 0, 1)));
      const h = new THREE.SphereGeometry(0.05, 8, 6); h.translate(0, 0, 0.3);
      paint(h, () => col('#1a8a3a'));
      return merge([b, h]);
    })();
    const dgMat = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: new THREE.Color('#0a6a68'), emissiveIntensity: 0.4 });
    const dwMat = new THREE.MeshBasicMaterial({ color: '#d8f4ff', transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false });
    const dwGeo = new THREE.PlaneGeometry(0.34, 0.07); dwGeo.translate(0.19, 0, 0); dwGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < Math.round(12 * k); i++) {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(dgBody, dgMat));
      const w: THREE.Mesh[] = [];
      for (const [s, z] of [[1, 0.1], [-1, 0.1], [1, 0.03], [-1, 0.03]]) {
        const m = new THREE.Mesh(dwGeo, dwMat); m.scale.x = s; m.position.set(0, 0.02, z); g.add(m); w.push(m);
      }
      g.scale.setScalar(1.3);
      this.group.add(g);
      const wv = world.waterVerts.length ? world.waterVerts[Math.floor(rnd() * world.waterVerts.length)] : { x: LAKE.x, z: LAKE.z };
      const p = new THREE.Vector3(wv.x, 1.2, wv.z);
      this.dragons.push({ g, w, pos: p, tgt: p.clone(), timer: R(0, 2), yaw: R(0, 6), ph: R(0, 6) });
    }

    this.waterSample = world.waterVerts.filter((_, i) => i % 7 === 0);
    // frogs
    const frogGeo = (() => {
      const parts: THREE.BufferGeometry[] = [];
      const b = new THREE.SphereGeometry(0.16, 10, 8); b.scale(1, 0.7, 1.3); b.translate(0, 0.1, 0);
      paint(b, (v) => col('#4a9a2c').lerp(col('#c8e090'), clamp(-(v.y - 0.1) * 7, 0, 1)));
      parts.push(b);
      for (const s of [-1, 1]) {
        const e = new THREE.SphereGeometry(0.05, 6, 5); e.translate(s * 0.08, 0.24, 0.12); paint(e, () => col('#d8c040')); parts.push(e);
        const l = new THREE.SphereGeometry(0.07, 6, 5); l.scale(0.6, 0.6, 1.5); l.translate(s * 0.15, 0.06, -0.12); paint(l, () => col('#3a8a24')); parts.push(l);
      }
      return merge(parts);
    })();
    const frogMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    for (let i = 0; i < Math.round(8 * k); i++) {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(frogGeo, frogMat));
      g.scale.setScalar(1.2);
      this.group.add(g);
      const p = this.shorePoint(i);
      g.position.copy(p);
      this.frogs.push({ g, pos: p, from: p.clone(), to: p.clone(), t: 0, hop: false, idle: R(1, 5), yaw: R(0, 6), ribT: R(3, 10) });
    }

    // butterflies
    for (let i = 0; i < Math.round(14 * k); i++) {
      const idx = i % NPC_PALETTES.length;
      const b = new Butterfly(NPC_PALETTES[idx], true);
      b.model.scale.setScalar(0.2);
      b.halo.visible = false;
      this.group.add(b.group);
      const p = start.clone().add(new THREE.Vector3(R(-40, 40), 0, R(-40, 40)));
      this.npcs.push({ b, pos: p, head: R(0, 6.28), speed: R(1.2, 2.6), ph: R(0, 6), idx, alt: R(1, 4.5), turn: 0, met: false });
    }

    // ground critters
    const nBug = Math.round(70 * q.particles);
    this.bugPos = new Float32Array(nBug * 3);
    this.bugHead = new Float32Array(nBug);
    const bc = new Float32Array(nBug * 3);
    const cols = ['#201008', '#b02818', '#181818', '#6a4a20'].map((c) => col(c));
    for (let i = 0; i < nBug; i++) {
      this.bugPos[i * 3] = start.x + R(-25, 25); this.bugPos[i * 3 + 2] = start.z + R(-25, 25);
      this.bugHead[i] = R(0, 6.28);
      const c = cols[i % 4]; bc[i * 3] = c.r; bc[i * 3 + 1] = c.g; bc[i * 3 + 2] = c.b;
    }
    const bg = new THREE.BufferGeometry();
    bg.setAttribute('position', new THREE.BufferAttribute(this.bugPos, 3));
    bg.setAttribute('color', new THREE.BufferAttribute(bc, 3));
    this.bugs = new THREE.Points(bg, new THREE.PointsMaterial({ size: 0.07, vertexColors: true, sizeAttenuation: true }));
    this.bugs.frustumCulled = false;
    this.group.add(this.bugs);
  }

  private shorePoint(i: number) {
    const W = this.world;
    const useLake = i % 3 !== 0;
    const c = useLake ? LAKE : POND;
    for (let tries = 0; tries < 40; tries++) {
      const a = R(0, 6.28);
      for (let r = c.R * 0.7; r < c.R * 2.2; r += 0.7) {
        const x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
        const h = W.heightAt(x, z);
        if (h > 0.3 && h < 1.2) return new THREE.Vector3(x, h, z);
        if (h > 1.2) break;
      }
    }
    return new THREE.Vector3(POND.x + POND.R * 1.4, 1, POND.z);
  }

  private sendToPerch(b: Bird, instant = false) {
    const spots = this.veg.treeSpots;
    if (!spots.length) return;
    let best: THREE.Vector3 | null = null, bd = 1e9;
    for (let k = 0; k < 14; k++) {
      const s = spots[Math.floor(rnd() * spots.length)];
      const d = s.distanceTo(b.pos);
      if (d < bd) { bd = d; best = s; }
    }
    if (!best) return;
    b.perch = best;
    if (instant) {
      b.mode = 'perch'; b.pos.copy(best); b.timer = R(6, 25); b.g.position.copy(best);
      b.g.rotation.y = R(0, 6.28); b.wl.rotation.z = -0.4; b.wr.rotation.z = 0.4;
    } else b.mode = 'land';
  }

  update(dt: number, pl: THREE.Vector3) {
    this.t += dt;
    const W = this.world, t = this.t;
    const tmp = new THREE.Vector3();

    for (const b of this.birds) {
      const far = b.pos.distanceTo(pl);
      if (far > 280) {
        const a = R(0, 6.28), d = R(90, 190);
        b.home.set(pl.x + Math.cos(a) * d, 0, pl.z + Math.sin(a) * d);
        b.home.x = clamp(b.home.x, -440, 440); b.home.z = clamp(b.home.z, -440, 440);
        b.pos.set(b.home.x + R(-30, 30), W.heightAt(b.home.x, b.home.z) + b.alt, b.home.z + R(-30, 30));
        b.mode = 'fly'; b.timer = R(10, 30);
      }
      if (b.mode === 'fly' || b.mode === 'takeoff') {
        const ang = Math.atan2(b.pos.z - b.home.z, b.pos.x - b.home.x) + 0.55 * b.dir;
        tmp.set(b.home.x + Math.cos(ang) * b.radius, 0, b.home.z + Math.sin(ang) * b.radius);
        const gh = W.heightAt(tmp.x, tmp.z);
        tmp.y = Math.max(gh + b.alt + Math.sin(t * 0.3 + b.fseed) * 4, b.pos.y * 0.97 + (gh + b.alt) * 0.03);
        tmp.sub(b.pos);
        const want = tmp.normalize().multiplyScalar(b.speed);
        b.vel.lerp(want, 1 - Math.exp(-1.6 * dt));
        b.pos.addScaledVector(b.vel, dt);
        const gh2 = W.heightAt(b.pos.x, b.pos.z) + 3;
        if (b.pos.y < gh2) b.pos.y = gh2;
        const yaw = Math.atan2(b.vel.x, b.vel.z);
        const dy = angleDiff(b.g.rotation.y, yaw);
        b.g.rotation.y += dy * (1 - Math.exp(-3 * dt));
        b.roll += (-dy * 1.2 - b.roll) * (1 - Math.exp(-3 * dt));
        b.g.rotation.z = b.roll;
        b.g.rotation.x = -clamp(b.vel.y * 0.08, -0.5, 0.5);
        b.g.position.copy(b.pos);
        const flapping = Math.sin(t * 0.6 + b.fseed) > -0.35;
        b.flap += dt * (flapping ? 11 : 0);
        const a = flapping ? Math.sin(b.flap) * 0.75 : 0.1;
        b.wl.rotation.z = a; b.wr.rotation.z = -a;
        b.timer -= dt;
        if (b.timer <= 0 && far < 220) { b.timer = R(15, 45); this.sendToPerch(b); }
        b.chirpT -= dt;
        if (b.chirpT <= 0) { b.chirpT = R(5, 14); if (far < 60) hooksChirp(this.hooks, 1 - far / 60); }
      } else if (b.mode === 'land' && b.perch) {
        tmp.copy(b.perch).sub(b.pos);
        const d = tmp.length();
        const sp = clamp(d * 0.9, 1.2, b.speed);
        b.vel.lerp(tmp.normalize().multiplyScalar(sp), 1 - Math.exp(-3 * dt));
        b.pos.addScaledVector(b.vel, dt);
        b.g.position.copy(b.pos);
        const yaw = Math.atan2(b.vel.x, b.vel.z);
        b.g.rotation.y += angleDiff(b.g.rotation.y, yaw) * (1 - Math.exp(-4 * dt));
        b.g.rotation.x = d > 1.5 ? -0.1 : 0.5;
        b.g.rotation.z = 0;
        b.flap += dt * 16;
        const a = Math.sin(b.flap) * 0.9;
        b.wl.rotation.z = a; b.wr.rotation.z = -a;
        if (d < 0.25) { b.mode = 'perch'; b.timer = R(8, 28); b.g.rotation.x = 0; b.vel.set(0, 0, 0); }
      } else if (b.mode === 'perch') {
        b.timer -= dt;
        b.g.rotation.y += Math.sin(t * 0.8 + b.fseed) * dt * 0.5;
        b.g.rotation.x = Math.sin(t * 2 + b.fseed) * 0.05;
        b.wl.rotation.z = -0.45; b.wr.rotation.z = 0.45;
        b.chirpT -= dt;
        if (b.chirpT <= 0) { b.chirpT = R(3, 9); if (far < 60) hooksChirp(this.hooks, 1 - far / 60); }
        if (b.timer <= 0) {
          b.mode = 'takeoff';
          const a = R(0, 6.28);
          b.home.set(b.pos.x - Math.cos(a) * b.radius, 0, b.pos.z - Math.sin(a) * b.radius);
          b.vel.set(0, 3, 0);
          b.timer = R(14, 40);
          setTimeout(() => { if (b.mode === 'takeoff') b.mode = 'fly'; }, 600);
        }
      }
    }

    // bees
    const flowers = this.veg.flowerItems;
    for (const b of this.bees) {
      b.ph += dt * 90;
      const wa = Math.sin(b.ph) * 0.9;
      b.wl.rotation.z = wa; b.wr.rotation.z = -wa;
      const d2 = Math.hypot(b.pos.x - pl.x, b.pos.z - pl.z);
      if (d2 > 55 && flowers.length) {
        const f = flowers[Math.floor(rnd() * flowers.length)];
        b.pos.set(f.x, f.y + 1.2, f.z); b.tgt.copy(b.pos);
      }
      b.timer -= dt;
      if (b.timer <= 0) {
        if (flowers.length && rnd() < 0.9) {
          const f = flowers[Math.floor(rnd() * flowers.length)];
          b.tgt.set(f.x, f.y + 0.9 * f.sy + 0.12, f.z);
        } else b.tgt.set(pl.x + R(-15, 15), W.heightAt(pl.x, pl.z) + R(1, 3), pl.z + R(-15, 15));
        b.timer = R(2.5, 6);
        b.hover = false;
      }
      tmp.copy(b.tgt).sub(b.pos);
      const d = tmp.length();
      if (d > 0.15) {
        b.pos.addScaledVector(tmp.normalize(), Math.min(d, 2.8 * dt * (1 + d * 0.15)));
        b.g.rotation.y += angleDiff(b.g.rotation.y, Math.atan2(tmp.x, tmp.z)) * (1 - Math.exp(-6 * dt));
      } else b.hover = true;
      const wob = b.hover ? 0.03 : 0.12;
      b.g.position.set(b.pos.x + Math.sin(t * 5 + b.ph * 0.01) * wob, b.pos.y + Math.sin(t * 7 + b.ph * 0.02) * wob, b.pos.z + Math.cos(t * 4.6) * wob);
      b.g.rotation.x = b.hover ? 0.5 : 0.1;
    }

    // dragonflies
    for (const d of this.dragons) {
      d.ph += dt * 60;
      const wa = Math.sin(d.ph) * 0.35;
      d.w[0].rotation.z = wa; d.w[1].rotation.z = -wa; d.w[2].rotation.z = -wa; d.w[3].rotation.z = wa;
      d.timer -= dt;
      if (d.timer <= 0) {
        const near = this.waterSample;
        let pick = near[Math.floor(rnd() * near.length)];
        for (let k = 0; k < 6; k++) {
          const c = near[Math.floor(rnd() * near.length)];
          if (c && Math.hypot(c.x - d.pos.x, c.z - d.pos.z) < 24) { pick = c; break; }
        }
        if (pick) d.tgt.set(pick.x, R(0.6, 1.8), pick.z);
        d.timer = R(0.8, 2.6);
      }
      tmp.copy(d.tgt).sub(d.pos);
      const dist = tmp.length();
      if (dist > 0.1) {
        const sp = Math.min(dist * 3, 5.5);
        d.pos.addScaledVector(tmp.normalize(), sp * dt);
        d.yaw += angleDiff(d.yaw, Math.atan2(tmp.x, tmp.z)) * (1 - Math.exp(-8 * dt));
      }
      d.g.position.set(d.pos.x, d.pos.y + Math.sin(t * 9 + d.ph * 0.01) * 0.03, d.pos.z);
      d.g.rotation.y = d.yaw;
    }

    // frogs
    for (const f of this.frogs) {
      const dp = Math.hypot(f.pos.x - pl.x, f.pos.z - pl.z);
      if (f.hop) {
        f.t += dt / 0.55;
        const k = Math.min(1, f.t);
        f.pos.lerpVectors(f.from, f.to, k);
        f.g.position.set(f.pos.x, f.pos.y + Math.sin(k * Math.PI) * 0.55, f.pos.z);
        f.g.rotation.x = -Math.cos(k * Math.PI) * 0.5;
        if (f.t >= 1) { f.hop = false; f.idle = R(2, 8); f.g.rotation.x = 0; f.g.position.copy(f.pos); }
      } else {
        f.idle -= dt;
        f.g.scale.y = 1.2 * (1 + Math.sin(t * 3 + f.yaw) * 0.04);
        if (f.idle <= 0 || (dp < 2.5 && rnd() < 0.05)) {
          const a = R(0, 6.28), dd = R(1, 2.8);
          const nx = f.pos.x + Math.cos(a) * dd, nz = f.pos.z + Math.sin(a) * dd;
          const h = W.heightAt(nx, nz);
          if (h > -0.35 && h < 2.5) {
            f.from.copy(f.pos); f.to.set(nx, Math.max(h, 0.05), nz); f.t = 0; f.hop = true;
            f.yaw = Math.atan2(nx - f.pos.x, nz - f.pos.z); f.g.rotation.y = f.yaw;
          } else f.idle = 1;
        }
        f.ribT -= dt;
        if (f.ribT <= 0) { f.ribT = R(5, 14); if (dp < 38) this.hooks.ribbit(1 - dp / 38); }
      }
    }

    // butterflies
    for (const n of this.npcs) {
      n.ph += dt;
      const d = Math.hypot(n.pos.x - pl.x, n.pos.z - pl.z);
      if (d > 110) {
        const a = R(0, 6.28), r = R(35, 80);
        n.pos.set(clamp(pl.x + Math.cos(a) * r, -460, 460), 0, clamp(pl.z + Math.sin(a) * r, -460, 460));
        n.pos.y = W.heightAt(n.pos.x, n.pos.z) + n.alt;
        n.met = false;
      }
      n.turn += (Math.sin(n.ph * 0.7 + n.idx) * 0.9 + Math.sin(n.ph * 1.9) * 0.5 - n.turn) * dt;
      n.head += n.turn * dt * 1.3;
      const sp = n.speed * (0.7 + 0.3 * Math.sin(n.ph * 2.4));
      n.pos.x += Math.sin(n.head) * sp * dt; n.pos.z += Math.cos(n.head) * sp * dt;
      const gh = W.heightAt(n.pos.x, n.pos.z);
      const ty = Math.max(gh + n.alt + Math.sin(n.ph * 0.9) * 1.1, W.heightAt(n.pos.x, n.pos.z) + 0.8, 0.9);
      n.pos.y += (ty - n.pos.y) * (1 - Math.exp(-1.5 * dt)) + Math.sin(n.ph * 12) * dt * 0.5;
      n.b.group.position.copy(n.pos);
      n.b.group.rotation.set(0.1 * Math.sin(n.ph * 3), n.head, -n.turn * 0.5);
      const glide = Math.sin(n.ph * 0.8 + n.idx * 2) > 0.75;
      n.b.animate(dt, { freq: glide ? 0.5 : 5.2, amp: glide ? 0.2 : 0.85, mean: glide ? 0.45 : 0.45, fold: 0, expand: 1, hang: 0, wet: 0, glow: 0, feed: 0 });
      if (!n.met && Math.hypot(n.pos.x - pl.x, n.pos.z - pl.z) < 5 && Math.abs(n.pos.y - pl.y) < 4) { n.met = true; this.hooks.meet(n.idx); }
    }

    // ground critters
    const bp = this.bugPos;
    for (let i = 0; i < this.bugHead.length; i++) {
      this.bugHead[i] += (Math.random() - 0.5) * 3 * dt;
      bp[i * 3] += Math.sin(this.bugHead[i]) * 0.25 * dt;
      bp[i * 3 + 2] += Math.cos(this.bugHead[i]) * 0.25 * dt;
      const dx = bp[i * 3] - pl.x, dz = bp[i * 3 + 2] - pl.z;
      if (dx * dx + dz * dz > 900) { const a = Math.random() * 6.28, r = 8 + Math.random() * 18; bp[i * 3] = pl.x + Math.cos(a) * r; bp[i * 3 + 2] = pl.z + Math.sin(a) * r; }
      const h = W.heightAt(bp[i * 3], bp[i * 3 + 2]);
      bp[i * 3 + 1] = h < 0.6 ? -50 : h + 0.06;
    }
    this.bugs.geometry.attributes.position.needsUpdate = true;
  }
}

function hooksChirp(h: WildHooks, v: number) { h.chirp(clamp(v, 0, 1)); }
