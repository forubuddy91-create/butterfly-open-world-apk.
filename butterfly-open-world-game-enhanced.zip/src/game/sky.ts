import * as THREE from 'three';
import { QualityCfg, WeatherMode } from './config';
import { U, CHUNK_PARS, CHUNK_END, GLSL_NOISE } from './shared';
import { World } from './terrain';
import { glowTex, leafSpriteTex, shaftTex, softTex } from './textures';
import { clamp, smoothstep, lerp } from './noise';

interface Key {
  h: number; top: string; hor: string; sun: string; sunI: number; hemiS: string; hemiG: string; hemiI: number; fog: string;
}
const KEYS: Key[] = [
  { h: 0, top: '#070d2c', hor: '#16204a', sun: '#8899ff', sunI: 0, hemiS: '#3a4a90', hemiG: '#141a30', hemiI: 0.9, fog: '#111a3a' },
  { h: 4.8, top: '#121a4a', hor: '#2c3770', sun: '#aa88cc', sunI: 0, hemiS: '#4a5a9a', hemiG: '#1c2036', hemiI: 0.95, fog: '#252e5e' },
  { h: 5.9, top: '#3c58a8', hor: '#f2a070', sun: '#ffa860', sunI: 1.8, hemiS: '#8a9cd0', hemiG: '#5a4c44', hemiI: 1.5, fog: '#e8b090' },
  { h: 7.5, top: '#4a88dc', hor: '#d4e2ee', sun: '#ffeccc', sunI: 2.9, hemiS: '#a4c4f0', hemiG: '#78885c', hemiI: 2.1, fog: '#cde0ec' },
  { h: 12, top: '#2c7cea', hor: '#b8e0f6', sun: '#fff6e4', sunI: 3.3, hemiS: '#b0d4ff', hemiG: '#88985c', hemiI: 2.4, fog: '#c0e0f2' },
  { h: 16, top: '#3a84e2', hor: '#d4e6ee', sun: '#ffe6bc', sunI: 3.0, hemiS: '#b4cef0', hemiG: '#8a9258', hemiI: 2.2, fog: '#d6e4e6' },
  { h: 18.1, top: '#5a62b0', hor: '#ff9658', sun: '#ff9248', sunI: 2.3, hemiS: '#b494a8', hemiG: '#6a4a3a', hemiI: 1.6, fog: '#f2a674' },
  { h: 19.5, top: '#222c70', hor: '#8a4c7c', sun: '#c07050', sunI: 0.4, hemiS: '#5a5c9c', hemiG: '#2a2a3c', hemiI: 1.1, fog: '#5c4a70' },
  { h: 21.2, top: '#0a1034', hor: '#1a2250', sun: '#8899ff', sunI: 0, hemiS: '#3a4a90', hemiG: '#141a30', hemiI: 0.9, fog: '#131c3e' },
  { h: 24, top: '#070d2c', hor: '#16204a', sun: '#8899ff', sunI: 0, hemiS: '#3a4a90', hemiG: '#141a30', hemiI: 0.9, fog: '#111a3a' },
];
const KC = KEYS.map((k) => ({
  h: k.h, top: new THREE.Color(k.top), hor: new THREE.Color(k.hor), sun: new THREE.Color(k.sun), sunI: k.sunI,
  hemiS: new THREE.Color(k.hemiS), hemiG: new THREE.Color(k.hemiG), hemiI: k.hemiI, fog: new THREE.Color(k.fog),
}));

const REGION_FOG = [
  { c: new THREE.Color('#a6dca8'), m: 0.22, d: 1.35, s: new THREE.Color('#fff2c4'), sm: 0.2 },
  { c: new THREE.Color('#ffc890'), m: 0.3, d: 0.9, s: new THREE.Color('#ff9a4c'), sm: 0.38 },
  { c: new THREE.Color('#a8e2f2'), m: 0.14, d: 1.0, s: new THREE.Color('#fff6ee'), sm: 0.1 },
  { c: new THREE.Color('#e0eaf6'), m: 0.2, d: 1.4, s: new THREE.Color('#ffe9cc'), sm: 0.15 },
];

const WEATHER: Record<string, { cloud: number; rain: number; mist: number; wind: number }> = {
  sunny: { cloud: 0.12, rain: 0, mist: 0, wind: 0.22 },
  cloudy: { cloud: 0.85, rain: 0, mist: 0.12, wind: 0.4 },
  rain: { cloud: 1, rain: 1, mist: 0.25, wind: 0.55 },
  windy: { cloud: 0.35, rain: 0, mist: 0, wind: 1 },
  mist: { cloud: 0.5, rain: 0, mist: 1, wind: 0.12 },
};

const POINT_VERT = `
  attribute vec4 aSeed; attribute vec3 aColor;
  uniform vec3 uCam; uniform float uTime, uBox, uSize, uSway, uViewH, uOpacity, uTwinkle;
  uniform vec3 uFall;
  varying vec3 vColor; varying float vAlpha; varying float vAng;
  void main(){
    vec3 o = aSeed.xyz * uBox;
    vec3 p = o + uFall * uTime;
    p.xz += vec2(sin(uTime*0.8 + aSeed.w*6.28), cos(uTime*0.7 + aSeed.w*9.0)) * uSway;
    p.y += sin(uTime*1.3 + aSeed.w*20.0) * uSway * 0.25;
    vec3 q = mod(p - uCam + vec3(uBox*0.5), uBox) - vec3(uBox*0.5);
    vec3 world = uCam + q;
    vec4 mv = viewMatrix * vec4(world, 1.0);
    float d = length(q) / (uBox*0.5);
    float fade = 1.0 - smoothstep(0.55, 1.0, d);
    float tw = mix(1.0, 0.5 + 0.5*sin(uTime*2.2 + aSeed.w*40.0), uTwinkle);
    vAlpha = fade * tw * uOpacity;
    vColor = aColor;
    vAng = aSeed.w*6.28 + uTime*(0.6 + aSeed.w);
    gl_PointSize = uSize * uViewH * 0.5 * projectionMatrix[1][1] / max(-mv.z, 0.1);
    gl_Position = projectionMatrix * mv;
  }`;
const POINT_FRAG = `
  ${CHUNK_PARS}
  uniform sampler2D uTex; uniform float uRotate;
  varying vec3 vColor; varying float vAlpha; varying float vAng;
  void main(){
    vec2 c = gl_PointCoord - 0.5;
    float a = vAng * uRotate;
    c = mat2(cos(a), -sin(a), sin(a), cos(a)) * c + 0.5;
    vec4 t = texture2D(uTex, c);
    gl_FragColor = vec4(vColor * t.rgb, t.a * vAlpha);
    if (gl_FragColor.a < 0.01) discard;
    ${CHUNK_END}
  }`;

class BoxParticles {
  points: THREE.Points;
  mat: THREE.ShaderMaterial;
  constructor(count: number, public box: number, o: {
    size: number; tex: THREE.Texture; additive: boolean; colors: string[]; fall: [number, number, number];
    sway: number; twinkle: number; rotate: number;
  }) {
    const seed = new Float32Array(count * 4), colr = new Float32Array(count * 3), pos = new Float32Array(count * 3);
    const cs = o.colors.map((c) => new THREE.Color(c));
    for (let i = 0; i < count; i++) {
      for (let k = 0; k < 4; k++) seed[i * 4 + k] = Math.random();
      const c = cs[Math.floor(Math.random() * cs.length)];
      const v = 0.8 + Math.random() * 0.4;
      colr[i * 3] = c.r * v; colr[i * 3 + 1] = c.g * v; colr[i * 3 + 2] = c.b * v;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 4));
    g.setAttribute('aColor', new THREE.BufferAttribute(colr, 3));
    this.mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      blending: o.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: {
        uCam: { value: new THREE.Vector3() }, uTime: U.uTime, uBox: { value: box }, uSize: { value: o.size },
        uSway: { value: o.sway }, uViewH: { value: 800 }, uOpacity: { value: 0 }, uTwinkle: { value: o.twinkle },
        uFall: { value: new THREE.Vector3(...o.fall) }, uTex: { value: o.tex }, uRotate: { value: o.rotate },
      },
      vertexShader: POINT_VERT, fragmentShader: POINT_FRAG,
    });
    this.points = new THREE.Points(g, this.mat);
    this.points.frustumCulled = false;
  }
  set opacity(v: number) { this.mat.uniforms.uOpacity.value = v; this.points.visible = v > 0.005; }
}

export class Atmosphere {
  scene: THREE.Scene;
  sky: THREE.Mesh;
  sun: THREE.DirectionalLight;
  moon: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  fog: THREE.FogExp2;
  hour = 7.6;
  mode: WeatherMode = 'auto';
  autoName = 'sunny';
  autoTimer = 60;
  cur = { cloud: 0.12, rain: 0, mist: 0.35, wind: 0.22 };
  rainMesh: THREE.LineSegments;
  leaves: BoxParticles; motes: BoxParticles; flies: BoxParticles;
  shafts: { g: THREE.Group; ox: number; oz: number; mats: THREE.MeshBasicMaterial[] }[] = [];
  sunDir = new THREE.Vector3(0, 1, 0);
  night = 0;
  daylight = 1;
  sunVis = 1;
  dayCycle = true;
  private rainU: Record<string, { value: unknown }>;
  private skyU: Record<string, { value: unknown }>;
  private tmpA = new THREE.Color();
  private tmpB = new THREE.Color();
  private shadowMapSize: number;
  private range: number;

  constructor(scene: THREE.Scene, q: QualityCfg, private world: World) {
    this.scene = scene;
    this.fog = new THREE.FogExp2(0xbfe0f0, 0.0016);
    scene.fog = this.fog;

    this.skyU = {
      uTop: U.uSkyTop, uHor: U.uSkyHor, uSunDir: U.uSunDir, uSunColor: U.uSunColor, uTime: U.uTime,
      uCloud: { value: 0.2 }, uNight: { value: 0 }, uRain: U.uRain,
    };
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false, uniforms: this.skyU as never,
      vertexShader: `varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix*modelViewMatrix*vec4(position,1.0); gl_Position = p.xyww; }`,
      fragmentShader: `
        ${CHUNK_PARS}
        ${GLSL_NOISE}
        uniform vec3 uTop, uHor, uSunDir, uSunColor; uniform float uTime, uCloud, uNight, uRain;
        varying vec3 vDir;
        float fbm(vec2 p){ float s=0.0, a=0.5; for(int i=0;i<${q.cloudOct};i++){ s+=a*vnoise(p); p=p*2.03+vec2(1.7,9.2); a*=0.5; } return s; }
        void main(){
          vec3 d = normalize(vDir);
          float h = max(d.y, 0.0);
          vec3 col = mix(uHor, uTop, pow(h, 0.5));
          col = mix(col, uHor, smoothstep(0.0, -0.25, d.y));
          float sd = max(dot(d, uSunDir), 0.0);
          vec3 sc = uSunColor;
          col += sc * (pow(sd, 5.0)*0.22 + pow(sd, 48.0)*0.4);
          col += sc * smoothstep(0.9992, 0.9997, sd) * 6.0 * step(0.0, uSunDir.y + 0.02);
          // moon
          float md = max(dot(d, -uSunDir), 0.0);
          col += vec3(0.75,0.85,1.0) * (smoothstep(0.9993, 0.9996, md)*2.2 + pow(md, 60.0)*0.25) * uNight;
          // stars
          vec2 sp = d.xz / (d.y + 1.2) * 90.0;
          float st = step(0.9965, hash21(floor(sp))) * smoothstep(0.1, 0.5, d.y);
          col += vec3(1.0) * st * uNight * (0.6 + 0.4*sin(uTime*2.0 + hash21(floor(sp))*40.0));
          // clouds
          if (d.y > -0.02) {
            vec2 uv = d.xz / (max(d.y, 0.0) + 0.22) * 0.55 + vec2(uTime*0.004, uTime*0.0016);
            float c = fbm(uv*1.6);
            float cov = mix(0.6, 0.28, uCloud);
            float m = smoothstep(cov, cov + 0.22, c);
            float c2 = fbm(uv*1.6 + uSunDir.xz*0.12);
            float lit = clamp((c - c2)*4.0 + 0.62, 0.0, 1.0);
            vec3 cLit = mix(vec3(1.0), sc, 0.4) * (0.55 + 0.6*clamp(uSunDir.y + 0.4, 0.0, 1.0));
            vec3 cDark = mix(uHor, uTop, 0.35) * 0.9 + 0.12;
            cDark = mix(cDark, vec3(0.38,0.42,0.48), uRain*0.7);
            vec3 cc = mix(cDark, cLit, lit);
            cc = mix(cc, uHor*1.1, 0.0);
            cc *= mix(1.0, 0.25, uNight);
            float fadeH = smoothstep(0.0, 0.18, d.y);
            col = mix(col, cc, m * fadeH * 0.96);
          }
          gl_FragColor = vec4(col, 1.0);
          ${CHUNK_END}
        }`,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1500, 32, 16), skyMat);
    this.sky.frustumCulled = false;
    this.sky.renderOrder = -10;
    scene.add(this.sky);

    this.hemi = new THREE.HemisphereLight(0xb0d0ff, 0x88a060, 2.2);
    scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff0d0, 3);
    this.range = q.shadowRange;
    this.shadowMapSize = q.shadowMap;
    if (q.shadowMap > 0) {
      this.sun.castShadow = true;
      this.sun.shadow.mapSize.set(q.shadowMap, q.shadowMap);
      const c = this.sun.shadow.camera;
      c.left = -this.range; c.right = this.range; c.top = this.range; c.bottom = -this.range; c.near = 1; c.far = 400;
      this.sun.shadow.bias = -0.0005;
      this.sun.shadow.normalBias = 0.35;
    }
    scene.add(this.sun, this.sun.target);
    this.moon = new THREE.DirectionalLight(0x8fa8ff, 0.4);
    scene.add(this.moon, this.moon.target);

    // rain
    const rc = q.rain;
    const rpos = new Float32Array(rc * 6), roff = new Float32Array(rc * 6), rend = new Float32Array(rc * 2);
    for (let i = 0; i < rc; i++) {
      const x = Math.random(), y = Math.random(), z = Math.random();
      for (let k = 0; k < 2; k++) {
        roff[(i * 2 + k) * 3] = x; roff[(i * 2 + k) * 3 + 1] = y; roff[(i * 2 + k) * 3 + 2] = z;
        rend[i * 2 + k] = k;
      }
    }
    const rg = new THREE.BufferGeometry();
    rg.setAttribute('position', new THREE.BufferAttribute(rpos, 3));
    rg.setAttribute('aOff', new THREE.BufferAttribute(roff, 3));
    rg.setAttribute('aEnd', new THREE.BufferAttribute(rend, 1));
    this.rainU = {
      uCam: { value: new THREE.Vector3() }, uTime: U.uTime, uBox: { value: 40 }, uRain: U.uRain, uWind: U.uWind,
    };
    this.rainMesh = new THREE.LineSegments(rg, new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, uniforms: this.rainU as never,
      vertexShader: `
        attribute vec3 aOff; attribute float aEnd; uniform vec3 uCam; uniform float uTime, uBox, uRain, uWind;
        varying float vA;
        void main(){
          vec3 o = aOff*uBox;
          vec3 p = o + vec3(uWind*3.0, -24.0, uWind*1.5)*uTime;
          vec3 q = mod(p - uCam + vec3(uBox*0.5), uBox) - vec3(uBox*0.5);
          vec3 w = uCam + q;
          w += aEnd * vec3(-uWind*0.12, 0.7, -uWind*0.06);
          float d = length(q)/(uBox*0.5);
          vA = (1.0 - smoothstep(0.5, 1.0, d)) * uRain * (0.35 + 0.3*aEnd);
          gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
        }`,
      fragmentShader: `${CHUNK_PARS} varying float vA; void main(){ gl_FragColor = vec4(0.75,0.85,1.0, vA*0.8); ${CHUNK_END} }`,
    }));
    this.rainMesh.frustumCulled = false;
    this.rainMesh.visible = false;
    scene.add(this.rainMesh);

    const pc = q.particles;
    this.leaves = new BoxParticles(Math.floor(140 * pc), 44, {
      size: 0.2, tex: leafSpriteTex(), additive: false, colors: ['#7ec23a', '#a8d040', '#e0b030', '#e87a2a', '#5aa02e'],
      fall: [0.4, -1.0, 0.25], sway: 1.8, twinkle: 0, rotate: 1,
    });
    this.motes = new BoxParticles(Math.floor(320 * pc), 40, {
      size: 0.05, tex: softTex(), additive: true, colors: ['#fff4cc', '#ffffff', '#d8ffd0'], fall: [0.03, 0.09, 0.02], sway: 0.9, twinkle: 0.4, rotate: 0,
    });
    this.flies = new BoxParticles(Math.floor(130 * pc), 56, {
      size: 0.16, tex: glowTex(), additive: true, colors: ['#d2ff70', '#a8ff80', '#ffee80'], fall: [0, 0.03, 0], sway: 3.0, twinkle: 1, rotate: 0,
    });
    scene.add(this.leaves.points, this.motes.points, this.flies.points);

    // sun shafts
    const st = shaftTex();
    const nShafts = Math.floor(16 * Math.min(1, q.particles + 0.3));
    for (let i = 0; i < nShafts; i++) {
      const g = new THREE.Group();
      const mats: THREE.MeshBasicMaterial[] = [];
      for (let k = 0; k < 2; k++) {
        const m = new THREE.MeshBasicMaterial({
          map: st, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false, opacity: 0,
          color: 0xfff0c0,
        });
        const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2.4 + Math.random() * 5, 70), m);
        mesh.rotation.y = k * Math.PI / 2;
        g.add(mesh); mats.push(m);
      }
      this.shafts.push({ g, ox: Math.random() * 100, oz: Math.random() * 100, mats });
      scene.add(g);
    }
  }

  setViewHeight(h: number) {
    for (const b of [this.leaves, this.motes, this.flies]) b.mat.uniforms.uViewH.value = h;
  }

  setMode(m: WeatherMode) { this.mode = m; if (m === 'auto') this.pickAuto(); }
  private pickAuto() {
    const r = Math.random();
    this.autoName = r < 0.42 ? 'sunny' : r < 0.58 ? 'cloudy' : r < 0.72 ? 'windy' : r < 0.86 ? 'rain' : 'mist';
    this.autoTimer = 90 + Math.random() * 120;
  }

  weatherLabel() {
    const c = this.cur;
    if (c.rain > 0.45) return 'Rain';
    if (c.mist > 0.55) return 'Mist';
    if (c.cloud > 0.6) return 'Cloudy';
    if (c.wind > 0.7) return 'Windy';
    return 'Clear';
  }

  private keyAt(h: number) {
    let i = 0;
    while (i < KC.length - 2 && h >= KC[i + 1].h) i++;
    const a = KC[i], b = KC[i + 1];
    const t = clamp((h - a.h) / (b.h - a.h), 0, 1);
    return { a, b, t: t * t * (3 - 2 * t) };
  }

  update(dt: number, cam: THREE.Vector3, focus: THREE.Vector3, rw: number[], timeScale: number) {
    // time
    this.hour = (this.hour + (dt * timeScale) / 90) % 24;
    U.uTime.value += dt;
    // weather
    const name = this.mode === 'auto' ? this.autoName : this.mode;
    if (this.mode === 'auto') { this.autoTimer -= dt; if (this.autoTimer <= 0) this.pickAuto(); }
    const tg = { ...WEATHER[name] };
    if (this.mode === 'auto' || this.mode === 'sunny') {
      const morning = smoothstep(4.8, 6, this.hour) * smoothstep(9.6, 7.4, this.hour);
      tg.mist = Math.max(tg.mist, 0.7 * morning);
    }
    const k = 1 - Math.exp(-dt * 0.3);
    (Object.keys(this.cur) as (keyof typeof this.cur)[]).forEach((key) => { this.cur[key] += (tg[key] - this.cur[key]) * k; });
    const W = this.cur;
    const gust = 0.5 + 0.5 * Math.sin(U.uTime.value * 0.35) * Math.sin(U.uTime.value * 0.13 + 1);
    U.uWind.value = clamp(W.wind * (0.7 + 0.5 * gust), 0, 1.3);
    U.uRain.value = W.rain;

    // sun
    const a = ((this.hour - 6) / 12) * Math.PI;
    this.sunDir.set(Math.cos(a), Math.sin(a), 0.32).normalize();
    U.uSunDir.value.copy(this.sunDir);
    const sy = this.sunDir.y;
    this.sunVis = smoothstep(-0.03, 0.1, sy);
    this.night = 1 - smoothstep(-0.16, 0.08, sy);
    this.daylight = clamp(0.14 + 0.86 * smoothstep(-0.06, 0.4, sy), 0, 1);
    U.uLight.value = this.daylight;

    const { a: ka, b: kb, t } = this.keyAt(this.hour);
    const top = this.tmpA.copy(ka.top).lerp(kb.top, t).clone();
    const hor = ka.hor.clone().lerp(kb.hor, t);
    const sunC = ka.sun.clone().lerp(kb.sun, t);
    const hemiS = ka.hemiS.clone().lerp(kb.hemiS, t);
    const hemiG = ka.hemiG.clone().lerp(kb.hemiG, t);
    const fogC = ka.fog.clone().lerp(kb.fog, t);
    let sunI = lerp(ka.sunI, kb.sunI, t) * this.sunVis;
    let hemiI = lerp(ka.hemiI, kb.hemiI, t);

    // weather grading
    const grey = new THREE.Color('#8e99a6');
    const dull = clamp(W.cloud * 0.55 + W.rain * 0.25, 0, 0.85);
    const dayAmt = this.daylight;
    top.lerp(grey.clone().multiplyScalar(0.55 + 0.45 * dayAmt), dull * dayAmt);
    hor.lerp(grey.clone().multiplyScalar(0.6 + 0.5 * dayAmt), dull * 0.8 * dayAmt);
    fogC.lerp(grey.clone().multiplyScalar(0.55 + 0.5 * dayAmt), dull * 0.7 * dayAmt);
    fogC.lerp(new THREE.Color('#dfe6ee').multiplyScalar(0.3 + 0.7 * dayAmt), W.mist * 0.55 * dayAmt);
    sunI *= 1 - 0.62 * W.cloud - 0.25 * W.rain;
    hemiI *= 1 - 0.12 * W.cloud;

    // region tint
    let fd = 0;
    const regionFog = new THREE.Color(0, 0, 0), regionSun = new THREE.Color(0, 0, 0);
    let fm = 0, sm = 0;
    for (let i = 0; i < 4; i++) {
      const R = REGION_FOG[i];
      fd += rw[i] * R.d; fm += rw[i] * R.m; sm += rw[i] * R.sm;
      regionFog.add(this.tmpB.copy(R.c).multiplyScalar(rw[i]));
      regionSun.add(this.tmpB.copy(R.s).multiplyScalar(rw[i]));
    }
    fogC.lerp(regionFog.multiplyScalar(0.3 + 0.7 * dayAmt), fm * dayAmt);
    sunC.lerp(regionSun, sm * this.sunVis);
    hemiS.lerp(regionFog, 0.1 * dayAmt);

    U.uSkyTop.value.copy(top);
    U.uSkyHor.value.copy(hor);
    U.uSunColor.value.copy(sunC).multiplyScalar(Math.min(1.2, 0.35 + sunI * 0.3));
    this.skyU.uCloud.value = W.cloud;
    this.skyU.uNight.value = this.night;

    U.uFogColor.value.copy(fogC);
    const baseD = 0.0014 + W.mist * 0.0085 * (0.6 + 0.4 * dayAmt) + W.rain * 0.0022 + W.cloud * 0.0003;
    U.uFogDensity.value = baseD * fd;
    this.fog.color.copy(fogC);
    this.fog.density = U.uFogDensity.value;

    this.hemi.color.copy(hemiS);
    this.hemi.groundColor.copy(hemiG);
    this.hemi.intensity = hemiI;
    this.sun.color.copy(sunC);
    this.sun.intensity = sunI;
    const wasCast = this.sun.castShadow;
    const shouldCast = this.shadowMapSize > 0 && sunI > 0.08;
    if (wasCast !== shouldCast) this.sun.castShadow = shouldCast;
    // shadows follow the player
    const dir = this.sunDir;
    this.sun.target.position.copy(focus);
    this.sun.position.copy(focus).addScaledVector(dir, 140);
    this.moon.target.position.copy(focus);
    this.moon.position.copy(focus).addScaledVector(dir, -100);
    this.moon.intensity = 0.55 * this.night * (1 - W.cloud * 0.5);

    this.sky.position.copy(cam);

    // precipitation & particles
    this.rainMesh.visible = W.rain > 0.03;
    (this.rainU.uCam.value as THREE.Vector3).copy(cam);
    const treeW = rw[0] * 1 + rw[3] * 0.5 + rw[2] * 0.6 + rw[1] * 0.2;
    this.leaves.opacity = (0.25 + 0.75 * U.uWind.value) * treeW * 0.95 * (1 - W.rain * 0.8) * this.daylight;
    this.motes.opacity = this.daylight * this.sunVis * (1 - W.rain) * (1 - W.mist * 0.4) * 0.8;
    this.flies.opacity = this.night * (1 - W.rain) * (0.3 + 0.7 * (rw[0] + rw[1] + rw[2])) * 1.0;
    for (const b of [this.leaves, this.motes, this.flies]) b.mat.uniforms.uCam.value.copy(cam);

    // sun shafts
    const shaftStrength = smoothstep(0.08, 0.4, sy) * (1 - smoothstep(0.82, 0.98, sy) * 0.5) * (1 - W.cloud * 0.8) * (1 - W.rain);
    const shaftAmt = shaftStrength * (rw[0] * 1.0 + rw[3] * 0.55 + rw[2] * 0.4 + rw[1] * 0.2 + W.mist * 0.7);
    const B = 110;
    const up = new THREE.Vector3(0, 1, 0);
    const q = new THREE.Quaternion().setFromUnitVectors(up, dir);
    this.shafts.forEach((s, i) => {
      const dx = ((((s.ox - cam.x) % B) + B) % B) - B / 2, dz = ((((s.oz - cam.z) % B) + B) % B) - B / 2;
      const x = cam.x + dx, z = cam.z + dz;
      const y = this.world.heightAt(x, z);
      s.g.position.set(x, y, z).addScaledVector(dir, 30);
      s.g.quaternion.copy(q);
      const edge = 1 - smoothstep(0.55, 1, Math.hypot(dx, dz) / (B / 2));
      const flick = 0.75 + 0.25 * Math.sin(U.uTime.value * 0.6 + i * 1.7);
      for (const m of s.mats) { m.opacity = 0.16 * shaftAmt * edge * flick; m.color.copy(sunC); }
      s.g.visible = shaftAmt > 0.01;
    });
  }
}
