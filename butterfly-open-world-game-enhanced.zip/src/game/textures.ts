import * as THREE from 'three';
import { hash2, mulberry32 } from './noise';

export function canvasTex(w: number, h: number, draw: (ctx: CanvasRenderingContext2D, c: HTMLCanvasElement) => void, srgb = true) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d')!, c);
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

export function softTex() {
  return canvasTex(64, 64, (g) => {
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.35, 'rgba(255,255,255,0.55)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  });
}

export function glowTex() {
  return canvasTex(128, 128, (g) => {
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.15, 'rgba(255,255,255,0.7)');
    gr.addColorStop(0.5, 'rgba(255,255,255,0.12)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  });
}

export function leafSpriteTex() {
  return canvasTex(64, 64, (g) => {
    g.translate(32, 32); g.rotate(-0.6);
    const gr = g.createLinearGradient(-26, 0, 26, 0);
    gr.addColorStop(0, '#ffffff'); gr.addColorStop(1, '#b8b8b8');
    g.fillStyle = gr;
    g.beginPath(); g.ellipse(0, 0, 26, 11, 0, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(80,80,80,0.6)'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(-24, 0); g.lineTo(24, 0); g.stroke();
  });
}

export function leafClumpTex(seed: number) {
  const r = mulberry32(seed);
  return canvasTex(128, 128, (g) => {
    g.clearRect(0, 0, 128, 128);
    for (let i = 0; i < 46; i++) {
      const a = r() * Math.PI * 2, d = Math.sqrt(r()) * 52;
      const x = 64 + Math.cos(a) * d, y = 64 + Math.sin(a) * d;
      const rot = r() * Math.PI * 2;
      const L = 13 + r() * 9, W = 5.5 + r() * 3;
      g.save(); g.translate(x, y); g.rotate(rot);
      const v = 150 + Math.floor(r() * 105);
      const gr = g.createLinearGradient(-L, -W, L, W);
      gr.addColorStop(0, `rgb(${v},${v},${v})`);
      gr.addColorStop(1, `rgb(${Math.max(90, v - 70)},${Math.max(90, v - 70)},${Math.max(90, v - 70)})`);
      g.fillStyle = gr;
      g.beginPath(); g.ellipse(0, 0, L, W, 0, 0, Math.PI * 2); g.fill();
      g.strokeStyle = 'rgba(70,70,70,0.55)'; g.lineWidth = 1;
      g.beginPath(); g.moveTo(-L, 0); g.lineTo(L, 0); g.stroke();
      g.restore();
    }
  });
}

export function stoneTex() {
  return canvasTex(256, 256, (g) => {
    const img = g.createImageData(256, 256);
    for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
      let n = 0, a = 0.5, f = 8;
      for (let o = 0; o < 4; o++) {
        const ix = Math.floor(x / (256 / f)), iy = Math.floor(y / (256 / f));
        n += a * hash2(ix % f, iy % f, o * 7 + 3);
        a *= 0.5; f *= 2;
      }
      const v = 150 + n * 90;
      const i = (y * 256 + x) * 4;
      img.data[i] = v; img.data[i + 1] = v * 0.98; img.data[i + 2] = v * 0.94; img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    const r = mulberry32(5);
    g.strokeStyle = 'rgba(40,36,30,0.55)'; g.lineWidth = 2;
    for (let row = 0; row < 8; row++) {
      const y = row * 32;
      g.beginPath(); g.moveTo(0, y); g.lineTo(256, y); g.stroke();
      const off = (row % 2) * 40;
      for (let x = off; x < 256; x += 80) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 32); g.stroke(); }
    }
    g.lineWidth = 1;
    for (let i = 0; i < 40; i++) {
      g.beginPath(); let x = r() * 256, y = r() * 256; g.moveTo(x, y);
      for (let k = 0; k < 4; k++) { x += (r() - 0.5) * 24; y += (r() - 0.3) * 22; g.lineTo(x, y); }
      g.stroke();
    }
  });
}

function tileNoise(x: number, y: number, per: number, seed: number) {
  const ix = Math.floor(x), iy = Math.floor(y);
  const fx = x - ix, fy = y - iy;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  const a = hash2(ix % per, iy % per, seed), b = hash2((ix + 1) % per, iy % per, seed);
  const c = hash2(ix % per, (iy + 1) % per, seed), d = hash2((ix + 1) % per, (iy + 1) % per, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

export function detailTex() {
  // Higher-resolution repeating ground detail reduces visible texture pixelation.
  const S = 512;
  const data = new Uint8Array(S * S * 4);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    let r = 0, g = 0;
    r += tileNoise(x / S * 16, y / S * 16, 16, 1) * 0.5;
    r += tileNoise(x / S * 32, y / S * 32, 32, 2) * 0.3;
    r += tileNoise(x / S * 64, y / S * 64, 64, 3) * 0.2;
    g += tileNoise(x / S * 4, y / S * 4, 4, 4) * 0.6;
    g += tileNoise(x / S * 8, y / S * 8, 8, 5) * 0.4;
    const i = (y * S + x) * 4;
    data[i] = r * 255; data[i + 1] = g * 255; data[i + 2] = 128; data[i + 3] = 255;
  }
  const t = new THREE.DataTexture(data, S, S, THREE.RGBAFormat);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.generateMipmaps = true;
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

export function shaftTex() {
  return canvasTex(64, 256, (g) => {
    const h = g.createLinearGradient(0, 0, 0, 256);
    h.addColorStop(0, 'rgba(255,255,255,0.0)');
    h.addColorStop(0.2, 'rgba(255,255,255,0.85)');
    h.addColorStop(0.7, 'rgba(255,255,255,0.5)');
    h.addColorStop(1, 'rgba(255,255,255,0.0)');
    g.fillStyle = h; g.fillRect(0, 0, 64, 256);
    g.globalCompositeOperation = 'destination-in';
    const w = g.createLinearGradient(0, 0, 64, 0);
    w.addColorStop(0, 'rgba(0,0,0,0)'); w.addColorStop(0.5, 'rgba(0,0,0,1)'); w.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = w; g.fillRect(0, 0, 64, 256);
  }, false);
}
