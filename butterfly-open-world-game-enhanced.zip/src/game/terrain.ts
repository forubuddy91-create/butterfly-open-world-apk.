import * as THREE from 'three';
import { fbm, ridged, lerp, smoothstep, clamp, mulberry32 } from './noise';
import { HALF, WORLD, WATER_LEVEL, RegionId } from './config';
import { U, CHUNK_PARS, CHUNK_END, GLSL_NOISE } from './shared';
import { detailTex, softTex } from './textures';

export const REGION_C: [number, number][] = [[-210, 210], [210, 210], [-210, -210], [210, -210]];
const SIG = [160, 170, 150, 170];
export const REGION_IDS: RegionId[] = ['forest', 'meadow', 'lake', 'mountain'];

export const LAKE = { x: -210, z: -210, R: 108 };
export const POND = { x: -140, z: 238, R: 24 };
export const PLAT = { x0: -300, x1: -120, z1: -338, h: 36 };
export const FALLS = [{ x: -232, w: 6.5 }, { x: -178, w: 5 }];

const riverCurve = new THREE.CatmullRomCurve3(
  [[-210, -120], [-228, -70], [-205, -20], [-165, 35], [-148, 95], [-165, 155], [-150, 210], [-138, 236]].map(
    (p) => new THREE.Vector3(p[0], 0, p[1]),
  ),
);
export const RIVER_PTS = riverCurve.getPoints(90);

export const PATHS: [number, number][][] = [
  [[-186, 196], [-130, 207], [-60, 212], [20, 196], [100, 202], [170, 207], [228, 190]],
  [[-186, 196], [-176, 140], [-186, 80], [-216, 30]],
  [[228, 190], [200, 120], [214, 40], [226, -40], [214, -120], [226, -205]],
  [[-60, 212], [-50, 130], [-70, 40], [-110, -40]],
];

export function regionWeights(x: number, z: number, out: number[] = [0, 0, 0, 0]) {
  let sum = 0;
  for (let i = 0; i < 4; i++) {
    const dx = x - REGION_C[i][0], dz = z - REGION_C[i][1];
    const w = Math.exp(-(dx * dx + dz * dz) / (2 * SIG[i] * SIG[i]));
    out[i] = w; sum += w;
  }
  const inv = 1 / Math.max(sum, 1e-9);
  for (let i = 0; i < 4; i++) out[i] *= inv;
  return out;
}

function segDist(px: number, pz: number, ax: number, az: number, bx: number, bz: number) {
  const dx = bx - ax, dz = bz - az;
  const t = clamp(((px - ax) * dx + (pz - az) * dz) / (dx * dx + dz * dz + 1e-9), 0, 1);
  return Math.hypot(ax + dx * t - px, az + dz * t - pz);
}

export function distToRiver(x: number, z: number) {
  let d = 1e9;
  for (let i = 0; i < RIVER_PTS.length - 1; i++) {
    const a = RIVER_PTS[i], b = RIVER_PTS[i + 1];
    const dd = segDist(x, z, a.x, a.z, b.x, b.z);
    if (dd < d) d = dd;
  }
  return d;
}

const _w = [0, 0, 0, 0];
export function heightRaw(x: number, z: number): number {
  const w = regionWeights(x, z, _w);
  const hf = 5 + (fbm(x * 0.006 + 10, z * 0.006, 4, 1) - 0.5) * 24 + (fbm(x * 0.045, z * 0.045, 3, 2) - 0.5) * 3.2;
  const hm = 9 + (fbm(x * 0.0055 + 50, z * 0.0055 + 20, 4, 3) - 0.5) * 50 + (fbm(x * 0.03, z * 0.03, 2, 4) - 0.5) * 2.5;
  const hl = 4 + (fbm(x * 0.007 + 90, z * 0.007, 4, 5) - 0.5) * 16;
  const ht = 24 + ridged(x * 0.0045 + 7, z * 0.0045 + 3, 5, 6) * 80 + (fbm(x * 0.03, z * 0.03, 3, 7) - 0.5) * 8;
  let h = w[0] * hf + w[1] * hm + w[2] * hl + w[3] * ht;
  if (h < 5) h = 5 + (h - 5) * 0.2; // soft floor: only deliberate bodies of water dip below sea level

  // great peak
  const px = x - 265, pz = z + 275;
  const pk = Math.exp(-(px * px + pz * pz) / (2 * 80 * 80));
  if (pk > 0.002) h += 105 * pk * (0.55 + 0.9 * ridged(x * 0.012 + 3, z * 0.012, 4, 8));

  // lake bowl
  {
    const dx = x - LAKE.x, dz = z - LAKE.z;
    const d = Math.hypot(dx, dz), ang = Math.atan2(dz, dx);
    const R = LAKE.R + 14 * Math.sin(3 * ang + 1) + 8 * Math.sin(5 * ang + 2);
    const s = d / R;
    if (s < 1.6) {
      const bed = -0.9 - 11 * (1 - Math.min(1, s * s));
      h = lerp(h, bed, smoothstep(1.6, 0.92, s));
    }
  }
  // forest pond
  {
    const dx = x - POND.x, dz = z - POND.z;
    const s = Math.hypot(dx, dz) / (POND.R * (1 + 0.15 * Math.sin(Math.atan2(dz, dx) * 4)));
    if (s < 1.8) {
      const bed = -0.9 - 3.2 * (1 - Math.min(1, s * s));
      h = lerp(h, bed, smoothstep(1.8, 0.95, s));
    }
  }
  // river
  if (x > -300 && x < -80 && z > -150 && z < 280) {
    const rd = distToRiver(x, z);
    const rw = 4.2;
    h = lerp(h, -1.5, smoothstep(rw * 5.5, rw * 0.9, rd));
  }
  // waterfall plateau
  {
    const mx = smoothstep(PLAT.x0 - 20, PLAT.x0 + 20, x) * smoothstep(PLAT.x1 + 20, PLAT.x1 - 20, x);
    const mz = smoothstep(PLAT.z1 + 8, PLAT.z1 - 8, z);
    const m = mx * mz;
    if (m > 0) {
      h = lerp(h, PLAT.h + (fbm(x * 0.05, z * 0.05, 2, 11) - 0.5) * 1.4, m);
      for (const f of FALLS) {
        const q = (x - f.x) / (f.w * 0.62);
        h -= 2.4 * Math.exp(-q * q) * m;
      }
    }
  }
  // world edge mountain wall
  const m2 = Math.max(Math.abs(x), Math.abs(z));
  if (m2 > 340) {
    const e = smoothstep(350, 470, m2);
    h += e * (60 + 150 * ridged(x * 0.006 + 11, z * 0.006 + 5, 4, 9)) + smoothstep(470, 540, m2) * 90;
  }
  return h;
}

export interface Perch { pos: THREE.Vector3; kind: 'leaf' | 'branch' | 'rock' | 'ruin' | 'canopy'; }

export class World {
  seg: number;
  step: number;
  hm: Float32Array;
  pathData!: Uint8ClampedArray;
  pathTex!: THREE.CanvasTexture;
  group = new THREE.Group();
  terrain!: THREE.Mesh;
  water!: THREE.Mesh;
  fallMeshes: THREE.Mesh[] = [];
  fallBase: THREE.Vector3[] = [];
  waterVerts: { x: number; z: number; d: number }[] = [];
  mist!: THREE.Points;
  mistData: { x: number; y: number; z: number; v: number; ph: number; bx: number; bz: number }[] = [];
  perches: Perch[] = [];

  constructor(seg: number) {
    this.seg = seg;
    this.step = WORLD / seg;
    this.hm = new Float32Array((seg + 1) * (seg + 1));
    const n = seg + 1;
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      this.hm[j * n + i] = heightRaw(-HALF + i * this.step, -HALF + j * this.step);
    }
    this.buildPathMap();
  }

  heightAt(x: number, z: number): number {
    const n = this.seg + 1;
    let fx = (x + HALF) / this.step, fz = (z + HALF) / this.step;
    fx = clamp(fx, 0, this.seg - 0.001); fz = clamp(fz, 0, this.seg - 0.001);
    const i = Math.floor(fx), j = Math.floor(fz);
    const tx = fx - i, tz = fz - j;
    const h = this.hm;
    const a = h[j * n + i], b = h[j * n + i + 1], c = h[(j + 1) * n + i], d = h[(j + 1) * n + i + 1];
    return a + (b - a) * tx + (c - a) * tz + (a - b - c + d) * tx * tz;
  }

  slopeAt(x: number, z: number) {
    const e = 1.5;
    const dx = this.heightAt(x + e, z) - this.heightAt(x - e, z);
    const dz = this.heightAt(x, z + e) - this.heightAt(x, z - e);
    return Math.hypot(dx, dz) / (2 * e);
  }

  regionAt(x: number, z: number): RegionId {
    const w = regionWeights(x, z);
    let bi = 0;
    for (let i = 1; i < 4; i++) if (w[i] > w[bi]) bi = i;
    return REGION_IDS[bi];
  }

  pathMask(x: number, z: number): number {
    const u = clamp(Math.floor(((x + HALF) / WORLD) * 1024), 0, 1023);
    const v = clamp(Math.floor(((z + HALF) / WORLD) * 1024), 0, 1023);
    return this.pathData[(v * 1024 + u) * 4] / 255;
  }

  /** closeness to running water (0..1) and waterfalls (0..1) for ambient audio */
  waterNear(x: number, z: number) {
    const dl = Math.hypot(x - LAKE.x, z - LAKE.z) - LAKE.R * 1.1;
    let water = Math.exp(-Math.max(0, dl) / 35);
    const dp = Math.hypot(x - POND.x, z - POND.z) - POND.R;
    water = Math.max(water, Math.exp(-Math.max(0, dp) / 25) * 0.7);
    if (x > -300 && x < -80 && z > -150 && z < 280) water = Math.max(water, Math.exp(-distToRiver(x, z) / 22) * 0.8);
    let fall = 0;
    for (const b of this.fallBase) fall = Math.max(fall, Math.exp(-Math.hypot(x - b.x, z - b.z) / 55));
    return { water, fall };
  }

  private buildPathMap() {
    const c = document.createElement('canvas');
    c.width = c.height = 1024;
    const g = c.getContext('2d')!;
    g.fillStyle = '#000'; g.fillRect(0, 0, 1024, 1024);
    g.strokeStyle = '#fff'; g.lineCap = 'round'; g.lineJoin = 'round';
    const r = mulberry32(77);
    const k = 1024 / WORLD;
    for (const p of PATHS) {
      const curve = new THREE.CatmullRomCurve3(p.map((q) => new THREE.Vector3(q[0], 0, q[1])));
      const pts = curve.getPoints(120);
      g.shadowColor = '#fff'; g.shadowBlur = 3;
      g.lineWidth = 3.4 * k * 1.0;
      g.beginPath();
      pts.forEach((q, i) => {
        const wob = Math.sin(i * 0.37) * 2.5 + (r() - 0.5) * 0.8;
        const X = (q.x + wob + HALF) * k, Y = (q.z + Math.cos(i * 0.31) * 2.5 + HALF) * k;
        if (i === 0) g.moveTo(X, Y); else g.lineTo(X, Y);
      });
      g.stroke();
    }
    this.pathData = g.getImageData(0, 0, 1024, 1024).data;
    this.pathTex = new THREE.CanvasTexture(c);
    this.pathTex.flipY = false;
    this.pathTex.wrapS = this.pathTex.wrapT = THREE.ClampToEdgeWrapping;
  }

  build(scene: THREE.Scene) {
    this.buildTerrain();
    this.buildWater();
    this.buildFalls();
    scene.add(this.group);
  }

  private buildTerrain() {
    const n = this.seg + 1;
    const pos = new Float32Array(n * n * 3);
    const col = new Float32Array(n * n * 3);
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      const k = (j * n + i) * 3;
      pos[k] = -HALF + i * this.step; pos[k + 1] = this.hm[j * n + i]; pos[k + 2] = -HALF + j * this.step;
    }
    const idx = new Uint32Array(this.seg * this.seg * 6);
    let q = 0;
    for (let j = 0; j < this.seg; j++) for (let i = 0; i < this.seg; i++) {
      const a = j * n + i, b = a + 1, c = a + n, d = c + 1;
      idx[q++] = a; idx[q++] = c; idx[q++] = b; idx[q++] = b; idx[q++] = c; idx[q++] = d;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.computeVertexNormals();
    const nor = geo.attributes.normal.array as Float32Array;

    const C = (h: string) => new THREE.Color(h);
    // Rich, layered forest and meadow palette inspired by the supplied environment reference.
    const cF1 = C('#1a5c18'), cF2 = C('#0e3d14');
    const cF3 = C('#2e7a1a'), cF4 = C('#4a9a20');
    const cM1 = C('#7ec830'), cM2 = C('#a8d840');
    const cM3 = C('#5aaa14'), cM4 = C('#c8e040');
    const cL = C('#2a8a40'), cL2 = C('#1a6830');
    const cT = C('#4a7a28'), cT2 = C('#3a6020');
    const rock = C('#7a7568'), rock2 = C('#5c5650'), rock3 = C('#9a9080');
    const lichen = C('#4a6030');
    const sand = C('#c8b878'), wet = C('#3a7860');
    const snowline = C('#ddeeff');
    const tmp = new THREE.Color();
    const w = [0, 0, 0, 0];
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      const k = (j * n + i) * 3;
      const x = pos[k], h = pos[k + 1], z = pos[k + 2];
      regionWeights(x, z, w);
      const n1 = fbm(x * 0.018, z * 0.018, 4, 21);
      const n2 = fbm(x * 0.065, z * 0.065, 3, 22);
      const n3 = fbm(x * 0.008, z * 0.008, 3, 23);
      const n4 = fbm(x * 0.14, z * 0.14, 2, 24);
      const base = new THREE.Color(0, 0, 0);
      const fCol = new THREE.Color().copy(cF1).lerp(cF2, n2 * 0.7).lerp(cF3, n1 * 0.5);
      fCol.lerp(cF4, n4 * 0.3 * smoothstep(5, 12, h));
      base.add(fCol.multiplyScalar(w[0]));
      const mCol = new THREE.Color().copy(cM1).lerp(cM2, n1).lerp(cM3, n3 * 0.4);
      mCol.lerp(cM4, n2 * 0.4);
      base.add(mCol.multiplyScalar(w[1]));
      base.add(tmp.copy(cL).lerp(cL2, n2 * 0.6).multiplyScalar(w[2]));
      base.add(tmp.copy(cT).lerp(cT2, n3 * 0.5).multiplyScalar(w[3]));
      const ny = nor[k + 1];
      let rk = smoothstep(0.84, 0.60, ny);
      rk = Math.max(rk, w[3] * smoothstep(40, 90, h) * 0.9);
      rk = Math.max(rk, smoothstep(35, 55, h) * smoothstep(0.9, 0.75, ny) * 0.65);
      const rockBlend = new THREE.Color().copy(rock).lerp(rock2, n2).lerp(rock3, n4 * 0.4);
      rockBlend.lerp(lichen, n1 * 0.3);
      base.lerp(rockBlend, clamp(rk, 0, 1));
      base.lerp(sand, smoothstep(1.5, 0.3, h) * smoothstep(-4, -0.5, h) * (1 - w[0] * 0.4));
      base.lerp(wet, smoothstep(-0.2, -2.5, h) * 0.9);
      base.lerp(snowline, w[3] * smoothstep(90, 115, h) * 0.7);
      col[k] = base.r; col[k + 1] = base.g; col[k + 2] = base.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.computeBoundingSphere();

    const detail = detailTex();
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uDetail = { value: detail };
      shader.uniforms.uPath = { value: this.pathTex };
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWPos = (modelMatrix * vec4(position, 1.0)).xyz;');
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;\nuniform sampler2D uDetail;\nuniform sampler2D uPath;')
        .replace('#include <color_fragment>', `#include <color_fragment>
          // Multi-scale procedural ground detail.
          float d1 = texture2D(uDetail, vWPos.xz * 0.38).r;
          float d2 = texture2D(uDetail, vWPos.xz * 0.055).g;
          float d3 = texture2D(uDetail, vWPos.xz * 2.1).r;
          float d4 = texture2D(uDetail, vWPos.xz * 0.015).b;
          float dd = (0.58 + 0.52*d1) * (0.80 + 0.36*d2) * (0.88 + 0.24*d3) * (0.92 + 0.16*d4);
          diffuseColor.rgb *= dd;
          float greenBoost = d1 * d2 * 0.18;
          diffuseColor.rgb += vec3(-greenBoost*0.3, greenBoost, -greenBoost*0.5);
          float pm = texture2D(uPath, (vWPos.xz + 500.0)/1000.0).r;
          pm *= smoothstep(0.5, 1.8, vWPos.y);
          vec3 pc = vec3(0.52, 0.38, 0.22) * (0.7 + 0.5*d1) * (0.8 + 0.3*d2);
          diffuseColor.rgb = mix(diffuseColor.rgb, pc, pm * 0.88);
          float lum = dot(diffuseColor.rgb, vec3(0.299, 0.587, 0.114));
          diffuseColor.rgb = max(mix(vec3(lum), diffuseColor.rgb, 1.16), vec3(0.0));`);
    };
    mat.customProgramCacheKey = () => 'terrain_v2';
    this.terrain = new THREE.Mesh(geo, mat);
    this.terrain.receiveShadow = true;
    this.group.add(this.terrain);
  }

  private buildWater() {
    const S = 2;
    const N = WORLD / S;
    const n = N + 1;
    const map = new Int32Array(n * n).fill(-1);
    const px: number[] = [], pd: number[] = [];
    const depthAt = (i: number, j: number) => WATER_LEVEL - this.heightAt(-HALF + i * S, -HALF + j * S);
    const dcache = new Float32Array(n * n);
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) dcache[j * n + i] = depthAt(i, j);
    const indices: number[] = [];
    const vid = (i: number, j: number) => {
      const k = j * n + i;
      if (map[k] < 0) {
        map[k] = px.length / 2;
        px.push(-HALF + i * S, -HALF + j * S);
        pd.push(dcache[k]);
      }
      return map[k];
    };
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const a = dcache[j * n + i], b = dcache[j * n + i + 1], c = dcache[(j + 1) * n + i], d = dcache[(j + 1) * n + i + 1];
      if (Math.max(a, b, c, d) < -0.25) continue;
      const A = vid(i, j), B = vid(i + 1, j), Cc = vid(i, j + 1), D = vid(i + 1, j + 1);
      indices.push(A, Cc, B, B, Cc, D);
    }
    const cnt = px.length / 2;
    const pos = new Float32Array(cnt * 3);
    const dep = new Float32Array(cnt);
    for (let i = 0; i < cnt; i++) {
      pos[i * 3] = px[i * 2]; pos[i * 3 + 1] = WATER_LEVEL; pos[i * 3 + 2] = px[i * 2 + 1];
      dep[i] = pd[i];
      if (pd[i] > 1.2) this.waterVerts.push({ x: px[i * 2], z: px[i * 2 + 1], d: pd[i] });
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aDepth', new THREE.BufferAttribute(dep, 1));
    geo.setIndex(indices);
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: {
        uTime: U.uTime, uSunDir: U.uSunDir, uSunColor: U.uSunColor, uSkyTop: U.uSkyTop, uSkyHor: U.uSkyHor,
        uFogColor: U.uFogColor, uFogDensity: U.uFogDensity, uRain: U.uRain, uLight: U.uLight,
        uShallow: { value: new THREE.Color('#3fc4b8') }, uDeep: { value: new THREE.Color('#0a5675') },
      },
      vertexShader: `
        attribute float aDepth; varying vec3 vWorld; varying float vDepth;
        void main(){ vec4 wp = modelMatrix*vec4(position,1.0); vWorld = wp.xyz; vDepth = aDepth; gl_Position = projectionMatrix*viewMatrix*wp; }`,
      fragmentShader: `
        ${CHUNK_PARS}
        uniform float uTime, uFogDensity, uRain, uLight;
        uniform vec3 uSunDir, uSunColor, uSkyTop, uSkyHor, uFogColor, uShallow, uDeep;
        varying vec3 vWorld; varying float vDepth;
        vec2 grad(vec2 p, float t){
          vec2 g = vec2(0.0);
          g += cos(dot(p, vec2(.9,.4))*1.7 + t*1.2) * vec2(.9,.4)*.35;
          g += cos(dot(p, vec2(-.5,.8))*2.9 - t*1.5) * vec2(-.5,.8)*.25;
          g += cos(dot(p, vec2(.3,-.95))*5.3 + t*2.1) * vec2(.3,-.95)*.18;
          g += cos(dot(p, vec2(-.8,-.2))*9.7 - t*2.6) * vec2(-.8,-.2)*.1;
          return g;
        }
        void main(){
          vec2 p = vWorld.xz;
          vec2 g = grad(p*0.9, uTime) + grad(p*2.3+17.0, uTime*1.3)*0.6;
          g *= (0.45 + uRain*0.6);
          vec3 n = normalize(vec3(-g.x, 1.0, -g.y));
          vec3 V = normalize(cameraPosition - vWorld);
          vec3 R = reflect(-V, n);
          float fres = clamp(0.05 + pow(1.0 - max(dot(n, V), 0.0), 4.0)*0.95, 0.0, 1.0);
          vec3 refl = mix(uSkyHor, uSkyTop, pow(clamp(R.y, 0.0, 1.0), 0.5));
          vec3 H = normalize(uSunDir + V);
          float nh = max(dot(n,H), 0.0);
          float spec = pow(nh, 320.0)*3.0 + pow(nh, 36.0)*0.12;
          float depth = max(vDepth, 0.0);
          vec3 body = mix(uShallow, uDeep, smoothstep(0.1, 4.5, depth));
          float caus = pow(abs(sin(p.x*2.7 + sin(p.y*1.9+uTime*.8))*sin(p.y*2.9+uTime*.6)), 6.0);
          body += vec3(.18,.32,.26)*caus*(1.0-smoothstep(0.0,2.6,depth))*uLight;
          body *= (0.28 + 0.72*uLight);
          vec3 col = mix(body, refl, fres);
          col += uSunColor*spec*step(0.0, uSunDir.y);
          float foam = smoothstep(0.42, 0.0, vDepth) * (0.55 + 0.45*sin(p.x*3.7+p.y*2.9+uTime*1.4));
          col = mix(col, vec3(0.95,1.0,1.0)*(0.35+0.65*uLight), clamp(foam,0.0,1.0)*0.55);
          float alpha = smoothstep(-0.08, 0.3, vDepth) * mix(0.66, 0.97, smoothstep(0.0, 3.0, depth));
          alpha = clamp(alpha + fres*0.3*smoothstep(-0.05,0.3,vDepth), 0.0, 1.0);
          float dist = length(cameraPosition - vWorld);
          float fog = 1.0 - exp(-uFogDensity*uFogDensity*dist*dist);
          col = mix(col, uFogColor, fog);
          gl_FragColor = vec4(col, alpha);
          ${CHUNK_END}
        }`,
    });
    this.water = new THREE.Mesh(geo, mat);
    this.water.frustumCulled = false;
    this.water.renderOrder = 2;
    this.group.add(this.water);
  }

  private buildFalls() {
    const mkMat = () => new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      uniforms: {
        uTime: U.uTime, uSunColor: U.uSunColor, uFogColor: U.uFogColor, uFogDensity: U.uFogDensity, uLight: U.uLight,
        uShallow: { value: new THREE.Color('#58cfc8') },
      },
      vertexShader: `
        attribute float aSlope; varying vec2 vUv; varying float vSlope; varying vec3 vWorld;
        void main(){ vUv = uv; vSlope = aSlope; vec4 wp = modelMatrix*vec4(position,1.0); vWorld = wp.xyz; gl_Position = projectionMatrix*viewMatrix*wp; }`,
      fragmentShader: `
        ${CHUNK_PARS}
        ${GLSL_NOISE}
        uniform float uTime, uFogDensity, uLight; uniform vec3 uSunColor, uFogColor, uShallow;
        varying vec2 vUv; varying float vSlope; varying vec3 vWorld;
        void main(){
          float sp = mix(0.5, 3.4, vSlope);
          float n1 = vnoise(vec2(vUv.x*9.0, vUv.y*2.2 - uTime*sp));
          float n2 = vnoise(vec2(vUv.x*23.0+5.0, vUv.y*5.0 - uTime*sp*1.7));
          float streak = n1*0.6 + n2*0.4;
          float edge = smoothstep(0.0, 0.2, vUv.x) * smoothstep(1.0, 0.8, vUv.x);
          vec3 col = mix(uShallow, vec3(0.93,0.98,1.0), clamp(vSlope*1.1 + streak*0.45*vSlope, 0.0, 1.0));
          col *= (0.4 + 0.6*uLight);
          col += uSunColor*0.06*vSlope;
          float a = edge * mix(0.5, 0.92, vSlope) * (0.55 + 0.7*streak);
          float dist = length(cameraPosition - vWorld);
          float fog = 1.0 - exp(-uFogDensity*uFogDensity*dist*dist);
          col = mix(col, uFogColor, fog);
          gl_FragColor = vec4(col, clamp(a, 0.0, 1.0));
          ${CHUNK_END}
        }`,
    });

    const mistPos: number[] = [];
    FALLS.forEach((f) => {
      let zTop = -392, zBot = -300;
      let found = false;
      for (let z = -392; z < -250; z += 0.5) {
        const h = this.heightAt(f.x, z);
        if (!found && h < PLAT.h - 3.6) { zTop = z; found = true; }
        if (found && h < 0.6) { zBot = z; break; }
      }
      const rows: { z: number; y: number }[] = [];
      for (let z = -392; z <= zBot + 1.5; z += 1) rows.push({ z, y: this.heightAt(f.x, z) + 0.5 });
      // keep water monotonic downstream and ensure it hugs the groove
      for (let i = 1; i < rows.length; i++) rows[i].y = Math.min(rows[i].y, rows[i - 1].y);
      const pos: number[] = [], uv: number[] = [], sl: number[] = [], idx: number[] = [];
      let len = 0;
      rows.forEach((r, i) => {
        if (i > 0) len += Math.hypot(1, rows[i - 1].y - r.y);
        const slope = i > 0 ? clamp((rows[i - 1].y - r.y) * 0.9, 0, 1) : 0;
        pos.push(f.x - f.w / 2, r.y, r.z, f.x + f.w / 2, r.y, r.z);
        uv.push(0, len / 7, 1, len / 7);
        sl.push(slope, slope);
        if (i > 0) { const a = (i - 1) * 2; idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3); }
      });
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
      geo.setAttribute('aSlope', new THREE.Float32BufferAttribute(sl, 1));
      geo.setIndex(idx);
      const m = new THREE.Mesh(geo, mkMat());
      m.frustumCulled = false; m.renderOrder = 3;
      this.group.add(m);
      this.fallMeshes.push(m);
      this.fallBase.push(new THREE.Vector3(f.x, 0.6, zBot));
      void zTop;
      for (let i = 0; i < 26; i++) {
        mistPos.push(f.x, 1, zBot);
        this.mistData.push({ x: 0, y: 0, z: 0, v: Math.random(), ph: Math.random() * 6.28, bx: f.x, bz: zBot });
      }
    });
    const mg = new THREE.BufferGeometry();
    mg.setAttribute('position', new THREE.Float32BufferAttribute(mistPos, 3));
    const mm = new THREE.PointsMaterial({
      map: softTex(), size: 11, transparent: true, opacity: 0.32, depthWrite: false, color: 0xffffff, sizeAttenuation: true,
    });
    this.mist = new THREE.Points(mg, mm);
    this.mist.frustumCulled = false;
    this.group.add(this.mist);
  }

  update(dt: number, light: number) {
    // rising spray at the waterfall bases
    const arr = this.mist.geometry.attributes.position.array as Float32Array;
    for (let i = 0; i < this.mistData.length; i++) {
      const m = this.mistData[i];
      m.v += dt * 0.28;
      if (m.v > 1) { m.v -= 1; m.ph = Math.random() * 6.28; }
      const s = m.v;
      arr[i * 3] = m.bx + Math.sin(m.ph + s * 3) * 4 + Math.cos(m.ph * 2) * 3;
      arr[i * 3 + 1] = 1 + s * 9;
      arr[i * 3 + 2] = m.bz + 3 + Math.cos(m.ph + s * 2) * 4 + Math.sin(m.ph * 3) * 2;
    }
    this.mist.geometry.attributes.position.needsUpdate = true;
    (this.mist.material as THREE.PointsMaterial).opacity = 0.3 * (0.3 + 0.7 * light);
  }

  dispose() {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
  }
}
