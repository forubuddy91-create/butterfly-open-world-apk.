import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { U, CHUNK_PARS, CHUNK_END } from './shared';
import { glowTex } from './textures';

export interface Palette {
  edge: string; mid: string; glow: string; glow2: string; vein: string; rim: string; body: string; emissive: string; band: string;
}

/** The hero butterfly: deep navy edges, luminous cyan cells, glowing antennae tips. */
export const BLUE: Palette = {
  edge: '#050c48', mid: '#1830b4', glow: '#7ff6ff', glow2: '#00a6ff', vein: '#06104f', rim: '#9cf0ff',
  body: '#0a1670', emissive: '#12b4ff', band: '#7df4ff',
};
export const NPC_PALETTES: Palette[] = [
  { edge: '#2a1004', mid: '#b84c0c', glow: '#ffd070', glow2: '#ff8a1c', vein: '#2a1004', rim: '#ffe6a0', body: '#2a1408', emissive: '#a04008', band: '#ffb040' },
  { edge: '#3a2c06', mid: '#c8a010', glow: '#fff59a', glow2: '#ffd020', vein: '#3a2c06', rim: '#fffbc0', body: '#3a2c0a', emissive: '#907008', band: '#ffe060' },
  { edge: '#5a6078', mid: '#c8d0e0', glow: '#ffffff', glow2: '#dfe8ff', vein: '#7a8098', rim: '#ffffff', body: '#505870', emissive: '#505870', band: '#e0e8ff' },
  { edge: '#5a1040', mid: '#d8509a', glow: '#ffc4e6', glow2: '#ff7ac0', vein: '#5a1040', rim: '#ffe0f2', body: '#4a1038', emissive: '#902068', band: '#ff9ad0' },
  { edge: '#2a0c58', mid: '#7a40d8', glow: '#e0c8ff', glow2: '#a870ff', vein: '#2a0c58', rim: '#f0e0ff', body: '#2a1060', emissive: '#6030b8', band: '#c8a0ff' },
  { edge: '#08301a', mid: '#2c9a50', glow: '#c8ffa0', glow2: '#58d870', vein: '#08301a', rim: '#e0ffc8', body: '#0c3a20', emissive: '#208048', band: '#90f090' },
];

const texCache = new Map<string, THREE.CanvasTexture>();

function wingTexture(kind: 'fore' | 'hind', p: Palette) {
  const key = kind + p.edge + p.mid;
  const hit = texCache.get(key);
  if (hit) return hit;
  const S = 512;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d')!;
  const root = kind === 'fore' ? { x: 0, y: 296 } : { x: 0, y: 84 };
  const path = (ctx: CanvasRenderingContext2D) => {
    ctx.beginPath();
    if (kind === 'fore') {
      ctx.moveTo(0, 262);
      ctx.bezierCurveTo(60, 170, 190, 58, 330, 30);
      ctx.quadraticCurveTo(430, 8, 502, 12);
      ctx.bezierCurveTo(492, 90, 472, 180, 424, 262);
      ctx.bezierCurveTo(384, 322, 252, 352, 150, 354);
      ctx.bezierCurveTo(90, 354, 40, 338, 0, 326);
    } else {
      ctx.moveTo(0, 30);
      ctx.bezierCurveTo(120, 10, 262, 40, 372, 120);
      ctx.bezierCurveTo(432, 170, 482, 250, 506, 338);
      ctx.quadraticCurveTo(452, 330, 442, 376);
      ctx.quadraticCurveTo(410, 350, 384, 404);
      ctx.quadraticCurveTo(350, 372, 320, 428);
      ctx.quadraticCurveTo(286, 396, 252, 442);
      ctx.quadraticCurveTo(210, 400, 172, 432);
      ctx.quadraticCurveTo(110, 372, 60, 346);
      ctx.lineTo(0, 150);
    }
    ctx.closePath();
  };
  const scaled = (ctx: CanvasRenderingContext2D, s: number, fn: () => void) => {
    ctx.save();
    ctx.translate(root.x, root.y); ctx.scale(s, s); ctx.translate(-root.x, -root.y);
    fn();
    ctx.restore();
  };
  // outer membrane: deep edge colour
  const og = g.createLinearGradient(0, 0, S, S * 0.6);
  og.addColorStop(0, p.mid); og.addColorStop(0.55, p.edge); og.addColorStop(1, p.edge);
  path(g); g.fillStyle = og; g.fill();
  g.save();
  path(g); g.clip();
  // inner luminous field
  scaled(g, 0.84, () => {
    path(g);
    const cx = kind === 'fore' ? 160 : 150, cy = kind === 'fore' ? 250 : 170;
    const ig = g.createRadialGradient(cx, cy, 10, cx + 40, cy, 330);
    ig.addColorStop(0, p.glow); ig.addColorStop(0.45, p.glow2); ig.addColorStop(1, p.mid);
    g.fillStyle = ig; g.fill();
    g.lineWidth = 7; g.strokeStyle = p.mid; g.stroke();
  });
  // second, brighter petal-like cell
  scaled(g, 0.58, () => {
    path(g);
    const ig = g.createRadialGradient(120, root.y - 20, 4, 150, root.y - 10, 240);
    ig.addColorStop(0, '#ffffff'); ig.addColorStop(0.3, p.glow); ig.addColorStop(1, p.glow2);
    g.globalAlpha = 0.85; g.fillStyle = ig; g.fill(); g.globalAlpha = 1;
    g.lineWidth = 9; g.strokeStyle = p.vein; g.stroke();
  });
  // veins radiating from the root
  g.lineCap = 'round';
  const nV = kind === 'fore' ? 7 : 8;
  for (let i = 0; i < nV; i++) {
    const t = (i + 0.5) / nV;
    const ex = kind === 'fore' ? 150 + t * 350 : 120 + t * 380;
    const ey = kind === 'fore' ? 20 + (1 - Math.sin(t * Math.PI)) * 40 + t * 320 : 40 + t * 380;
    g.beginPath(); g.moveTo(root.x + 4, root.y);
    g.quadraticCurveTo((root.x + ex) * 0.45, (root.y + ey) * 0.5 - 14, ex, ey);
    g.lineWidth = 6 - t * 2; g.strokeStyle = p.vein; g.globalAlpha = 0.85; g.stroke();
  }
  g.globalAlpha = 1;
  // gloss streak along the leading edge
  const gl = g.createLinearGradient(0, 0, S, 120);
  gl.addColorStop(0, 'rgba(255,255,255,0.0)'); gl.addColorStop(0.5, 'rgba(255,255,255,0.28)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gl; g.fillRect(0, 0, S, S);
  g.restore();
  // luminous rim
  path(g);
  g.lineWidth = 3; g.strokeStyle = p.rim; g.globalAlpha = 0.8; g.stroke(); g.globalAlpha = 1;
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  texCache.set(key, t);
  return t;
}

function wingGeometry(W: number, zMin: number, zMax: number, seg = 16) {
  const pos: number[] = [], uv: number[] = [], idx: number[] = [];
  for (let j = 0; j <= seg; j++) for (let i = 0; i <= seg; i++) {
    const u = i / seg, v = j / seg;
    pos.push(u * W, 0, zMin + v * (zMax - zMin));
    uv.push(u, v);
  }
  for (let j = 0; j < seg; j++) for (let i = 0; i < seg; i++) {
    const a = j * (seg + 1) + i, b = a + 1, c = a + seg + 1, d = c + 1;
    idx.push(a, b, c, b, d, c);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  return g;
}

function wingMaterial(tex: THREE.Texture, pivot: number) {
  return new THREE.ShaderMaterial({
    side: THREE.DoubleSide,
    uniforms: {
      uMap: { value: tex }, uFlap: { value: 0.4 }, uBend: { value: 0 }, uExpand: { value: 1 }, uHang: { value: 0 },
      uWet: { value: 0 }, uGlow: { value: 1 }, uTime: U.uTime, uLight: U.uLight, uPivot: { value: pivot },
    },
    vertexShader: `
      uniform float uFlap, uBend, uExpand, uHang, uPivot, uTime;
      varying vec2 vUv;
      void main(){
        vUv = uv;
        vec3 p = position;
        float ex = mix(0.16, 1.0, uExpand);
        p.x *= ex;
        p.z = uPivot + (p.z - uPivot) * mix(0.45, 1.0, uExpand);
        float wr = (1.0 - uExpand) * 0.035;
        p.y += sin(p.x*22.0 + p.z*13.0) * wr + sin(p.x*9.0 - p.z*17.0 + uTime) * wr * 0.6;
        float a = uFlap + uBend * uv.x * uv.x;
        vec3 pf = vec3(p.x*cos(a) - p.y*sin(a), p.x*sin(a) + p.y*cos(a), p.z);
        pf.y -= uv.x*uv.x*0.05; // gentle camber
        vec3 ph = vec3(p.y + 0.07 + sin(p.x*10.0 + uTime*1.5)*0.012, (p.z - uPivot)*0.9 + 0.14, -p.x*0.92);
        vec3 pp = mix(pf, ph, uHang);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pp, 1.0);
      }`,
    fragmentShader: `
      ${CHUNK_PARS}
      uniform sampler2D uMap; uniform float uGlow, uWet, uLight, uTime;
      varying vec2 vUv;
      void main(){
        vec4 t = texture2D(uMap, vUv);
        if (t.a < 0.5) discard;
        vec3 col = t.rgb;
        float lum = dot(col, vec3(0.3, 0.6, 0.1));
        col *= 1.0 + uGlow * smoothstep(0.12, 0.7, lum) * 2.2;
        col += col * pow(max(sin(vUv.x*6.0 + vUv.y*4.0 - uTime*0.9), 0.0), 14.0) * 0.5;
        col = mix(col, col*vec3(0.5,0.55,0.62) + 0.02, uWet*0.65);
        col *= 0.55 + 0.45*uLight + uGlow*0.25*(1.0-uLight);
        gl_FragColor = vec4(col, 1.0);
        ${CHUNK_END}
      }`,
  });
}

export interface WingPose {
  freq: number; amp: number; mean: number; fold: number; expand: number; hang: number; wet: number; glow: number; feed: number;
}

export class Butterfly {
  group = new THREE.Group();
  model = new THREE.Group();
  fore: THREE.ShaderMaterial;
  hind: THREE.ShaderMaterial;
  abdomen = new THREE.Group();
  antL = new THREE.Group();
  antR = new THREE.Group();
  probo = new THREE.Group();
  legs = new THREE.Group();
  halo: THREE.Sprite;
  light: THREE.PointLight | null = null;
  phase = Math.random() * 6;
  flapValue = 0;
  flapVel = 0;
  private lastFlap = 0;
  private stuff: THREE.Material[] = [];

  constructor(public pal: Palette = BLUE, simple = false, withLight = false) {
    this.group.add(this.model);
    const foreTex = wingTexture('fore', pal), hindTex = wingTexture('hind', pal);
    this.fore = wingMaterial(foreTex, 0.08);
    this.hind = wingMaterial(hindTex, 0.08);
    const fg = wingGeometry(1.15, -0.45, 0.75), hg = wingGeometry(1.08, -0.95, 0.25);
    for (const side of [1, -1]) {
      const a = new THREE.Mesh(fg, this.fore), b = new THREE.Mesh(hg, this.hind);
      a.scale.x = b.scale.x = side;
      a.frustumCulled = b.frustumCulled = false;
      a.position.y = 0.002; b.position.y = -0.002;
      this.model.add(a, b);
    }

    const bodyMat = new THREE.MeshStandardMaterial({ color: pal.body, emissive: pal.emissive, emissiveIntensity: 0.9, roughness: 0.25, metalness: 0.35 });
    const bandMat = new THREE.MeshStandardMaterial({ color: pal.band, emissive: pal.band, emissiveIntensity: 1.8, roughness: 0.4 });
    const eyeMat = new THREE.MeshStandardMaterial({ color: '#05081c', roughness: 0.1, metalness: 0.6, emissive: pal.emissive, emissiveIntensity: 0.25 });
    this.stuff.push(bodyMat, bandMat, eyeMat);

    const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.115, 12, 10), bodyMat);
    thorax.scale.set(0.95, 0.95, 1.5); thorax.position.set(0, 0, 0.1);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.082, 10, 8), bodyMat);
    head.position.set(0, 0.0, 0.34);
    this.model.add(thorax, head);
    for (const s of [1, -1]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), eyeMat);
      eye.position.set(s * 0.055, 0.03, 0.38);
      this.model.add(eye);
    }
    // segmented abdomen: dark plates with glowing bands
    this.abdomen.position.set(0, 0, 0.0);
    const dark: THREE.BufferGeometry[] = [], band: THREE.BufferGeometry[] = [];
    const n = simple ? 5 : 11;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      const r = 0.088 * (1 - t * 0.68);
      const g = new THREE.SphereGeometry(r, 9, 7);
      g.scale(1, 0.92, 1.0);
      g.translate(0, -0.005 * i, -0.02 - i * (0.82 / n));
      (i % 2 ? band : dark).push(g);
    }
    this.abdomen.add(new THREE.Mesh(mergeGeometries(dark)!, bodyMat), new THREE.Mesh(mergeGeometries(band)!, bandMat));
    this.model.add(this.abdomen);

    // antennae with glowing bulbs
    for (const [grp, s] of [[this.antL, 1], [this.antR, -1]] as [THREE.Group, number][]) {
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(s * 0.03, 0.04, 0.4), new THREE.Vector3(s * 0.12, 0.22, 0.62),
        new THREE.Vector3(s * 0.3, 0.32, 0.9), new THREE.Vector3(s * 0.52, 0.34, 1.12),
      ]);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 10, 0.009, 4), eyeMat);
      const tip = new THREE.Mesh(new THREE.SphereGeometry(0.036, 8, 6), bandMat);
      tip.position.copy(curve.getPoint(1));
      tip.scale.set(1.5, 1, 1);
      grp.add(tube, tip);
      grp.position.set(0, 0, 0);
      this.model.add(grp);
    }
    if (!simple) {
      // legs
      const legMat = new THREE.MeshStandardMaterial({ color: '#0a1038', roughness: 0.5 });
      this.stuff.push(legMat);
      for (let i = 0; i < 6; i++) {
        const s = i % 2 ? 1 : -1, k = Math.floor(i / 2);
        const geo = new THREE.CylinderGeometry(0.006, 0.01, 0.3, 4);
        geo.translate(0, -0.15, 0);
        const m = new THREE.Mesh(geo, legMat);
        m.position.set(s * 0.04, -0.07, 0.2 - k * 0.1);
        m.rotation.z = s * 0.5; m.rotation.x = (k - 1) * 0.25;
        this.legs.add(m);
      }
      this.model.add(this.legs);
      // proboscis
      const pc = new THREE.CatmullRomCurve3([new THREE.Vector3(0, -0.02, 0.4), new THREE.Vector3(0, -0.12, 0.5), new THREE.Vector3(0, -0.28, 0.5)]);
      this.probo.add(new THREE.Mesh(new THREE.TubeGeometry(pc, 8, 0.007, 4), legMat));
      this.probo.visible = false;
      this.model.add(this.probo);
    }
    const sm = new THREE.SpriteMaterial({ map: glowTex(), color: pal.emissive, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.55, fog: false });
    this.halo = new THREE.Sprite(sm);
    this.halo.scale.setScalar(simple ? 1.6 : 2.5);
    this.halo.position.set(0, 0, 0.05);
    this.model.add(this.halo);
    if (withLight) {
      this.light = new THREE.PointLight(pal.emissive, 2.2, 9, 1.6);
      this.light.position.set(0, 0.1, 0.1);
      this.group.add(this.light);
    }
  }

  animate(dt: number, p: WingPose) {
    this.phase += dt * p.freq * Math.PI * 2;
    const s = Math.sin(this.phase);
    const amp = p.amp * (1 - p.fold);
    let flap = p.mean + amp * s;
    flap = flap + (1.47 - flap) * p.fold;
    const flapH = p.mean + amp * Math.sin(this.phase - 0.55);
    const hindF = flapH + (1.43 - flapH) * p.fold;
    this.flapValue = s;
    this.flapVel = (flap - this.lastFlap) / Math.max(dt, 1e-3);
    this.lastFlap = flap;
    const bend = -clampN(this.flapVel * 0.03, -0.5, 0.5) * (1 - p.fold) * (1 - p.hang);
    this.fore.uniforms.uFlap.value = flap;
    this.hind.uniforms.uFlap.value = hindF;
    this.fore.uniforms.uBend.value = bend;
    this.hind.uniforms.uBend.value = bend * 1.2;
    for (const m of [this.fore, this.hind]) {
      m.uniforms.uExpand.value = p.expand;
      m.uniforms.uHang.value = p.hang;
      m.uniforms.uWet.value = p.wet;
      m.uniforms.uGlow.value = p.glow;
    }
    this.abdomen.rotation.x = -0.12 + Math.sin(this.phase + 0.8) * 0.07 * (1 - p.fold) - p.feed * 0.12;
    const sw = Math.sin(this.phase * 0.5) * 0.05;
    this.antL.rotation.set(sw, 0.0, sw * 0.6);
    this.antR.rotation.set(-sw * 0.8, 0.0, -sw * 0.6);
    this.probo.visible = p.feed > 0.05;
    if (p.feed > 0.05) { this.probo.scale.set(1, p.feed, p.feed); this.probo.rotation.x = 0.15 - p.feed * 0.1; }
    (this.halo.material as THREE.SpriteMaterial).opacity = 0.25 + 0.4 * p.glow;
  }

  dispose() {
    this.fore.dispose(); this.hind.dispose();
    this.stuff.forEach((m) => m.dispose());
  }
}

function clampN(x: number, a: number, b: number) { return x < a ? a : x > b ? b : x; }

/* ------------------------------------------------------------------ sparkle trail */

export class Sparkles {
  points: THREE.Points;
  private n: number;
  private i = 0;
  private now = 0;
  private pos: Float32Array; private vel: Float32Array; private birth: Float32Array; private size: Float32Array;
  private mat: THREE.ShaderMaterial;

  constructor(n = 140) {
    this.n = n;
    this.pos = new Float32Array(n * 3); this.vel = new Float32Array(n * 3);
    this.birth = new Float32Array(n).fill(-1000); this.size = new Float32Array(n);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('aVel', new THREE.BufferAttribute(this.vel, 3));
    g.setAttribute('aBirth', new THREE.BufferAttribute(this.birth, 1));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1));
    this.mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uNow: { value: 0 }, uLife: { value: 1.6 }, uViewH: { value: 800 }, uTex: { value: glowTex() }, uColor: { value: new THREE.Color('#3cc4ff') } },
      vertexShader: `
        attribute vec3 aVel; attribute float aBirth, aSize; uniform float uNow, uLife, uViewH; varying float vA;
        void main(){
          float age = uNow - aBirth; float t = age/uLife;
          vec3 p = position + aVel*age + vec3(0.0,-0.12,0.0)*age*age;
          vA = (t < 0.0 || t > 1.0) ? 0.0 : (1.0 - t) * (0.6 + 0.4*sin(age*18.0 + aBirth*50.0));
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = aSize * (1.0 - 0.5*t) * uViewH * 0.5 * projectionMatrix[1][1] / max(-mv.z, 0.1);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `${CHUNK_PARS} uniform sampler2D uTex; uniform vec3 uColor; varying float vA;
        void main(){ vec4 t = texture2D(uTex, gl_PointCoord); gl_FragColor = vec4(uColor*2.0*t.rgb, t.a*vA); if(gl_FragColor.a<0.01) discard; ${CHUNK_END} }`,
    });
    this.points = new THREE.Points(g, this.mat);
    this.points.frustumCulled = false;
  }

  setViewHeight(h: number) { this.mat.uniforms.uViewH.value = h; }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, size = 0.05) {
    const i = this.i; this.i = (this.i + 1) % this.n;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx + (Math.random() - 0.5) * 0.3; this.vel[i * 3 + 1] = vy + (Math.random() - 0.3) * 0.2; this.vel[i * 3 + 2] = vz + (Math.random() - 0.5) * 0.3;
    this.birth[i] = this.now; this.size[i] = size * (0.5 + Math.random());
    const g = this.points.geometry;
    g.attributes.position.needsUpdate = true; g.attributes.aVel.needsUpdate = true;
    g.attributes.aBirth.needsUpdate = true; g.attributes.aSize.needsUpdate = true;
  }

  update(dt: number) { this.now += dt; this.mat.uniforms.uNow.value = this.now; }
}
