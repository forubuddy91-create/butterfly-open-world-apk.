import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export type RGB = [number, number, number];
const _v = new THREE.Vector3();
const _n = new THREE.Vector3();

export const col = (hex: string) => new THREE.Color(hex);

/** Writes a per-vertex color attribute. */
export function paint(
  g: THREE.BufferGeometry,
  fn: (p: THREE.Vector3, n: THREE.Vector3, i: number) => THREE.Color | RGB,
) {
  const pos = g.attributes.position as THREE.BufferAttribute;
  const nor = g.attributes.normal as THREE.BufferAttribute | undefined;
  const arr = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    _v.fromBufferAttribute(pos, i);
    if (nor) _n.fromBufferAttribute(nor, i); else _n.set(0, 1, 0);
    const c = fn(_v, _n, i);
    if (Array.isArray(c)) { arr[i * 3] = c[0]; arr[i * 3 + 1] = c[1]; arr[i * 3 + 2] = c[2]; }
    else { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

export function xform(
  g: THREE.BufferGeometry,
  pos: [number, number, number] | THREE.Vector3 = [0, 0, 0],
  rot: [number, number, number] | THREE.Quaternion = [0, 0, 0],
  scale: number | [number, number, number] = 1,
) {
  const p = Array.isArray(pos) ? new THREE.Vector3(...pos) : pos;
  const q = rot instanceof THREE.Quaternion ? rot : new THREE.Quaternion().setFromEuler(new THREE.Euler(...rot));
  const s = typeof scale === 'number' ? new THREE.Vector3(scale, scale, scale) : new THREE.Vector3(...scale);
  const m = new THREE.Matrix4().compose(p, q, s);
  return g.clone().applyMatrix4(m);
}

export function merge(list: THREE.BufferGeometry[]) {
  const out = mergeGeometries(list, false);
  if (!out) throw new Error('merge failed');
  list.forEach((g) => g.dispose());
  return out;
}

export function setNormals(g: THREE.BufferGeometry, fn: (p: THREE.Vector3, i: number) => THREE.Vector3) {
  const pos = g.attributes.position as THREE.BufferAttribute;
  const arr = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    _v.fromBufferAttribute(pos, i);
    const n = fn(_v, i);
    arr[i * 3] = n.x; arr[i * 3 + 1] = n.y; arr[i * 3 + 2] = n.z;
  }
  g.setAttribute('normal', new THREE.BufferAttribute(arr, 3));
}

export function matrixFrom(x: number, y: number, z: number, rotY: number, sx: number, sy = sx, sz = sx) {
  const c = Math.cos(rotY), s = Math.sin(rotY);
  return new THREE.Matrix4().set(
    c * sx, 0, s * sz, x,
    0, sy, 0, y,
    -s * sx, 0, c * sz, z,
    0, 0, 0, 1,
  );
}
