export const WORLD = 1000;
export const HALF = 500;
export const WATER_LEVEL = 0;

export type QualityName = 'low' | 'medium' | 'high' | 'ultra';
export type WeatherMode = 'auto' | 'sunny' | 'cloudy' | 'rain' | 'windy' | 'mist';

export interface QualityCfg {
  terrainSeg: number;
  pixelRatio: number;
  shadowMap: number;
  shadowRange: number;
  grassR: number; grassCell: number;
  flowerR: number; flowerCell: number;
  fernR: number; fernCell: number;
  treeCards: number;
  treeDensity: number;
  rockDensity: number;
  bloom: number;
  wildlife: number;
  particles: number;
  rain: number;
  glowLight: boolean;
  msaa: number;
  cloudOct: number;
}

export const QUALITY: Record<QualityName, QualityCfg> = {
  low: {
    terrainSeg: 200, pixelRatio: 0.8, shadowMap: 0, shadowRange: 30,
    grassR: 34, grassCell: 0.95, flowerR: 30, flowerCell: 2.1, fernR: 36, fernCell: 5,
    treeCards: 14, treeDensity: 0.5, rockDensity: 0.6, bloom: 0, wildlife: 0.5, particles: 0.4, rain: 900,
    glowLight: false, msaa: 0, cloudOct: 3,
  },
  medium: {
    terrainSeg: 260, pixelRatio: 1.0, shadowMap: 1024, shadowRange: 36,
    grassR: 44, grassCell: 0.8, flowerR: 40, flowerCell: 1.7, fernR: 44, fernCell: 3.8,
    treeCards: 22, treeDensity: 0.75, rockDensity: 0.8, bloom: 0.45, wildlife: 0.75, particles: 0.7, rain: 2000,
    glowLight: false, msaa: 0, cloudOct: 4,
  },
  high: {
    terrainSeg: 320, pixelRatio: 1.5, shadowMap: 2048, shadowRange: 48,
    grassR: 54, grassCell: 0.68, flowerR: 48, flowerCell: 1.4, fernR: 52, fernCell: 3.2,
    treeCards: 30, treeDensity: 1, rockDensity: 1, bloom: 0.6, wildlife: 1, particles: 1, rain: 3500,
    glowLight: true, msaa: 4, cloudOct: 5,
  },
  ultra: {
    terrainSeg: 400, pixelRatio: 2, shadowMap: 4096, shadowRange: 60,
    grassR: 64, grassCell: 0.6, flowerR: 56, flowerCell: 1.15, fernR: 60, fernCell: 2.6,
    treeCards: 40, treeDensity: 1.2, rockDensity: 1.2, bloom: 0.75, wildlife: 1.3, particles: 1.4, rain: 5500,
    glowLight: true, msaa: 4, cloudOct: 5,
  },
};

export interface Settings {
  quality: QualityName;
  music: number;
  ambient: number;
  sfx: number;
  sensitivity: number;
  dayCycle: boolean;
  weather: WeatherMode;
}

export const DEFAULT_SETTINGS: Settings = {
  quality: 'medium', music: 0.5, ambient: 0.8, sfx: 0.7, sensitivity: 1, dayCycle: true, weather: 'auto',
};

export type RegionId = 'forest' | 'meadow' | 'lake' | 'mountain';
export const REGION_INFO: Record<RegionId, { name: string; sub: string }> = {
  forest: { name: 'Verdant Canopy', sub: 'Tropical Forest' },
  meadow: { name: 'Sunset Meadow', sub: 'Flower Fields' },
  lake: { name: 'Crystal Lake Valley', sub: 'Waters & Falls' },
  mountain: { name: 'Mistpeak Wilds', sub: 'Mountain Ruins' },
};

export const START_SITE = { x: -186, z: 196 };

export interface HudState {
  region: RegionId;
  regionTitle: string | null;
  hour: number;
  weather: string;
  nectar: number;
  discoveries: number;
  discoveryTotal: number;
  flowerTypes: number;
  prompt: null | 'feed' | 'rest' | 'ground';
  mode: string;
  night: boolean;
  toast: string | null;
  intro: boolean;
  introSkippable: boolean;
  introTime: number;
  sleeping: boolean;
  canSleep: boolean;
  glide: boolean;
}

export interface SaveData {
  x: number; y: number; z: number; yaw: number;
  hour: number; nectar: number; discovered: string[]; flowerTypes: string[];
}
