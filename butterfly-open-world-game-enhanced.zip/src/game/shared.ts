import * as THREE from 'three';

// Uniforms shared by every custom shader (wind, sky, fog) so one update drives the whole world.
export const U = {
  uTime: { value: 0 },
  uWind: { value: 0.3 },
  uSunDir: { value: new THREE.Vector3(0, 1, 0) },
  uSunColor: { value: new THREE.Color('#fff2d0') },
  uSkyTop: { value: new THREE.Color('#3f86e0') },
  uSkyHor: { value: new THREE.Color('#bfe0f0') },
  uFogColor: { value: new THREE.Color('#bfe0f0') },
  uFogDensity: { value: 0.0016 },
  uRain: { value: 0 },
  uLight: { value: 1 },
};

export const CHUNK_PARS = ``; // ShaderMaterial already injects tone-mapping / colour-space helpers
export const CHUNK_END = `
#include <tonemapping_fragment>
#include <colorspace_fragment>
`;

export const GLSL_NOISE = `
float hash21(vec2 p){ p = fract(p*vec2(123.34, 456.21)); p += dot(p, p+45.32); return fract(p.x*p.y); }
float vnoise(vec2 p){
  vec2 i = floor(p), f = fract(p);
  f = f*f*(3.0-2.0*f);
  float a = hash21(i), b = hash21(i+vec2(1,0)), c = hash21(i+vec2(0,1)), d = hash21(i+vec2(1,1));
  return mix(mix(a,b,f.x), mix(c,d,f.x), f.y);
}
`;

export type WindMode = 'grass' | 'canopy' | 'leaf';

/** Injects wind sway into a standard material (instanced or not). */
export function addWind(mat: THREE.Material, amp: number, mode: WindMode) {
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = U.uTime;
    shader.uniforms.uWind = U.uWind;
    let body = '';
    if (mode === 'grass') {
      body = `
        float hh = max(transformed.y, 0.0);
        float bend = hh * hh * ${amp.toFixed(3)} * w;
        transformed.x += (sin(uTime*2.1 + ph + hh*1.7) * (0.55 + gust*0.8) + gust*0.9) * bend;
        transformed.z += cos(uTime*1.7 + ph*1.3 + hh) * bend * 0.5;`;
    } else if (mode === 'canopy') {
      body = `
        float hy = max(transformed.y, 0.0);
        float k = ${amp.toFixed(3)} * w * (0.25 + hy * 0.05);
        transformed.x += sin(uTime*1.25 + ph + transformed.z*0.6) * k * (0.6 + gust*0.8);
        transformed.z += cos(uTime*1.05 + ph*1.4 + transformed.x*0.5) * k * 0.7;
        transformed.y += sin(uTime*2.3 + ph*2.0 + transformed.x) * k * 0.25;`;
    } else {
      body = `
        float lr = length(transformed.xz);
        float k2 = ${amp.toFixed(3)} * w * lr * 0.12;
        transformed.y += sin(uTime*1.6 + ph + lr*0.9) * k2 * (0.5 + gust);
        transformed.x += sin(uTime*1.1 + ph) * k2 * 0.4;`;
    }
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime;\nuniform float uWind;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        vec3 iPos = vec3(0.0);
        #ifdef USE_INSTANCING
          iPos = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
        #endif
        float ph = iPos.x*0.11 + iPos.z*0.13;
        float gust = sin(uTime*0.55 + iPos.x*0.021 + iPos.z*0.016)*0.5 + 0.5;
        float w = 0.3 + 0.9*uWind;
        ${body}`);
  };
  mat.customProgramCacheKey = () => `wind_${mode}_${amp}`;
}
