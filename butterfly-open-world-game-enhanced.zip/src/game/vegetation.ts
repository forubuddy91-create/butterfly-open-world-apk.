import * as THREE from 'three';
import { World, Perch, regionWeights, RIVER_PTS } from './terrain';
import { QualityCfg, START_SITE } from './config';
import { mulberry32, fbm, noise2, hash2, smoothstep, clamp, lerp } from './noise';
import { paint, xform, merge, setNormals, matrixFrom, col } from './geo';
import { leafClumpTex, stoneTex } from './textures';
import { addWind } from './shared';

export const FLOWER_TYPES = [
  { name: 'Sunbloom', color: '#ffc21a' },
  { name: 'Ember Cosmos', color: '#ff7a1c' },
  { name: 'Moon Daisy', color: '#fbfbf2' },
  { name: 'Rose Petal', color: '#ff7fb0' },
  { name: 'Bluebell', color: '#5a6cff' },
  { name: 'Twilight Lily', color: '#a44cf0' },
  { name: 'Lavender Mist', color: '#b9a0ff' },
  { name: 'Red Poppy', color: '#ff3a2a' },
];
const REGION_FLOWERS = [
  [4, 4, 5, 2, 6, 4], // forest
  [0, 0, 1, 2, 3, 0, 1, 7], // meadow
  [2, 4, 6, 2, 3], // lake
  [0, 2, 7, 0], // mountain
];

export interface Item {
  x: number; y: number; z: number; rot: number; sx: number; sy: number;
  r: number; g: number; b: number; type: number;
}

/* ------------------------------------------------------------------ geometry builders */

function makeTrunk(rng: () => number, H: number) {
  const bark = col('#6a5038'), dark = col('#3d2d20'), moss = col('#4a7a2c');
  const main = new THREE.CylinderGeometry(0.3, 0.62, H, 8, 8, false);
  main.translate(0, H / 2, 0);
  const p = main.attributes.position;
  const ph = rng() * 6;
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i), t = y / H;
    let x = p.getX(i), z = p.getZ(i);
    const flare = 1 + Math.max(0, 1 - y / 1.5) * 1.0;
    x *= flare; z *= flare;
    x += Math.sin(t * 3 + ph) * 0.4 * t; z += Math.cos(t * 2.3 + ph) * 0.3 * t;
    p.setXYZ(i, x, y, z);
  }
  main.computeVertexNormals();
  paint(main, (v) => {
    const stripe = noise2(v.x * 5 + v.z * 3, v.y * 1.2, 5);
    const c = bark.clone().lerp(dark, stripe * 0.8);
    c.lerp(moss, smoothstep(2.2, 0.3, v.y) * 0.5 * noise2(v.x * 3, v.z * 3, 8));
    return c;
  });
  const parts: THREE.BufferGeometry[] = [main];
  const tips: THREE.Vector3[] = [];
  const nb = 3 + Math.floor(rng() * 2);
  for (let k = 0; k < nb; k++) {
    const a = k * 2.1 + rng() * 1.2;
    const y0 = H * (0.5 + 0.13 * k), len = 2.6 + rng() * 1.8;
    const phi = 0.85 + rng() * 0.45;
    const d = new THREE.Vector3(Math.cos(a) * Math.sin(phi), Math.cos(phi), Math.sin(a) * Math.sin(phi));
    const t0 = y0 / H;
    const base = new THREE.Vector3(Math.sin(t0 * 3 + ph) * 0.4 * t0, y0, Math.cos(t0 * 2.3 + ph) * 0.3 * t0);
    const g = new THREE.CylinderGeometry(0.07, 0.19, len, 6, 1);
    g.translate(0, len / 2, 0);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d);
    const gg = xform(g, base, q);
    paint(gg, (v) => bark.clone().lerp(dark, noise2(v.x * 4, v.z * 4, 3) * 0.7));
    parts.push(gg);
    tips.push(base.clone().addScaledVector(d, len));
  }
  tips.sort((a, b) => b.y - a.y);
  return { geo: merge(parts), tips };
}

function makeCanopy(
  rng: () => number, cards: number,
  centers: { c: THREE.Vector3; rx: number; ry: number; w: number }[],
  dark: THREE.Color, light: THREE.Color, size: number,
) {
  const parts: THREE.BufferGeometry[] = [];
  const totalW = centers.reduce((s, c) => s + c.w, 0);
  const Z = new THREE.Vector3(0, 0, 1);
  for (const cc of centers) {
    const n = Math.max(2, Math.round((cards * cc.w) / totalW));
    for (let i = 0; i < n; i++) {
      const dir = new THREE.Vector3(rng() * 2 - 1, rng() * 2 - 1, rng() * 2 - 1);
      if (dir.lengthSq() < 0.01) dir.set(0, 1, 0);
      dir.normalize();
      const r = 0.4 + 0.6 * Math.sqrt(rng());
      const pos = new THREE.Vector3(cc.c.x + dir.x * cc.rx * r, cc.c.y + dir.y * cc.ry * r, cc.c.z + dir.z * cc.rx * r);
      const nrm = new THREE.Vector3(dir.x, dir.y + 0.35, dir.z).normalize();
      const face = nrm.clone().add(new THREE.Vector3(rng() - 0.5, rng() - 0.5, rng() - 0.5).multiplyScalar(0.7)).normalize();
      const q = new THREE.Quaternion().setFromUnitVectors(Z, face);
      q.multiply(new THREE.Quaternion().setFromAxisAngle(Z, rng() * 6.28));
      const s = size * (0.8 + rng() * 0.45) * (cc.rx / centers[0].rx > 0.7 ? 1 : 0.7);
      const g = new THREE.PlaneGeometry(s, s);
      const gg = xform(g, pos, q);
      const tt = clamp((pos.y - (cc.c.y - cc.ry)) / (2 * cc.ry), 0, 1);
      const jit = (0.88 + rng() * 0.24) * 1.7;
      const c = dark.clone().lerp(light, Math.pow(tt, 0.85)).multiplyScalar(jit);
      paint(gg, () => c);
      setNormals(gg, () => nrm);
      parts.push(gg);
    }
  }
  return merge(parts);
}

function makePine(rng: () => number, H: number) {
  const parts: THREE.BufferGeometry[] = [];
  const tr = new THREE.CylinderGeometry(0.22, 0.5, H * 0.5, 6, 1);
  tr.translate(0, H * 0.25, 0);
  paint(tr, () => col('#4a3626'));
  parts.push(tr);
  const dark = col('#0d3a22'), light = col('#3a8a3c');
  const tiers = 6;
  for (let i = 0; i < tiers; i++) {
    const t = i / (tiers - 1);
    const r = 3.3 - t * 2.4 + rng() * 0.3, h = 3.4 - t * 0.8;
    const y = H * 0.2 + t * H * 0.72;
    const g = new THREE.ConeGeometry(r, h, 9, 1, true);
    g.translate(0, y + h / 2, 0);
    const p = g.attributes.position;
    for (let k = 0; k < p.count; k++) {
      const vy = p.getY(k);
      if (vy < y + h * 0.3) {
        const j = 0.8 + 0.35 * noise2(p.getX(k) * 2 + i * 7, p.getZ(k) * 2, 4);
        p.setXYZ(k, p.getX(k) * j, vy - Math.abs(Math.sin(k * 1.7)) * 0.25, p.getZ(k) * j);
      }
    }
    g.computeVertexNormals();
    paint(g, (v) => dark.clone().lerp(light, clamp((v.y - y) / h, 0, 1) * 0.8 + t * 0.2));
    parts.push(g);
  }
  return { geo: merge(parts), top: H * 0.95 };
}

interface LeafPlant { geo: THREE.BufferGeometry; leafPts: THREE.Vector3[] }
function makeLeafPlant(seed: number, n: number, L: number, W: number): LeafPlant {
  const rng = mulberry32(seed);
  const pos: number[] = [], colr: number[] = [], idx: number[] = [];
  const dark = col('#1c5a1e'), mid = col('#3d9a2a'), tipc = col('#a2dc42');
  const leafPts: THREE.Vector3[] = [];
  const rows = 10;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + rng() * 0.5;
    const s0 = 1.3 + rng() * 0.45, dr = s0 * (0.78 + rng() * 0.15);
    const len = L * (0.75 + rng() * 0.4);
    const fx = Math.cos(a), fz = Math.sin(a), sx = -fz, sz = fx;
    const base = pos.length / 3;
    for (let k = 0; k <= rows; k++) {
      const t = k / rows;
      const d = len * t * 0.78;
      const y = len * (s0 * t - dr * t * t) * 0.62 + 0.1;
      const w = W * Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.04)), 0.75) * (len / L);
      for (const side of [-1, 0, 1]) {
        const curl = -Math.abs(side) * w * 0.32;
        pos.push(fx * d + sx * side * w, y + curl + (side === 0 ? 0.03 : 0), fz * d + sz * side * w);
        const c = dark.clone().lerp(mid, Math.min(1, t * 1.6)).lerp(tipc, Math.max(0, t - 0.45) * 1.3);
        if (side === 0) c.multiplyScalar(1.18);
        colr.push(c.r, c.g, c.b);
      }
      if (k === Math.floor(rows * 0.6)) leafPts.push(new THREE.Vector3(fx * d, y + 0.05, fz * d));
    }
    for (let k = 0; k < rows; k++) {
      const r0 = base + k * 3, r1 = base + (k + 1) * 3;
      idx.push(r0, r0 + 1, r1 + 1, r0, r1 + 1, r1);
      idx.push(r0 + 1, r0 + 2, r1 + 2, r0 + 1, r1 + 2, r1 + 1);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('color', new THREE.Float32BufferAttribute(colr, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(new Array((pos.length / 3) * 2).fill(0), 2));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  leafPts.sort((a, b) => b.y - a.y);
  return { geo, leafPts };
}

function makeGrass() {
  const rng = mulberry32(3);
  const pos: number[] = [], colr: number[] = [], idx: number[] = [], nor: number[] = [];
  const cb = col('#1d4a16'), cm = col('#4d9a22'), ct = col('#b0d84c');
  const blades = 7;
  for (let b = 0; b < blades; b++) {
    const bx = (rng() - 0.5) * 0.5, bz = (rng() - 0.5) * 0.5;
    const ang = rng() * Math.PI, ca = Math.cos(ang), sa = Math.sin(ang);
    const h = 0.55 + rng() * 0.6, w = 0.045 + rng() * 0.03;
    const lean = 0.12 + rng() * 0.3, la = rng() * 6.28, lx = Math.cos(la) * lean, lz = Math.sin(la) * lean;
    const base = pos.length / 3;
    const shade = 0.85 + rng() * 0.3;
    pos.push(bx - ca * w, 0, bz - sa * w, bx + ca * w, 0, bz + sa * w);
    pos.push(bx - ca * w * 0.7 + lx * 0.3, h * 0.55, bz - sa * w * 0.7 + lz * 0.3, bx + ca * w * 0.7 + lx * 0.3, h * 0.55, bz + sa * w * 0.7 + lz * 0.3);
    pos.push(bx + lx, h, bz + lz);
    for (const c of [cb, cb, cm, cm, ct]) colr.push(c.r * shade, c.g * shade, c.b * shade);
    for (let i = 0; i < 5; i++) nor.push(0, 1, 0);
    idx.push(base, base + 1, base + 2, base + 1, base + 3, base + 2, base + 2, base + 3, base + 4);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(colr, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(new Array((pos.length / 3) * 2).fill(0), 2));
  g.setIndex(idx);
  return g;
}

export const FLOWER_H = 0.8;
function makeFlower() {
  const H = FLOWER_H;
  // stem
  const sp: number[] = [], sc: number[] = [], si: number[] = [], sn: number[] = [];
  const g1 = col('#2c6a22'), g2 = col('#5aa032');
  for (let k = 0; k < 4; k++) {
    const t = k / 3, y = H * t, off = 0;
    sp.push(-0.016 + off, y, 0, 0.016 + off, y, 0);
    const c = g1.clone().lerp(g2, t);
    sc.push(c.r, c.g, c.b, c.r, c.g, c.b);
    sn.push(0, 0, 1, 0, 0, 1);
    if (k > 0) { const a = (k - 1) * 2; si.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  }
  const stem = new THREE.BufferGeometry();
  stem.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
  stem.setAttribute('color', new THREE.Float32BufferAttribute(sc, 3));
  stem.setAttribute('normal', new THREE.Float32BufferAttribute(sn, 3));
  stem.setAttribute('uv', new THREE.Float32BufferAttribute(new Array(16).fill(0), 2));
  stem.setIndex(si);
  const stem2 = xform(stem, [0, 0, 0], [0, 1.57, 0]);
  const stemG = merge([stem, stem2]);
  // head
  const hp: number[] = [], hn: number[] = [], hi: number[] = [], hc: number[] = [];
  const petals = 8;
  const hx = Math.sin(1 * 2.2) * 0.05 * 0 + 0.0;
  hp.push(hx, H + 0.02, 0); hn.push(0, 1, 0); hc.push(1, 1, 1);
  for (let i = 0; i < petals; i++) {
    const a = (i / petals) * Math.PI * 2, w = 0.13;
    const a0 = a - w, a1 = a + w;
    const base = hp.length / 3;
    hp.push(Math.cos(a0) * 0.09, H + 0.03, Math.sin(a0) * 0.09);
    hp.push(Math.cos(a) * 0.3, H + 0.08, Math.sin(a) * 0.3);
    hp.push(Math.cos(a1) * 0.09, H + 0.03, Math.sin(a1) * 0.09);
    for (let k = 0; k < 3; k++) { hn.push(0, 1, 0); }
    hc.push(0.9, 0.9, 0.9, 1.05, 1.05, 1.05, 0.9, 0.9, 0.9);
    hi.push(0, base, base + 2, base, base + 1, base + 2);
  }
  const head = new THREE.BufferGeometry();
  head.setAttribute('position', new THREE.Float32BufferAttribute(hp, 3));
  head.setAttribute('normal', new THREE.Float32BufferAttribute(hn, 3));
  head.setAttribute('color', new THREE.Float32BufferAttribute(hc, 3));
  head.setAttribute('uv', new THREE.Float32BufferAttribute(new Array((hp.length / 3) * 2).fill(0), 2));
  head.setIndex(hi);
  const center = new THREE.SphereGeometry(0.06, 6, 4);
  center.translate(0, H + 0.05, 0);
  paint(center, () => col('#ffd23a'));
  return { stem: stemG, head, center };
}

const rockCache: THREE.BufferGeometry[] = [];
function makeRock(seed: number) {
  const g = new THREE.IcosahedronGeometry(1, 2);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const n = 0.78 + 0.5 * noise2(x * 1.4 + y * 0.8 + seed * 9, z * 1.4 + y * 1.1 + seed * 3, seed);
    const n2 = noise2(x * 4 + seed, z * 4 + y * 3, seed + 4);
    x *= n * (1 + (n2 - 0.5) * 0.15); y *= n * (1 + (n2 - 0.5) * 0.15); z *= n;
    if (y < -0.45) y = -0.45 + (y + 0.45) * 0.1;
    p.setXYZ(i, x, y * 0.8, z);
  }
  g.computeVertexNormals();
  const rk = col('#8e887c'), rk2 = col('#6a645c'), moss = col('#4f8a2e'), moss2 = col('#76a83a');
  paint(g, (v, n) => {
    const c = rk.clone().lerp(rk2, noise2(v.x * 3 + seed, v.z * 3, 2));
    const m = smoothstep(0.3, 0.8, n.y) * (0.55 + 0.45 * noise2(v.x * 2.3, v.z * 2.3, 9 + seed));
    c.lerp(moss.clone().lerp(moss2, noise2(v.x * 5, v.z * 5, 1)), m);
    return c;
  });
  return g;
}

/* ------------------------------------------------------------------ ruins */

function stoneBoxFactory(parts: THREE.BufferGeometry[], rng: () => number) {
  const base = col('#d6cdb8'), moss = col('#5e9a34'), moss2 = col('#86b444');
  return (w: number, h: number, d: number, x: number, y: number, z: number, ry = 0, rz = 0, shade = 1, mossAmt = 0.8) => {
    const g = new THREE.BoxGeometry(w, h, d);
    const uv = g.attributes.uv;
    for (let f = 0; f < 6; f++) {
      const dm = f < 2 ? [d, h] : f < 4 ? [w, d] : [w, h];
      for (let k = 0; k < 4; k++) {
        const i = f * 4 + k;
        uv.setXY(i, (uv.getX(i) * dm[0]) / 2.8 + rng(), (uv.getY(i) * dm[1]) / 2.8 + rng());
      }
    }
    const geo = xform(g, [x, y, z], [0, ry, rz]);
    const v0 = 0.88 + rng() * 0.22;
    paint(geo, (v, n) => {
      const c = base.clone().multiplyScalar(shade * v0);
      const m = smoothstep(0.5, 0.9, n.y) * mossAmt * (0.6 + 0.4 * noise2(v.x * 2 + 5, v.z * 2, 3));
      c.lerp(moss.clone().lerp(moss2, noise2(v.x * 3, v.z * 3, 7)), m);
      c.lerp(moss, smoothstep(1.2, 0, v.y) * 0.45);
      return c;
    });
    parts.push(geo);
  };
}

function buildArch(span: number, H: number, broken: boolean, seed: number) {
  const parts: THREE.BufferGeometry[] = [];
  const r = mulberry32(seed);
  const box = stoneBoxFactory(parts, r);
  const hs = span / 2;
  for (const sx of [-1, 1]) {
    const cut = broken && sx > 0;
    box(2.7, 0.8, 2.7, sx * hs, 0.4, 0, 0, 0, 0.9);
    const shaftH = cut ? H * (0.45 + r() * 0.2) : H;
    let y = 0.8;
    while (y < shaftH - 0.2) {
      const hh = Math.min(1.5, shaftH - y);
      box(1.75, hh, 1.75, sx * hs + (r() - 0.5) * 0.12, y + hh / 2, (r() - 0.5) * 0.12, (r() - 0.5) * 0.12);
      y += hh;
    }
    if (!cut) box(2.3, 0.55, 2.3, sx * hs, y + 0.27, 0, 0, 0, 1.05);
  }
  const R = hs, n = 11, yc = H + 0.85;
  for (let i = 0; i < n; i++) {
    if (broken && (i < 3 || (i === 5 && r() < 0.5))) continue;
    const ang = (Math.PI * (i + 0.5)) / n;
    const arc = ((Math.PI * R) / n) * 1.04;
    box(arc, 1.15, 1.85, Math.cos(ang) * R, yc + Math.sin(ang) * R, 0, 0, ang + Math.PI / 2, 1.0, 0.9);
  }
  if (!broken) {
    box(span + 2.8, 1.1, 2.1, 0, yc + R + 1.05, 0, 0, 0, 1.05, 1);
    for (let i = -1; i <= 1; i++) box(1.5, 0.7, 1.6, i * (span * 0.4), yc + R + 1.95, 0, 0, 0, 1, 1);
  } else {
    box(2.2, 0.9, 1.9, -hs * 0.3, yc + R + 0.4, 0, 0.2, 0.15, 1, 1);
  }
  for (let i = 0; i < 5; i++) box(0.9 + r() * 1.1, 0.7 + r() * 0.6, 0.9 + r() * 1.0, (r() - 0.5) * span * 1.5, 0.35, 2.6 + r() * 2.5, r() * 3, 0, 0.85);
  return merge(parts);
}

function buildPillars(seed: number) {
  const parts: THREE.BufferGeometry[] = [];
  const r = mulberry32(seed);
  const box = stoneBoxFactory(parts, r);
  for (let i = 0; i < 5; i++) {
    const x = (i - 2) * 3.6 + (r() - 0.5) * 1.4, z = (r() - 0.5) * 3;
    const H = 2 + r() * 7;
    box(2.2, 0.7, 2.2, x, 0.35, z, 0, 0, 0.9);
    let y = 0.7;
    while (y < H) { const hh = Math.min(1.45, H - y); box(1.6, hh, 1.6, x + (r() - 0.5) * 0.1, y + hh / 2, z, r() * 0.3); y += hh; }
    if (r() < 0.5) box(2.1, 0.5, 2.1, x, y + 0.25, z, 0, 0, 1.05);
  }
  box(1.7, 1.5, 1.7, 3, 0.75, 4.2, 0.4, 1.4, 0.95);
  box(1.4, 1.4, 1.4, -4, 0.7, 3.7, 0.9, 0, 0.9);
  return merge(parts);
}

function buildWall(seed: number) {
  const parts: THREE.BufferGeometry[] = [];
  const r = mulberry32(seed);
  const box = stoneBoxFactory(parts, r);
  for (let row = 0; row < 6; row++) {
    let x = -9 + (row % 2) * 1.1;
    while (x < 9) {
      const w = 1.9 + r() * 1.0;
      if (r() < 0.2 + row * 0.13) { x += w; continue; }
      box(w, 1.05, 1.5, x + w / 2, 0.52 + row * 1.05, (r() - 0.5) * 0.08, 0, 0, 0.85 + r() * 0.2, 0.9);
      x += w + 0.05;
    }
  }
  return merge(parts);
}

function buildBridge() {
  const parts: THREE.BufferGeometry[] = [];
  const r = mulberry32(99);
  const box = stoneBoxFactory(parts, r);
  const span = 8.5, spans = 3, L = span * spans;
  const R = span / 2;
  box(L + 2.5, 0.55, 5.2, 0, 0.27, 0, 0, 0, 1, 0.9);
  box(L + 2.5, 0.95, 0.6, 0, 1.0, 2.3, 0, 0, 0.95, 1);
  box(L + 2.5, 0.95, 0.6, 0, 1.0, -2.3, 0, 0, 0.95, 1);
  box(L, 1.0, 4.8, 0, -0.5, 0, 0, 0, 0.8, 0.2);
  for (let i = 0; i <= spans; i++) box(1.7, 12, 4.9, -L / 2 + i * span, -6, 0, 0, 0, 0.85, 0.3);
  for (let s = 0; s < spans; s++) {
    const cx = -L / 2 + span * (s + 0.5);
    for (let i = 0; i < 9; i++) {
      const ang = (Math.PI * (i + 0.5)) / 9;
      box(((Math.PI * R) / 9) * 1.05, 0.95, 4.9, cx + Math.cos(ang) * R, -R + Math.sin(ang) * R - 0.5, 0, 0, ang + Math.PI / 2, 1, 0.5);
    }
  }
  return merge(parts);
}

function buildWindmill() {
  const body: THREE.BufferGeometry[] = [];
  const cream = col('#efe4c8'), roof = col('#a9442a'), wood = col('#7a5a38');
  const b = new THREE.CylinderGeometry(1.9, 2.9, 9, 12, 1);
  b.translate(0, 4.5, 0);
  paint(b, (v) => cream.clone().multiplyScalar(0.85 + 0.15 * noise2(v.x * 4, v.y * 3, 1)).lerp(col('#8a7d66'), smoothstep(1.2, 0, v.y) * 0.5));
  body.push(b);
  const rf = new THREE.ConeGeometry(2.5, 3.4, 12);
  rf.translate(0, 9 + 1.5, 0);
  paint(rf, () => roof);
  body.push(rf);
  const door = new THREE.BoxGeometry(1.1, 2, 0.3);
  door.translate(0, 1, 2.55);
  paint(door, () => wood);
  body.push(door);
  const win = new THREE.BoxGeometry(0.8, 1.0, 0.3);
  win.translate(0, 5.4, 2.1);
  paint(win, () => col('#3a2a1a'));
  body.push(win);
  const rotor: THREE.BufferGeometry[] = [];
  const hub = new THREE.SphereGeometry(0.5, 8, 6);
  paint(hub, () => wood);
  rotor.push(hub);
  for (let k = 0; k < 4; k++) {
    const arm = new THREE.BoxGeometry(0.24, 8.4, 0.24);
    arm.translate(0, 4.2, 0);
    paint(arm, () => wood);
    const sail = new THREE.BoxGeometry(1.6, 5.8, 0.08);
    sail.translate(0.95, 4.5, 0.05);
    paint(sail, (v) => cream.clone().multiplyScalar(0.8 + 0.2 * Math.abs(Math.sin(v.y * 6))));
    const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), (k * Math.PI) / 2);
    rotor.push(xform(arm, [0, 0, 0], q), xform(sail, [0, 0, 0], q));
  }
  return { body: merge(body), rotor: merge(rotor) };
}

/* ------------------------------------------------------------------ dynamic scatter */

class Scatter {
  meshes: THREE.InstancedMesh[];
  colorMeshes: number[];
  cell: number; R: number; cap: number;
  curX = NaN; curZ = NaN;
  items: Item[] = [];
  count = 0;
  private job: null | { cx: number; cz: number; row: number; n: number; out: Item[] } = null;
  private tmpMat: Float32Array;
  private tmpCol: Float32Array;
  constructor(
    meshes: THREE.InstancedMesh[], colorMeshes: number[], cell: number, R: number, cap: number,
    private gen: (wx: number, wz: number, ix: number, iz: number) => Item | null,
  ) {
    this.meshes = meshes; this.colorMeshes = colorMeshes; this.cell = cell; this.R = R; this.cap = cap;
    this.tmpMat = new Float32Array(cap * 16);
    this.tmpCol = new Float32Array(cap * 3);
    for (const i of colorMeshes) meshes[i].instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3);
    for (const m of meshes) { m.count = 0; m.frustumCulled = false; m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); }
  }

  update(px: number, pz: number, rows: number) {
    if (!this.job) {
      if (isNaN(this.curX) || Math.hypot(px - this.curX, pz - this.curZ) > this.R * 0.26) {
        const cx = Math.floor(px / this.cell) * this.cell, cz = Math.floor(pz / this.cell) * this.cell;
        this.job = { cx, cz, row: 0, n: Math.ceil(this.R / this.cell), out: [] };
      } else return;
    }
    const j = this.job;
    const { cell, R } = this;
    const baseIx = Math.round(j.cx / cell), baseIz = Math.round(j.cz / cell);
    let done = 0;
    while (done < rows && j.row <= j.n * 2) {
      const i = j.row - j.n;
      for (let k = -j.n; k <= j.n; k++) {
        if (j.out.length >= this.cap) break;
        const ix = baseIx + i, iz = baseIz + k;
        const wx = (ix + hash2(ix, iz, 11) * 0.9) * cell, wz = (iz + hash2(ix, iz, 12) * 0.9) * cell;
        const dist = Math.hypot(wx - j.cx, wz - j.cz);
        if (dist > R) continue;
        const it = this.gen(wx, wz, ix, iz);
        if (!it) continue;
        const f = 1 - smoothstep(R * 0.7, R, dist);
        if (f < 0.06) continue;
        it.sx *= f; it.sy *= f;
        j.out.push(it);
      }
      j.row++; done++;
    }
    if (j.row > j.n * 2) {
      const out = j.out;
      const tm = this.tmpMat, tc = this.tmpCol;
      for (let i = 0; i < out.length; i++) {
        const it = out[i];
        const c = Math.cos(it.rot), s = Math.sin(it.rot);
        const o = i * 16;
        tm[o] = c * it.sx; tm[o + 1] = 0; tm[o + 2] = -s * it.sx; tm[o + 3] = 0;
        tm[o + 4] = 0; tm[o + 5] = it.sy; tm[o + 6] = 0; tm[o + 7] = 0;
        tm[o + 8] = s * it.sx; tm[o + 9] = 0; tm[o + 10] = c * it.sx; tm[o + 11] = 0;
        tm[o + 12] = it.x; tm[o + 13] = it.y; tm[o + 14] = it.z; tm[o + 15] = 1;
        tc[i * 3] = it.r; tc[i * 3 + 1] = it.g; tc[i * 3 + 2] = it.b;
      }
      for (let mi = 0; mi < this.meshes.length; mi++) {
        const m = this.meshes[mi];
        (m.instanceMatrix.array as Float32Array).set(tm.subarray(0, out.length * 16));
        m.instanceMatrix.needsUpdate = true;
        if (this.colorMeshes.includes(mi) && m.instanceColor) {
          (m.instanceColor.array as Float32Array).set(tc.subarray(0, out.length * 3));
          m.instanceColor.needsUpdate = true;
        }
        m.count = out.length;
      }
      this.items = out; this.count = out.length;
      this.curX = j.cx; this.curZ = j.cz;
      this.job = null;
    }
  }
}

/* ------------------------------------------------------------------ vegetation manager */

interface Placement { x: number; y: number; z: number; rot: number; s: number; sy: number; tint: THREE.Color }

export class Vegetation {
  group = new THREE.Group();
  perches: Perch[] = [];
  treeSpots: THREE.Vector3[] = [];
  rotor: THREE.Object3D | null = null;
  grass!: Scatter; flowers!: Scatter; ferns!: Scatter;
  windmillPos = new THREE.Vector3();

  constructor(private world: World, private q: QualityCfg) {
    this.buildStatic();
    this.buildDynamic();
  }

  get flowerItems() { return this.flowers.items; }

  private ground(x: number, z: number) { return this.world.heightAt(x, z); }

  private buildStatic() {
    const W = this.world, q = this.q;
    const rng = mulberry32(1337);
    const w = [0, 0, 0, 0];
    const occ = new Set<number>();
    const key = (x: number, z: number) => (Math.floor(x / 5.5) + 300) * 1000 + Math.floor(z / 5.5) + 300;
    const clearing = (x: number, z: number) => Math.hypot(x - START_SITE.x, z - START_SITE.z) < 15;
    const dummyTint = () => new THREE.Color().setRGB(0.88 + rng() * 0.24, 0.9 + rng() * 0.2, 0.86 + rng() * 0.22);

    /* ---- trees ---- */
    const leafTex = [leafClumpTex(11), leafClumpTex(23)];
    const mkCanopyMat = (i: number) => {
      const m = new THREE.MeshLambertMaterial({ map: leafTex[i], vertexColors: true, alphaTest: 0.5, side: THREE.DoubleSide });
      addWind(m, 0.5, 'canopy');
      return m;
    };
    const canopyMats = [mkCanopyMat(0), mkCanopyMat(1)];
    const trunkMat = new THREE.MeshLambertMaterial({ vertexColors: true });

    interface TreeAsset { trunk?: THREE.BufferGeometry; canopy: THREE.BufferGeometry; mat: THREE.Material; tips: THREE.Vector3[]; list: Placement[] }
    const assets: TreeAsset[] = [];
    const broad = (seed: number, H: number, rx: number, ry: number, dark: string, light: string, matIdx: number) => {
      const r = mulberry32(seed);
      const tr = makeTrunk(r, H);
      const centers = [{ c: new THREE.Vector3(0, H * 1.0, 0), rx, ry, w: 1.5 }];
      tr.tips.slice(0, 3).forEach((t) => centers.push({ c: t.clone().add(new THREE.Vector3(0, 0.8, 0)), rx: rx * 0.45, ry: ry * 0.5, w: 0.7 }));
      const canopy = makeCanopy(r, q.treeCards, centers, col(dark), col(light), rx * 0.92);
      assets.push({ trunk: tr.geo, canopy, mat: canopyMats[matIdx], tips: tr.tips, list: [] });
    };
    broad(101, 9, 5.4, 3.6, '#1a4d1a', '#7cc030', 0);   // 0 tropical A
    broad(202, 11, 4.6, 4.2, '#16491c', '#8acb36', 1);  // 1 tropical B
    broad(303, 7.5, 4.8, 3.2, '#a63a18', '#f08a2a', 0); // 2 autumn red
    broad(404, 8, 4.6, 3.2, '#2c5a1a', '#a4c83a', 1);   // 3 light green
    const pineA = makePine(mulberry32(5), 14), pineB = makePine(mulberry32(6), 17);
    const pineMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    addWind(pineMat, 0.18, 'canopy');
    assets.push({ canopy: pineA.geo, mat: pineMat, tips: [new THREE.Vector3(0, pineA.top, 0)], list: [] }); // 4
    assets.push({ canopy: pineB.geo, mat: pineMat, tips: [new THREE.Vector3(0, pineB.top, 0)], list: [] }); // 5

    const attempts = Math.floor(21000 * q.treeDensity);
    for (let a = 0; a < attempts; a++) {
      const x = (rng() * 2 - 1) * 482, z = (rng() * 2 - 1) * 482;
      const h = W.heightAt(x, z);
      if (h < 1.3 || h > 105) continue;
      if (clearing(x, z)) continue;
      regionWeights(x, z, w);
      const clump = fbm(x * 0.025 + 9, z * 0.025, 3, 40);
      let p = w[0] * 0.3 * smoothstep(0.32, 0.48, clump) + w[1] * 0.05 * smoothstep(0.45, 0.6, clump) + w[2] * 0.11 * smoothstep(0.35, 0.5, clump) + w[3] * 0.14 * smoothstep(0.3, 0.45, clump);
      if (p <= 0 || rng() > p) continue;
      if (W.pathMask(x, z) > 0.2) continue;
      if (W.slopeAt(x, z) > 0.85) continue;
      const k = key(x, z);
      if (occ.has(k)) continue;
      let kind: number, s: number;
      const dom = w.indexOf(Math.max(...w));
      if (dom === 3 || h > 58) { kind = rng() < 0.85 ? 4 + (rng() < 0.5 ? 1 : 0) : (rng() < 0.5 ? 2 : 3); s = 0.8 + rng() * 1.2; if (h > 85) continue; }
      else if (dom === 0) { kind = rng() < 0.06 ? 4 : rng() < 0.55 ? 0 : 1; s = 1.5 + rng() * 1.2; if (kind === 4) s = 1.1 + rng() * 0.8; }
      else if (dom === 1) { kind = rng() < 0.42 ? 2 : (rng() < 0.5 ? 3 : 0); s = 0.85 + rng() * 0.55; }
      else { kind = rng() < 0.15 ? 4 : rng() < 0.5 ? 0 : 3; s = 1.0 + rng() * 0.8; }
      occ.add(k);
      if (s > 1.9) { occ.add(k + 1); occ.add(k - 1); occ.add(k + 1000); occ.add(k - 1000); }
      assets[kind].list.push({ x, y: h - 0.25, z, rot: rng() * 6.28, s, sy: s * (0.9 + rng() * 0.25), tint: dummyTint() });
    }
    for (const as of assets) {
      if (!as.list.length) continue;
      const mk = (geo: THREE.BufferGeometry, mat: THREE.Material, tint: boolean) => {
        const m = new THREE.InstancedMesh(geo, mat, as.list.length);
        as.list.forEach((p, i) => {
          m.setMatrixAt(i, matrixFrom(p.x, p.y, p.z, p.rot, p.s, p.sy, p.s));
          if (tint) m.setColorAt(i, p.tint);
        });
        m.castShadow = true; m.receiveShadow = true;
        m.instanceMatrix.needsUpdate = true;
        this.group.add(m);
      };
      if (as.trunk) mk(as.trunk, trunkMat, false);
      mk(as.canopy, as.mat, true);
      as.list.forEach((p, i) => {
        if (i % 2 === 0) {
          const t = as.tips[0].clone();
          t.set(t.x * p.s, t.y * p.sy, t.z * p.s);
          const c = Math.cos(p.rot), s = Math.sin(p.rot);
          const pos = new THREE.Vector3(p.x + t.x * c + t.z * s, p.y + t.y, p.z - t.x * s + t.z * c);
          this.perches.push({ pos, kind: as.trunk ? 'branch' : 'canopy' });
        }
        if (i % 3 === 0) this.treeSpots.push(new THREE.Vector3(p.x, p.y + (as.trunk ? 11 : 12) * p.sy, p.z));
      });
    }

    /* ---- rocks ---- */
    if (!rockCache.length) for (let i = 0; i < 3; i++) rockCache.push(makeRock(i + 1));
    const rockMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
    const rockLists: Placement[][] = [[], [], []];
    const rAttempts = Math.floor(9500 * q.rockDensity);
    for (let a = 0; a < rAttempts; a++) {
      const x = (rng() * 2 - 1) * 485, z = (rng() * 2 - 1) * 485;
      const h = W.heightAt(x, z);
      if (h < -0.8 || clearing(x, z)) continue;
      regionWeights(x, z, w);
      const slope = W.slopeAt(x, z);
      let p = w[0] * 0.06 + w[1] * 0.025 + w[2] * 0.05 + w[3] * 0.12 + Math.max(0, slope - 0.6) * 0.3;
      if (h < 1.8) p += 0.12;
      if (rng() > p) continue;
      const mount = w[3] > 0.5 || w[0] > 0.5;
      let s = 0.5 + Math.pow(rng(), 2.6) * (mount ? 6 : 3.2);
      if (h > 90) s *= 1.6;
      rockLists[Math.floor(rng() * 3)].push({
        x, y: h - s * 0.2, z, rot: rng() * 6.28, s: s * (1 + rng() * 0.6), sy: s * (0.6 + rng() * 0.5),
        tint: new THREE.Color().setScalar(0.8 + rng() * 0.35),
      });
    }
    rockLists.forEach((list, ri) => {
      if (!list.length) return;
      const m = new THREE.InstancedMesh(rockCache[ri], rockMat, list.length);
      list.forEach((p, i) => {
        m.setMatrixAt(i, matrixFrom(p.x, p.y, p.z, p.rot, p.s, p.sy, p.s * 0.85));
        m.setColorAt(i, p.tint);
        if (p.s > 1.5 && i % 2 === 0) this.perches.push({ pos: new THREE.Vector3(p.x, p.y + p.sy * 0.72, p.z), kind: 'rock' });
      });
      m.castShadow = true; m.receiveShadow = true;
      this.group.add(m);
    });

    /* ---- giant leaf plants ---- */
    const plants = [makeLeafPlant(7, 7, 4.4, 1.35), makeLeafPlant(8, 6, 3.8, 1.2)];
    const plantMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    addWind(plantMat, 1.0, 'leaf');
    const plantLists: Placement[][] = [[], []];
    for (let a = 0; a < 16000 * q.treeDensity; a++) {
      const x = (rng() * 2 - 1) * 480, z = (rng() * 2 - 1) * 480;
      const h = W.heightAt(x, z);
      if (h < 0.8 || h > 70 || clearing(x, z)) continue;
      regionWeights(x, z, w);
      const clump = fbm(x * 0.04 + 3, z * 0.04, 2, 55);
      let p = w[0] * 0.22 * smoothstep(0.35, 0.5, clump) + w[2] * 0.07 + w[1] * 0.008;
      if (h < 3) p *= 2;
      if (rng() > p || W.pathMask(x, z) > 0.25) continue;
      const k = Math.floor(rng() * 2);
      plantLists[k].push({ x, y: h - 0.1, z, rot: rng() * 6.28, s: 0.8 + rng() * 1.2, sy: 0.9 + rng() * 0.7, tint: new THREE.Color().setRGB(0.85 + rng() * 0.25, 0.9 + rng() * 0.2, 0.8 + rng() * 0.2) });
    }
    plantLists.forEach((list, pi) => {
      if (!list.length) return;
      const m = new THREE.InstancedMesh(plants[pi].geo, plantMat, list.length);
      list.forEach((p, i) => {
        m.setMatrixAt(i, matrixFrom(p.x, p.y, p.z, p.rot, p.s, p.s * p.sy * 0.9, p.s));
        m.setColorAt(i, p.tint);
        if (i % 3 === 0) {
          const lp = plants[pi].leafPts[0];
          const c = Math.cos(p.rot), s = Math.sin(p.rot);
          this.perches.push({
            pos: new THREE.Vector3(p.x + (lp.x * c + lp.z * s) * p.s, p.y + lp.y * p.s * p.sy * 0.9, p.z + (-lp.x * s + lp.z * c) * p.s),
            kind: 'leaf',
          });
        }
      });
      m.castShadow = true; m.receiveShadow = true;
      this.group.add(m);
    });

    /* ---- ruins ---- */
    const stone = stoneTex();
    stone.wrapS = stone.wrapT = THREE.RepeatWrapping;
    const stoneMat = new THREE.MeshLambertMaterial({ map: stone, vertexColors: true });
    const ruinGeo = {
      arch: buildArch(9, 9, false, 1), archB: buildArch(9, 9, true, 2), archC: buildArch(7, 7, true, 3),
      pillars: buildPillars(4), wall: buildWall(5),
    };
    const ruins: { t: keyof typeof ruinGeo; x: number; z: number; rot: number; s: number }[] = [
      { t: 'arch', x: -262, z: 168, rot: 0.5, s: 1.9 }, { t: 'archB', x: -120, z: 152, rot: 2.1, s: 1.3 },
      { t: 'pillars', x: -250, z: 255, rot: 0.3, s: 1.2 }, { t: 'wall', x: -162, z: 272, rot: 1.0, s: 1.2 },
      { t: 'archC', x: -300, z: 110, rot: 2.6, s: 1.3 },
      { t: 'arch', x: 236, z: 190, rot: -0.15, s: 1.7 }, { t: 'pillars', x: 205, z: 222, rot: 0.6, s: 1.1 },
      { t: 'wall', x: 176, z: 242, rot: 0.2, s: 1.1 }, { t: 'archB', x: 150, z: 118, rot: 1.2, s: 1.1 },
      { t: 'pillars', x: 290, z: 120, rot: 2.0, s: 1.0 },
      { t: 'arch', x: 172, z: -150, rot: 0.8, s: 1.6 }, { t: 'pillars', x: 192, z: -192, rot: 0.1, s: 1.3 },
      { t: 'archB', x: 232, z: -118, rot: -0.7, s: 1.4 }, { t: 'wall', x: 120, z: -215, rot: 0.9, s: 1.4 },
      { t: 'archC', x: 120, z: -110, rot: 0.2, s: 1.4 }, { t: 'arch', x: 266, z: -276, rot: 0.4, s: 0.9 },
      { t: 'archB', x: -118, z: -165, rot: 1.8, s: 1.5 }, { t: 'pillars', x: -318, z: -150, rot: 0.2, s: 1.2 },
      { t: 'arch', x: -205, z: -365, rot: 0.0, s: 1.5 }, { t: 'wall', x: -100, z: -80, rot: 0.5, s: 1.1 },
    ];
    const rl: Record<string, Placement[]> = {};
    for (const r of ruins) {
      const hs = [W.heightAt(r.x, r.z), W.heightAt(r.x + 6 * r.s, r.z), W.heightAt(r.x - 6 * r.s, r.z), W.heightAt(r.x, r.z + 5 * r.s), W.heightAt(r.x, r.z - 5 * r.s)];
      const mn = Math.min(...hs);
      if (mn < 0.5) continue;
      (rl[r.t] ||= []).push({ x: r.x, y: mn - 0.9, z: r.z, rot: r.rot, s: r.s, sy: r.s, tint: new THREE.Color(1, 1, 1) });
      if (r.t.startsWith('arch')) {
        const broken = r.t !== 'arch';
        const hs = r.t === 'archC' ? 3.5 : 4.5, H = r.t === 'archC' ? 7 : 9;
        const lx = broken ? -hs * r.s : 0, ly = broken ? H + 0.95 : 16.4;
        const c = Math.cos(r.rot), sn = Math.sin(r.rot);
        this.perches.push({ pos: new THREE.Vector3(r.x + lx * c, mn - 0.9 + ly * r.s, r.z - lx * sn), kind: 'ruin' });
      }
    }
    for (const t of Object.keys(rl)) {
      const list = rl[t];
      const m = new THREE.InstancedMesh(ruinGeo[t as keyof typeof ruinGeo], stoneMat, list.length);
      list.forEach((p, i) => m.setMatrixAt(i, matrixFrom(p.x, p.y, p.z, p.rot, p.s)));
      m.castShadow = true; m.receiveShadow = true;
      this.group.add(m);
    }

    /* ---- stone bridge over the river ---- */
    {
      const a = RIVER_PTS[27], b = RIVER_PTS[30];
      const tang = new THREE.Vector3(b.x - a.x, 0, b.z - a.z).normalize();
      const c = RIVER_PTS[28.5 | 0];
      const cx = c.x, cz = c.z;
      const ang = Math.atan2(tang.x, tang.z) + Math.PI / 2 + Math.PI; // local X along crossing direction
      const dirx = Math.cos(ang - Math.PI), dirz = -Math.sin(ang - Math.PI);
      void dirx; void dirz;
      const px = -tang.z, pz = tang.x; // perpendicular (crossing direction)
      const h1 = W.heightAt(cx + px * 14, cz + pz * 14), h2 = W.heightAt(cx - px * 14, cz - pz * 14);
      const deckY = Math.max(h1, h2, 3.4) + 0.2;
      const bm = new THREE.Mesh(buildBridge(), stoneMat);
      bm.position.set(cx, deckY, cz);
      bm.rotation.y = Math.atan2(-pz, px);
      bm.castShadow = true; bm.receiveShadow = true;
      this.group.add(bm);
      this.bridgePos.set(cx, deckY, cz);
      this.perches.push({ pos: new THREE.Vector3(cx + px * 3, deckY + 1.5, cz + pz * 3), kind: 'ruin' });
    }

    /* ---- windmill, fences ---- */
    {
      const wx = 262, wz = 262;
      const wy = W.heightAt(wx, wz) - 0.5;
      const wm = buildWindmill();
      const bodyM = new THREE.Mesh(wm.body, new THREE.MeshLambertMaterial({ vertexColors: true }));
      bodyM.position.set(wx, wy, wz); bodyM.rotation.y = -0.6;
      bodyM.castShadow = true; bodyM.receiveShadow = true;
      const rotor = new THREE.Mesh(wm.rotor, new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide }));
      rotor.castShadow = true;
      const pivot = new THREE.Group();
      pivot.position.set(0, 7.4, 2.9);
      pivot.add(rotor);
      bodyM.add(pivot);
      this.rotor = pivot;
      this.group.add(bodyM);
      this.windmillPos.set(wx, wy, wz);
      this.perches.push({ pos: new THREE.Vector3(wx, wy + 12.8, wz), kind: 'ruin' });

      const fenceParts: THREE.BufferGeometry[] = [];
      const wood = col('#8a6a45');
      const fence = (pts: [number, number][]) => {
        const X = new THREE.Vector3(1, 0, 0);
        const posts: THREE.Vector3[] = [];
        for (let i = 0; i < pts.length - 1; i++) {
          const [ax, az] = pts[i], [bx, bz] = pts[i + 1];
          const len = Math.hypot(bx - ax, bz - az), n = Math.max(1, Math.round(len / 2.4));
          for (let k = 0; k < n; k++) posts.push(new THREE.Vector3(lerp(ax, bx, k / n), 0, lerp(az, bz, k / n)));
          if (i === pts.length - 2) posts.push(new THREE.Vector3(bx, 0, bz));
        }
        posts.forEach((p) => { p.y = this.ground(p.x, p.z); });
        posts.forEach((p, i) => {
          const g = new THREE.BoxGeometry(0.2, 1.5, 0.2); g.translate(0, 0.6, 0);
          paint(g, () => wood.clone().multiplyScalar(0.8 + 0.3 * noise2(i, 3, 1)));
          fenceParts.push(xform(g, p));
          if (i > 0) {
            const a = posts[i - 1];
            for (const hy of [0.55, 1.05]) {
              const d = new THREE.Vector3(p.x - a.x, p.y - a.y, p.z - a.z);
              const len = d.length();
              const gr = new THREE.BoxGeometry(len, 0.12, 0.07);
              paint(gr, () => wood.clone().multiplyScalar(0.95));
              const q2 = new THREE.Quaternion().setFromUnitVectors(X, d.clone().normalize());
              fenceParts.push(xform(gr, [(a.x + p.x) / 2, (a.y + p.y) / 2 + hy, (a.z + p.z) / 2], q2));
            }
          }
        });
      };
      fence([[wx - 28, wz - 8], [wx - 14, wz - 18], [wx + 2, wz - 22], [wx + 18, wz - 18]]);
      fence([[wx - 30, wz + 10], [wx - 22, wz + 24], [wx - 8, wz + 32]]);
      const hay = new THREE.CylinderGeometry(1.0, 1.0, 1.6, 10);
      hay.rotateZ(Math.PI / 2);
      paint(hay, (v) => col('#d8b94a').multiplyScalar(0.8 + 0.2 * Math.sin(v.x * 9)));
      [[wx - 10, wz + 12, 0.4], [wx - 7, wz + 14, 1.1], [wx - 9, wz + 10, 2.0]].forEach(([hx, hz, ry], i) => {
        fenceParts.push(xform(hay, [hx, this.ground(hx, hz) + 0.9, hz], [0, ry + i, 0]));
      });
      const fm = new THREE.Mesh(merge(fenceParts), new THREE.MeshLambertMaterial({ vertexColors: true }));
      fm.castShadow = true; fm.receiveShadow = true;
      this.group.add(fm);
    }
  }

  bridgePos = new THREE.Vector3();

  private buildDynamic() {
    const W = this.world, q = this.q;
    const w = [0, 0, 0, 0];
    const grassMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    addWind(grassMat, 0.55, 'grass');
    const grassCap = Math.ceil(Math.PI * q.grassR * q.grassR / (q.grassCell * q.grassCell) * 0.9);
    const gm = new THREE.InstancedMesh(makeGrass(), grassMat, grassCap);
    gm.receiveShadow = q.shadowMap > 0;
    this.group.add(gm);
    const tint: [number, number, number][] = [[0.72, 0.95, 0.72], [1.14, 1.05, 0.64], [0.86, 1.05, 0.8], [0.9, 1.0, 0.78]];
    this.grass = new Scatter([gm], [0], q.grassCell, q.grassR, grassCap, (x, z, ix, iz) => {
      const h = W.heightAt(x, z);
      if (h < 0.55) return null;
      regionWeights(x, z, w);
      let d = w[0] * 0.62 + w[1] * 1.0 + w[2] * 0.75 + w[3] * 0.4;
      d *= 0.55 + 0.9 * fbm(x * 0.07, z * 0.07, 2, 61);
      if (hash2(ix, iz, 7) > d) return null;
      if (W.pathMask(x, z) > 0.3) return null;
      if (W.slopeAt(x, z) > 0.95) return null;
      const hs = w[0] * 0.8 + w[1] * 1.3 + w[2] * 1.0 + w[3] * 0.8;
      const v = 0.8 + 0.4 * hash2(ix, iz, 8);
      let r = 0, g = 0, b = 0;
      for (let i = 0; i < 4; i++) { r += w[i] * tint[i][0]; g += w[i] * tint[i][1]; b += w[i] * tint[i][2]; }
      const patch = 0.85 + 0.3 * noise2(x * 0.05, z * 0.05, 9);
      return { x, y: h - 0.03, z, rot: hash2(ix, iz, 9) * 6.28, sx: (0.8 + 0.5 * hash2(ix, iz, 10)) * 1.0, sy: hs * (0.7 + 0.6 * hash2(ix, iz, 13)), r: r * v * patch, g: g * v * patch, b: b * v * patch, type: 0 };
    });

    // flowers: stems + heads (tinted) + centres share the same instance transforms
    const fg = makeFlower();
    const fMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    addWind(fMat, 0.9, 'grass');
    const fCap = Math.ceil(Math.PI * q.flowerR * q.flowerR / (q.flowerCell * q.flowerCell) * 0.9);
    const stemM = new THREE.InstancedMesh(fg.stem, fMat, fCap);
    const headM = new THREE.InstancedMesh(fg.head, fMat, fCap);
    const centM = new THREE.InstancedMesh(fg.center, fMat, fCap);
    [stemM, headM, centM].forEach((m) => this.group.add(m));
    const flowerCols = FLOWER_TYPES.map((t) => col(t.color));
    this.flowers = new Scatter([stemM, headM, centM], [1], q.flowerCell, q.flowerR, fCap, (x, z, ix, iz) => {
      const h = W.heightAt(x, z);
      if (h < 0.7) return null;
      regionWeights(x, z, w);
      const dens = w[0] * 0.3 + w[1] * 0.8 + w[2] * 0.45 + w[3] * 0.25;
      const patch = smoothstep(0.38, 0.56, fbm(x * 0.045 + 5, z * 0.045, 2, 71));
      if (hash2(ix, iz, 21) > dens * (0.15 + patch * 1.2)) return null;
      if (W.pathMask(x, z) > 0.3 || W.slopeAt(x, z) > 0.9) return null;
      const dom = w.indexOf(Math.max(...w));
      const lst = REGION_FLOWERS[dom];
      const pn = noise2(x * 0.03 + 11, z * 0.03 + 4, 5);
      const type = lst[Math.floor(clamp(pn * 1.3 - 0.1, 0, 0.999) * lst.length)];
      const c = flowerCols[type];
      const s = 0.8 + 0.7 * hash2(ix, iz, 22);
      const v = 0.92 + 0.16 * hash2(ix, iz, 23);
      return { x, y: h - 0.02, z, rot: hash2(ix, iz, 24) * 6.28, sx: s, sy: s, r: c.r * v, g: c.g * v, b: c.b * v, type };
    });

    // ferns / small leafy plants
    const fern = makeLeafPlant(21, 9, 1.3, 0.42);
    const fernMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    addWind(fernMat, 1.4, 'leaf');
    const nCap = Math.ceil(Math.PI * q.fernR * q.fernR / (q.fernCell * q.fernCell) * 0.9);
    const fm = new THREE.InstancedMesh(fern.geo, fernMat, nCap);
    fm.receiveShadow = q.shadowMap > 0;
    this.group.add(fm);
    this.ferns = new Scatter([fm], [0], q.fernCell, q.fernR, nCap, (x, z, ix, iz) => {
      const h = W.heightAt(x, z);
      if (h < 0.7) return null;
      regionWeights(x, z, w);
      const d = w[0] * 0.85 + w[2] * 0.4 + w[3] * 0.25 + w[1] * 0.08;
      if (hash2(ix, iz, 31) > d) return null;
      if (W.pathMask(x, z) > 0.3 || W.slopeAt(x, z) > 0.9) return null;
      const s = 0.8 + 0.9 * hash2(ix, iz, 32);
      const v = 0.85 + 0.3 * hash2(ix, iz, 33);
      return { x, y: h - 0.05, z, rot: hash2(ix, iz, 34) * 6.28, sx: s, sy: s * 0.9, r: v, g: v, b: v * 0.95, type: 0 };
    });
  }

  update(dt: number, p: THREE.Vector3, wind: number) {
    this.grass.update(p.x, p.z, 4);
    this.flowers.update(p.x, p.z, 6);
    this.ferns.update(p.x, p.z, 6);
    if (this.rotor) this.rotor.rotation.z += dt * (0.25 + wind * 1.1);
  }
}
